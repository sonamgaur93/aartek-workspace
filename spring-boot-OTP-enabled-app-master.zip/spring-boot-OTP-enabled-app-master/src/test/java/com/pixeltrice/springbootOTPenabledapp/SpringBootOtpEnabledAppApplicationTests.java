package com.pixeltrice.springbootOTPenabledapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOtpEnabledAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
