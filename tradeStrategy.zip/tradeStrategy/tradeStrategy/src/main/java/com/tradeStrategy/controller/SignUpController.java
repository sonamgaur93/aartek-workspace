package com.tradeStrategy.controller;

import java.awt.Dialog.ModalExclusionType;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tradeStrategy.dto.UserRequestDto;
import com.tradeStrategy.dto.UserSigInDto;
import com.tradeStrategy.entity.User;
import com.tradeStrategy.service.UserService;

@Controller
public class SignUpController {

	@Autowired
	UserService userService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String welcomePage() {
		return "welcome";
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcomeHomePage() {
		return "welcome";
	}
	
	@RequestMapping(value = "/signUp", method = RequestMethod.GET)
	public String signUpPage() {
		return "sign-up";
	}

	@RequestMapping(value = "/signUp", method = RequestMethod.POST)
	public String signUpPage(@Valid @ModelAttribute("userRequestDto") UserRequestDto userRequestDto, BindingResult result) {
		
	  User existing	=userService.findByEmailCheck(userRequestDto.getEmail());
	  
	  if (existing != null) {
          result.rejectValue("email", null, "There is already an account registered with that email");
      }
		if (result.hasErrors()) {
			System.err.println(result);
			System.err.println(userRequestDto);
		 return "sign-up";
		}
		userService.signUpPage(userRequestDto);
		return "otp-page";
	}

	
	@RequestMapping(value = "/signIn", method = RequestMethod.GET)
	public String signInPage() {
		return "sign-in";
	}
	
	@RequestMapping(value = "/signIn", method = RequestMethod.POST)
	public String signInPage(@ModelAttribute UserSigInDto userSigInDto) {
		userService.signInPage(userSigInDto);
		return "homePage";
	}

}
