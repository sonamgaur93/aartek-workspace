package com.tradeStrategy.service;


import com.tradeStrategy.dto.UserRequestDto;
import com.tradeStrategy.dto.UserSigInDto;
import com.tradeStrategy.entity.User;

public interface UserService {

	String signUpPage(UserRequestDto userRequestDto);
	
	User findByEmailCheck(String email);

	String signInPage(UserSigInDto userSigInDto);

}
