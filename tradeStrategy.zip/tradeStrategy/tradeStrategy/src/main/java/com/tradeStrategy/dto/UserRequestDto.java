package com.tradeStrategy.dto;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.tradeStrategy.validation.ContactNumberConstraint;
import com.tradeStrategy.validation.EmailConstraint;

import lombok.Data;

@Data
public class UserRequestDto {

	private Integer id;

	@NotEmpty(message="First Name required")
	private String firstName;

	@NotEmpty(message ="Last Name required")
	private String lastName;

	@NotEmpty(message ="User Name required")
	private String username;

	
	@Email
	@EmailConstraint
	private String email;

	@NotEmpty(message ="Phone Number required")
	@ContactNumberConstraint
	private String phoneNumber;

	@NotEmpty(message ="Password required")
	private String password;

}
