package com.tradeStrategy.serviceImpl;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tradeStrategy.Exception.ServerException;
import com.tradeStrategy.dto.UserRequestDto;
import com.tradeStrategy.dto.UserSigInDto;
import com.tradeStrategy.entity.User;
import com.tradeStrategy.repository.UserRepo;
import com.tradeStrategy.service.UserService;


@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepo userRepo;

	@Override
	public String signUpPage(UserRequestDto userRequestDto) {
		User user =new User();
		user.setFirstName(userRequestDto.getFirstName());
		user.setLastName(userRequestDto.getLastName());
		user.setUsername(userRequestDto.getUsername());
		user.setPhoneNumber(userRequestDto.getPhoneNumber());
		user.setEmail(userRequestDto.getEmail());
		user.setPassword(new String(Base64.getEncoder().encode(userRequestDto.getPassword().getBytes())));
		userRepo.save(user);

		return "success";
	}

	@Override
	public String signInPage(UserSigInDto userSigInDto){
		User user=userRepo.findByEmail(userSigInDto.getEmail());
		if(user==null) {
			throw new ServerException();
		}
		return "success";

	}

	 @Override
	    public User findByEmailCheck(String email) {
	        return userRepo.findByEmail(email);
	    }

}
