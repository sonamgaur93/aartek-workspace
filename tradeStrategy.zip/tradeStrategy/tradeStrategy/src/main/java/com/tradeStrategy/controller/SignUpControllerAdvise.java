package com.tradeStrategy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.tradeStrategy.Exception.ServerException;
import com.tradeStrategy.dto.UserRequestDto;
import com.tradeStrategy.dto.UserSigInDto;
import com.tradeStrategy.service.UserService;

@ControllerAdvice
public class SignUpControllerAdvise {

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(ServerException.class)
	public String signInPage(Model model) {
		model.addAttribute("email", "User not found");
		return "error-page";
	}
}
