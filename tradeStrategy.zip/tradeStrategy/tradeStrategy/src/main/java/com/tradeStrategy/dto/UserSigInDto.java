package com.tradeStrategy.dto;

import lombok.Data;

@Data
public class UserSigInDto {

	private String email;
	private String password;
}
