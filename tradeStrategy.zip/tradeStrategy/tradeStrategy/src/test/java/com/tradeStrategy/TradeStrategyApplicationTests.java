package com.tradeStrategy;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeStrategyApplicationTests {


}
