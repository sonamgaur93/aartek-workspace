package com.hamararojgar.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mapping_notification_member")
@Entity
public class ModelMappingNotificationMember extends CommonDBFields{
	
	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}
	
	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	@Column(name="num_notification_id")
	private Long notificationId;
	
	@Column(name="vc_member_code")
	private String memberCode;
	
	@Column(name="vc_member_type")
	private String memberType;
	
}