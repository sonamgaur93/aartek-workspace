package com.hamararojgar.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "module_comments")
@Entity(name = "ModelModuleComment")
public class ModelModuleComment extends CommonDBFields{
	
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	@Column(name="vc_module_name")
	private String moduleName;
	
	@Column(name="vc_record_id")
	private String recordId;
	
	@Column(name="vc_comment")
	private String comment;

}