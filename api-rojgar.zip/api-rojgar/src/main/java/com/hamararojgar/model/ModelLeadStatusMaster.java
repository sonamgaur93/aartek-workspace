package com.hamararojgar.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mst_lead_status")
@Entity
public class ModelLeadStatusMaster extends CommonDBFields{
	
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDescription() {
		return statusDescription;
	}
	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}
	
	
	public String getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}



	private String statusCode;
	private String statusDescription;
	private String userRoles;
}
