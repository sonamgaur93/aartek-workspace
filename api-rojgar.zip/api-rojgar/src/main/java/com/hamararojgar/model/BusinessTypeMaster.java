package com.hamararojgar.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;

@Table(name = "business_type_master")
@Entity
public class BusinessTypeMaster  extends CommonDBFields{

	public String getTitle() {
		if(null != title && !title.isEmpty()) {
			return UCharacter.toTitleCase(title, BreakIterator.getTitleInstance());
		}
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	private String title;

}
