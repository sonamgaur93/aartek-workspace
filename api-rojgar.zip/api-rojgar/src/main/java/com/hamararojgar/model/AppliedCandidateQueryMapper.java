package com.hamararojgar.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hamararojgar.dto.AppliedCandidateDto;

public class AppliedCandidateQueryMapper implements RowMapper<AppliedCandidateDto> {

	@Override
	public AppliedCandidateDto mapRow(ResultSet resultSet, int i) throws SQLException {
		AppliedCandidateDto appliedCandidateDto = new AppliedCandidateDto();
		appliedCandidateDto.setAddress(resultSet.getString("address"));
		appliedCandidateDto.setAdhaar_image_url(resultSet.getString("adhaar_image_url"));
		appliedCandidateDto.setAppliedJobId(resultSet.getInt("appliedJobId"));
		appliedCandidateDto.setAppliedDate(resultSet.getString("appliedDate"));
		appliedCandidateDto.setAvailability(resultSet.getString("availability"));
		appliedCandidateDto.setContact_no(resultSet.getString("contact_no"));
		appliedCandidateDto.setCurrent_location(resultSet.getString("current_location"));
		appliedCandidateDto.setDevice_token(resultSet.getString("device_token"));
		appliedCandidateDto.setEmail(resultSet.getString("email"));
		appliedCandidateDto.setExpected_compensation(resultSet.getString("expected_compensation"));
		appliedCandidateDto.setExpected_salary(resultSet.getString("expected_salary"));
		appliedCandidateDto.setExperience(resultSet.getString("experience"));
		appliedCandidateDto.setFather_name(resultSet.getString("father_name"));
		appliedCandidateDto.setJob_id(resultSet.getInt("job_id"));
		appliedCandidateDto.setJob_seeker_id(resultSet.getInt("job_seeker_id"));
		appliedCandidateDto.setMessage(resultSet.getString("message"));
		appliedCandidateDto.setName(resultSet.getString("name"));
		appliedCandidateDto.setPreferred_location(resultSet.getString("preferred_location"));
		appliedCandidateDto.setProfile_pic_url(resultSet.getString("profile_pic_url"));
		appliedCandidateDto.setRecording_url(resultSet.getString("recording_url"));
		appliedCandidateDto.setSkills(resultSet.getString("skills"));
		appliedCandidateDto.setStatus(resultSet.getString("status"));
		appliedCandidateDto.setVerified(resultSet.getBoolean("verified"));
		appliedCandidateDto.setAppliedJobType(resultSet.getString("appliedJobType"));
		return appliedCandidateDto;
	}

}
