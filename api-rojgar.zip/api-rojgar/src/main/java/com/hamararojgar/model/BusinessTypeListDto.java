package com.hamararojgar.model;

import java.util.List;

public class BusinessTypeListDto extends ResponseDto{

	List<BusinessTypeMaster> businessTypeList ;

	public List<BusinessTypeMaster> getBusinessTypeList() {
		return businessTypeList;
	}

	public void setBusinessTypeList(List<BusinessTypeMaster> businessTypeList) {
		this.businessTypeList = businessTypeList;
	}

	
}
