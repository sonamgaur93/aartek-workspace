package com.hamararojgar.model;

public class VerifyUserDto {

	private int job_seeker_id;
	private String contact_no;
	private String otp;
	private String verificationType;
	private String email;
	private boolean isRegistration;
	
	public boolean isRegistration() {
		return isRegistration;
	}
	public void setRegistration(boolean isRegistration) {
		this.isRegistration = isRegistration;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public int getJob_seeker_id() {
		return job_seeker_id;
	}
	public void setJob_seeker_id(int job_seeker_id) {
		this.job_seeker_id = job_seeker_id;
	}
	public String getVerificationType() {
		return verificationType;
	}
	public void setVerificationType(String verificationType) {
		this.verificationType = verificationType;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "VerifyUserDto [job_seeker_id=" + job_seeker_id + ", contact_no=" + contact_no + ", otp=" + otp
				+ ", verificationType=" + verificationType + ", email=" + email + ", isRegistration=" + isRegistration
				+ "]";
	}
	
	
	
	
}
