package com.hamararojgar.model;

import java.time.Instant;

public class JobSeekerMasterDto extends ResponseDto{

	private Long id;
	private String contact_no; 
	private String name;
	private String father_name;
	private String expected_salary;
	private String experience;
	private String address;
	private String skills;
	private String current_location;
	private String preferred_location;
	private String availability;
	private String expected_compensation;
	private String message;
	private String adhaar_image_url;
	private String recording_url;
	private String profile_pic_url;
	private String status;
	private String email;
	private Boolean verified;
	private String deviceToken;
	
	private Instant entryDateTime;
	private Instant updateDateTime;
	private Boolean emailVerification;
	private Boolean accountVerification;
	private String whatsappNumber;
	private String whatsappVerification;	
	private Boolean mobileVerification;
	private Instant registredDateTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getContact() {
		return contact_no;
	}
	public void setContact(String contact) {
		this.contact_no = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getExpected_salary() {
		return expected_salary;
	}
	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getCurrent_location() {
		return current_location;
	}
	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}
	public String getPreferred_location() {
		return preferred_location;
	}
	public void setPreferred_location(String preferred_location) {
		this.preferred_location = preferred_location;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getExpected_compensation() {
		return expected_compensation;
	}
	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAdhaar_image_url() {
		return adhaar_image_url;
	}
	public void setAdhaar_image_url(String adhaar_image_url) {
		this.adhaar_image_url = adhaar_image_url;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	public String getProfile_pic_url() {
		return profile_pic_url;
	}
	public void setProfile_pic_url(String profile_pic_url) {
		this.profile_pic_url = profile_pic_url;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Boolean getVerified() {
		return verified;
	}
	public void setVerified(Boolean verified) {
		this.verified = verified;
	}
	public String getDeviceToken() {
		return deviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public Instant getEntryDateTime() {
		return entryDateTime;
	}
	public void setEntryDateTime(Instant entryDateTime) {
		this.entryDateTime = entryDateTime;
	}
	public Instant getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Instant updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public Boolean getEmailVerification() {
		return emailVerification;
	}
	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}
	public Boolean getAccountVerification() {
		return accountVerification;
	}
	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}
	public String getWhatsappNumber() {
		return whatsappNumber;
	}
	public void setWhatsappNumber(String whatsappNumber) {
		this.whatsappNumber = whatsappNumber;
	}
	public String getWhatsappVerification() {
		return whatsappVerification;
	}
	public void setWhatsappVerification(String whatsappVerification) {
		this.whatsappVerification = whatsappVerification;
	}
	public Boolean getMobileVerification() {
		return mobileVerification;
	}
	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}
	public Instant getRegistredDateTime() {
		return registredDateTime;
	}

	public void setRegistredDateTime(Instant registredDateTime) {
		this.registredDateTime = registredDateTime;
	}
	@Override
	public String toString() {
		return "JobSeekerMasterDto [id=" + id + ", contact_no=" + contact_no + ", name=" + name + ", father_name="
				+ father_name + ", expected_salary=" + expected_salary + ", experience=" + experience + ", address="
				+ address + ", skills=" + skills + ", current_location=" + current_location + ", preferred_location="
				+ preferred_location + ", availability=" + availability + ", expected_compensation="
				+ expected_compensation + ", message=" + message + ", adhaar_image_url=" + adhaar_image_url
				+ ", recording_url=" + recording_url + ", profile_pic_url=" + profile_pic_url + ", status=" + status
				+ ", email=" + email + ", verified=" + verified + ", deviceToken=" + deviceToken + ", entryDateTime="
				+ entryDateTime + ", updateDateTime=" + updateDateTime + ", emailVerification=" + emailVerification
				+ ", accountVerification=" + accountVerification + ", whatsappNumber=" + whatsappNumber
				+ ", whatsappVerification=" + whatsappVerification + ", mobileVerification=" + mobileVerification + "]";
	}
	

}
