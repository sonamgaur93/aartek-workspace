package com.hamararojgar.model;

import java.time.Instant;
import java.util.Calendar;
import java.util.TimeZone;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mst_campaign")
@Entity(name = "MasterCampaign")
public class MasterCampaign extends CommonDBFields{
	
	
	public String buildCampaignCode() {
		TimeZone timeZone = TimeZone.getTimeZone("UTC");
		Calendar calendar= Calendar.getInstance(timeZone );
		return String.valueOf(calendar.getTimeInMillis());
	}
	
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public String getCampaignDescription() {
		return campaignDescription;
	}
	public void setCampaignDescription(String campaignDescription) {
		this.campaignDescription = campaignDescription;
	}
	public Integer getCampaignType() {
		return campaignType;
	}
	public void setCampaignType(Integer campaignType) {
		this.campaignType = campaignType;
	}
	
	public Instant getCampaignEndDate() {
		return campaignEndDate;
	}
	public void setCampaignEndDate(Instant campaignEndDate) {
		this.campaignEndDate = campaignEndDate;
	}
	public String getCampaignStatus() {
		return campaignStatus;
	}
	public void setCampaignStatus(String campaignStatus) {
		this.campaignStatus = campaignStatus;
	}
	
	
	


	
	public Instant getCampaignStartDate() {
		return campaignStartDate;
	}


	public void setCampaignStartDate(Instant campaignStartDate) {
		this.campaignStartDate = campaignStartDate;
	}


	


	
	
	@Override
	public String toString() {
		return "MasterCampaign [campaignCode=" + campaignCode + ", campaignName=" + campaignName
				+ ", campaignDescription=" + campaignDescription + ", campaignType=" + campaignType
				+ ", campaignStartDate=" + campaignStartDate + ", campaignEndDate=" + campaignEndDate
				+ ", campaignStatus=" + campaignStatus + ", getEntryDateTime()=" + getEntryDateTime()
				+ ", getUpdateDateTime()=" + getUpdateDateTime() + ", getId()=" + getId() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}







	private String campaignCode;
	private String campaignName;
	private String campaignDescription;
	private Integer campaignType;
	private Instant campaignStartDate;
	private Instant campaignEndDate;
	private String campaignStatus;

}
