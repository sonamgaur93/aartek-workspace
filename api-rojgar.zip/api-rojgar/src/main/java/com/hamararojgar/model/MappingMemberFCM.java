package com.hamararojgar.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name = "mapping_member_fcm")
@Entity
public class MappingMemberFCM extends CommonDBFields{
	
	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getMemberCode() {
		return memberCode;
	}

	public void setMemberCode(String memberCode) {
		this.memberCode = memberCode;
	}

	public String getMemberType() {
		return memberType;
	}

	public void setMemberType(String memberType) {
		this.memberType = memberType;
	}

	@Column(name="vc_fcm_token")
	private String deviceToken;
	
	@Column(name="vc_member_code")
	private String memberCode;
	
	@Column(name="vc_member_type")
	private String memberType;
	
}