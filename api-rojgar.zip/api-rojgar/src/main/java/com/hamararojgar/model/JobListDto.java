package com.hamararojgar.model;

import java.util.Arrays;

public class JobListDto {

	private String name;
	private String location;
	private String skills;
	
	private String[] locations;
	private Integer [] nSkills;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getLocations() {
		return locations;
	}
	public void setLocations(String[] locations) {
		this.locations = locations;
	}
	public Integer[] getnSkills() {
		return nSkills;
	}
	public void setnSkills(Integer[] nSkills) {
		this.nSkills = nSkills;
	}
	@Override
	public String toString() {
		return "JobListDto [name=" + name + ", location=" + location + ", skills=" + skills + ", locations="
				+ Arrays.toString(locations) + ", nSkills=" + Arrays.toString(nSkills) + "]";
	}	
	
	
	
}