package com.hamararojgar.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.util.StreamUtils;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.EmployerLoginRequestDto;
import com.hamararojgar.dto.LeadDto;
import com.hamararojgar.dto.LeadListReqDto;
import com.hamararojgar.dto.LeadListResponseDto;
import com.hamararojgar.dto.PublishMultiLeadRequestDto;
import com.hamararojgar.dto.PublishMultiLeadResponseDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.model.CommentMaster;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerSkillMap;
import com.hamararojgar.model.LeadMaster;
import com.hamararojgar.model.LeadSkillMap;
import com.hamararojgar.model.LeadStageMaster;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.repo.CommentMasterRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.JobSeekerSkillMapRepo;
import com.hamararojgar.repo.LeadMasterRepo;
import com.hamararojgar.repo.LeadQueryMapper;
import com.hamararojgar.repo.LeadSkillMapRepo;
import com.hamararojgar.repo.LeadStageMasterRepo;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.serviceimpl.AWSS3Service;
import com.hamararojgar.serviceimpl.ServiceLeadMaster;
import com.hamararojgar.util.AssetType;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/rasset")
public class ControllerAssets {

	private static final Logger log = LogManager.getLogger(ControllerAssets.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	private RojgarConstantProperties constantProperties;
	
	@Autowired
	private Util util;
	
	@Autowired
	AWSS3Service awss3Service;
	


	@RequestMapping(value = "/getLeadProfile/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getLeadProfile(@PathVariable String id, HttpServletResponse response) throws IOException {
		
		try {
			InputStream targetStream = util.retrieveAsset(id, AssetType.LEAD_PROFILE);
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			StreamUtils.copy(targetStream, response.getOutputStream());
		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}

	
	@RequestMapping(value = "/getLeadRecording/{id}", method = RequestMethod.GET)
	public void getLeadRecording(@PathVariable String id, HttpServletResponse response) throws IOException {
		try {
			InputStream targetStream = util.retrieveAsset(id, AssetType.LEAD_RECORDING);
			response.setContentType("audio/mpeg");
			StreamUtils.copy(targetStream, response.getOutputStream());
		} catch (Exception e) {
			log.info("Exception in getRecording Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getAdminProfile/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getAdminProfile(@PathVariable String id, HttpServletResponse response) throws IOException {

		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = util.retrieveAsset(id, AssetType.ADMIN_PROFILE);
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getProfilePic/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getProfilePic(@PathVariable String id, HttpServletResponse response) throws IOException {

		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketProfile(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderProfile() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}

	}
	
	@RequestMapping(value = "/getAdhaarImage/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getAdhaarImage(@PathVariable String id, HttpServletResponse response) throws IOException {
		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketAdhar(), id).getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderAdhar() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getRecording/{id}", method = RequestMethod.GET)
	public void getRecording(@PathVariable String id, HttpServletResponse response) throws IOException {
		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketRecording(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderRecording() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getEmployerRecording/{id}", method = RequestMethod.GET)
	public void getEmployerRecording(@PathVariable String id, HttpServletResponse response) throws IOException {

		try {
			response.setContentType("audio/mpeg");
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketCompanyRecording(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderCompanyRecording() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getJobRecording/{id}", method = RequestMethod.GET)
	public void getJobRecording(@PathVariable String id, HttpServletResponse response) throws IOException {

		try {
			response.setContentType("audio/mpeg");
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketJobRecording(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderJobRecording() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getEmployerImage/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getEmployerImage(@PathVariable String id, HttpServletResponse response) throws IOException {
		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketCompanyImage(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderCompanyImage() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getChatImage/{id}", method = RequestMethod.GET)
	public void getChatImage(@PathVariable String id, HttpServletResponse response) throws IOException {

		try {
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				response.setContentType(MediaType.IMAGE_JPEG_VALUE);
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketChatFile(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderChatFile() + id);
				String extension = FilenameUtils.getExtension(id);
				if (extension.equalsIgnoreCase("pdf")) {
					response.setContentType(MediaType.APPLICATION_PDF_VALUE);
				} else if (extension.equalsIgnoreCase("doc")) {
					response.setContentType("application/msword");
				} else if (extension.equalsIgnoreCase("docx")) {
					response.setContentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
				} else if (extension.equalsIgnoreCase("csv")) {
					response.setContentType("text/csv");
				} else {
					response.setContentType(MediaType.IMAGE_JPEG_VALUE);
				}
				// response.setContentType(MediaType.IMAGE_JPEG_VALUE);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/getAdBanner/{id}", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public void getAdBanner(@PathVariable String id, HttpServletResponse response) throws IOException {
		try {
			response.setContentType(MediaType.IMAGE_JPEG_VALUE);
			InputStream targetStream = null;
			if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
				targetStream = awss3Service.downloadFile(constantProperties.getS3bucketAdImages(), id)
						.getObjectContent();
			} else {
				File imgFile = new File(constantProperties.getUploadFolderAd() + id);
				targetStream = new FileInputStream(imgFile);
			}
			StreamUtils.copy(targetStream, response.getOutputStream());

		} catch (Exception e) {
			log.info("Exception in getChatImage Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
}