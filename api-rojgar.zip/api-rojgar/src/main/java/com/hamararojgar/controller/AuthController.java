package com.hamararojgar.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.LoginRequest;
import com.hamararojgar.payload.response.JwtResponse;
import com.hamararojgar.payload.response.MessageResponse;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.util.JwtUtils;
import com.hamararojgar.util.Util;

@CrossOrigin(origins= "*")
@RestController
@RequestMapping("/api/auth/")
public class AuthController {
	
	private static final Logger log = LogManager.getLogger(AuthController.class);
	
	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	PasswordEncoder encoder;

	@Autowired
	JwtUtils jwtUtils;
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	Util util;


	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
		try {
			String email = loginRequest.getEmail().toLowerCase();
			String password = loginRequest.getPassword();
			if(email!=null && password!=null && !email.equalsIgnoreCase("") && !password.equalsIgnoreCase("")){
				//password = Util.encryptPassword(password);
				log.info("password" + password);

				//User user = userRepo.findByEmailAndPasswords(email, password);
				User user = userRepo.findByEmail(email);
				log.info("user:: " + user);
				log.info("validateUserPassword:: " + util.validateUserPassword(password, user.getPassword()));
				if(user!=null && util.validateUserPassword(password, user.getPassword())){
					password = user.getPassword();
					if(user.getStatus().equalsIgnoreCase("ACTIVE")){
						String role = user.getRole();
						String username = user.getUsername();
						try {
							Authentication authentication = authenticationManager
									.authenticate(new UsernamePasswordAuthenticationToken(email, password));
							SecurityContextHolder.getContext().setAuthentication(authentication);
							String jwt = jwtUtils.generateJwtToken(authentication);
							return ResponseEntity.ok(new JwtResponse(jwt,email,password,role,username,user.getProfilePicUrl(),user.getId().intValue()));
						} catch (AuthenticationException e) {
							e.printStackTrace();
							return ResponseEntity.badRequest().body(new MessageResponse("Failed to Login."));
						}
					}else{
						return ResponseEntity.badRequest().body(new MessageResponse("Account Blocked By Administrator."));
					}
				}
			}
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(new MessageResponse("Failed to Login."));
		}
		return ResponseEntity.badRequest().body(new MessageResponse("Invalid Credentials"));
	}

	
	
}
