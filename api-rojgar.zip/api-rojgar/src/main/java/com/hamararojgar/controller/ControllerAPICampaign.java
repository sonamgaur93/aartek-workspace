package com.hamararojgar.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.payload.request.RequestCampaign;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.serviceimpl.ServiceCampaign;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/api-campaign")
public class ControllerAPICampaign {
	
	private static final Logger log = LogManager.getLogger(ControllerAPICampaign.class);

	@Autowired
	private ServiceCampaign serviceCampaign;

	@Autowired
	Util util;

	
	@PostMapping("/campaign")
	public @ResponseBody ResponseHamaraRojgar createCampaign(@RequestBody RequestCampaign requestCampaign) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.createCampaign(requestCampaign);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	
	
	
	@GetMapping("/campaign")
	public @ResponseBody ResponseHamaraRojgar getCampaign(@RequestParam (required = false) Map<String, String> parameters) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.getCampaign(parameters);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@GetMapping("/campaign/{campaignCode}")
	public @ResponseBody ResponseHamaraRojgar getCampaign(@PathVariable(value = "campaignCode") String campaignCode) {
		int httpStatusValue = -1;
		//log.info("/campaign/{campaignCode}" +campaignCode );
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.getCampaign(campaignCode);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@GetMapping("/campaign/leads/{campaignCode}")
	public @ResponseBody ResponseHamaraRojgar getLeadsByCampaign(@PathVariable(value = "campaignCode") String campaignCode) {
		int httpStatusValue = -1;
		log.info("/campaign/leads/{campaignCode}");
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.getLeadsByCampaign(campaignCode);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@GetMapping("/campaign/members/{campaignCode}")
	public @ResponseBody ResponseHamaraRojgar getMembersByCampaign(@PathVariable(value = "campaignCode") String campaignCode) {
		log.info("/campaign/members/{campaignCode}");
		int httpStatusValue = -1;
		
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
//		ResponseCampaign responseCampaign = serviceCampaign.getLeadsByCampaign(campaignCode);
		ResponseCampaign responseCampaign = serviceCampaign.getMembersByCampaign(campaignCode);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	
	@GetMapping("/campaigns/member/{memberId}")
	public @ResponseBody ResponseHamaraRojgar getCampaignByUserId(@PathVariable(value = "memberId") String memberId) {
		log.info("/campaign/members/{campaignCode}");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.getCampaignByMemberId(memberId);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@PutMapping("/campaign")
	public @ResponseBody ResponseHamaraRojgar updateCampaign(@RequestBody RequestCampaign requestCampaign) {
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseCampaign responseCampaign = serviceCampaign.updateCampaign(requestCampaign);
		if (null != responseCampaign) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(responseCampaign);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
}