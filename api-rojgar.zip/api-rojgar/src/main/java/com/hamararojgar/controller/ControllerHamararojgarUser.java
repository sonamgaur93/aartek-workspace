package com.hamararojgar.controller;


import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseHamararojgarContent;
import com.hamararojgar.serviceimpl.MasterDataService;
import com.hamararojgar.util.Util;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/api-user")
public class ControllerHamararojgarUser {
	
	private static final Logger log = LogManager.getLogger(ControllerHamararojgarUser.class);
	
	@Autowired
	MasterDataService masterDataService;
	
	@Autowired
	Util util;

	@GetMapping("/getusers")
	public @ResponseBody ResponseHamaraRojgar getUsers(@RequestParam (required = false) Map<String, String> parameters) {
		log.info("Called api-users  getUsers");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseHamararojgarContent content = masterDataService.getUsers(parameters);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
	
	@GetMapping("/getuser/{id}")
	public @ResponseBody ResponseHamaraRojgar getUser(@PathVariable String id) {
		log.info("Called api-users  getUsers");
		int httpStatusValue = -1;
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		
		ResponseHamararojgarContent content = masterDataService.getUser(id);
		if (null != content) {
			httpStatusValue = HttpStatus.OK.value();
			responseHamaraRojgar.setContent(content);
		} else {
			httpStatusValue = HttpStatus.NO_CONTENT.value();
		}
		responseHamaraRojgar.setResponseCode(util.buildResponseStatus(httpStatusValue));
		return responseHamaraRojgar;
	}
}
