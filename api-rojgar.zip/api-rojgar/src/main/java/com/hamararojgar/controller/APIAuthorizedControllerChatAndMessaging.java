package com.hamararojgar.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseJobSeeker;
import com.hamararojgar.serviceimpl.ServiceJobSeeker;

@Controller
@CrossOrigin("*")
public class APIAuthorizedControllerChatAndMessaging {

	private static final Logger log = LogManager.getLogger(APIAuthorizedControllerChatAndMessaging.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	
}
