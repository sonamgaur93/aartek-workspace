package com.hamararojgar.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.AddProfileResponseDto;
import com.hamararojgar.dto.AddUpdateJobDto;
import com.hamararojgar.dto.AddUpdateJobResponseDto;
import com.hamararojgar.dto.AppliedCandidateDto;
import com.hamararojgar.dto.BannerDTO;
import com.hamararojgar.dto.ChangePasswordRequestDto;
import com.hamararojgar.dto.ChatReadDto;
import com.hamararojgar.dto.DeleteImageDto;
import com.hamararojgar.dto.EmployerJobListDto;
import com.hamararojgar.dto.EmployerLoginRequestDto;
import com.hamararojgar.dto.InviteForJobDto;
import com.hamararojgar.dto.JobListToInviteDto;
import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.dto.JobSeekerListByJobDto;
import com.hamararojgar.dto.JobSeekerListResponseDto;
import com.hamararojgar.dto.NotificationDto;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.dto.SaveJobChat;
import com.hamararojgar.dto.SendOtpDto;
import com.hamararojgar.dto.UpdateDeviceTokenDTO;
import com.hamararojgar.dto.UpdateProfileEmployerDto;
import com.hamararojgar.dto.VerificatioRequestDto;
import com.hamararojgar.dto.VerificatioResponseDto;
import com.hamararojgar.model.AddJobSeekerDto;
import com.hamararojgar.model.AdvertisementsMaster;
import com.hamararojgar.model.AppliedJobChatMaster;
import com.hamararojgar.model.ApplyJobDto;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobListDto;
import com.hamararojgar.model.JobListResponseDto;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerIdDto;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerMasterDto;
import com.hamararojgar.model.LocationListDto;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.model.UserOtp;
import com.hamararojgar.model.VerifyUserDto;
import com.hamararojgar.repo.AdvertisementsMasterRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.UserOtpRepo;
import com.hamararojgar.serviceimpl.JobSeekerService;
import com.hamararojgar.serviceimpl.MailSenderService;
import com.hamararojgar.serviceimpl.ServiceMappingMemberFCM;
import com.hamararojgar.util.JwtUtils;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.RojgarPasswordGenerator;
import com.hamararojgar.util.SmsSender;
import com.hamararojgar.util.SortingList;
import com.hamararojgar.util.Util;

@Controller
public class JobSeekerController {

	private static final Logger log = LogManager.getLogger(JobSeekerController.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	JwtUtils jwtUtils;

	@Autowired
	private JobSeekerService rozgarService;

	@Autowired
	private RojgarConstantProperties constantProperties;

	@Autowired
	EmployerRepo employerRepo;

	@Autowired
	JobMasterRepo jobMasterRepo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	AdvertisementsMasterRepo advertisementsMasterRepo;

	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	@Autowired
	MailSenderService mailSenderService;

	@Autowired
	UserOtpRepo userOtpRepo;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	PasswordEncoder encoder;
	
	@Autowired
	Util util;
	
	@Autowired
	ServiceMappingMemberFCM serviceMappingMemberFCM;

	@RequestMapping(value = "/api/addBanner", method = RequestMethod.GET)
	public @ResponseBody BannerDTO addBanner() {
		BannerDTO dto = new BannerDTO();
		try {
			List<AdvertisementsMaster> adList = advertisementsMasterRepo.findByStatus("ACTIVE");
			/*
			 * String imageName = rozgarService.getRandomBannerImage();
			 * if(!imageName.equalsIgnoreCase("")){
			 * dto.setBannerUrl(baseUrlImage+imageName); }else{ dto.setBannerUrl(imageName);
			 * }
			 */
			List<String> bannerList = new ArrayList<>();
			for (AdvertisementsMaster ad : adList) {
				bannerList.add(constantProperties.getBaseUrlImage() + ad.getImageUrl());
			}
			dto.setBannerList(bannerList);
			dto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			dto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			dto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			dto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getSkills Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return dto;
	}

	

	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;



	@RequestMapping(value = "/api/addEditProfile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<AddProfileResponseDto> addEditProfile(
			@ModelAttribute AddJobSeekerDto addJobSeekerDto, HttpServletRequest request, Errors errors) {
		AddProfileResponseDto responseDTO = new AddProfileResponseDto();
		reqLog.info("Got Add Edit Request :{}", addJobSeekerDto);
		try {
			if (addJobSeekerDto.getJob_seeker_id() != 0) {
				JobSeekerMaster jm = null;
				//jm = jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(), true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(addJobSeekerDto.getContact_no(), true);
				if (jm != null) {
					if (jm.getId() != addJobSeekerDto.getJob_seeker_id()) {
						responseDTO.setResponseCode("9999");
						responseDTO.setResponseDescription("Mobile Number is already Verifed with another user in db");
						return new ResponseEntity<>(responseDTO, HttpStatus.OK);
					}
				}
			}

			int id = rozgarService.addEditProfile(addJobSeekerDto);
			if (id > 0) {
				serviceMappingMemberFCM.createMappingMemberFCM("SEEKER", String.valueOf(id),
						addJobSeekerDto.getDeviceToken());
				responseDTO.setJobSeekerId(id);
				Optional<JobSeekerMaster> js = rozgarService.getJobSeekerProfileDetails((long) id);
				if (js.isPresent()) {
					ObjectMapper mapper = new ObjectMapper();
					JobSeekerMasterDto jobSeekerMasterDto = mapper.convertValue(js.get(), JobSeekerMasterDto.class);
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
					responseDTO.setJobSeeker(jobSeekerMasterDto);
				}
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else if (id == -1) {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Mobile Number Already Exist With Another User.");
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addEditProfile Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	

	@RequestMapping(value = "/api/getJobList", method = RequestMethod.POST)
	public @ResponseBody JobListResponseDto getJobList(@RequestBody JobListDto jobListDto) {
		JobListResponseDto jobListResponseDto = new JobListResponseDto();
		try {
			List<JobMasterDto> jobList = rozgarService.getJobList(jobListDto);
			if (jobList != null) {
				for (JobMasterDto jobMasterDto : jobList) {
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				}
				jobListResponseDto.setJobList(jobList);
				jobListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobListResponseDto;
	}
/*
	@RequestMapping(value = "/api/getJobS", method = RequestMethod.POST)
	public @ResponseBody JobListResponseDto getJobs(@RequestBody JobListDto jobListDto) {
		JobListResponseDto jobListResponseDto = new JobListResponseDto();
		try {
			List<JobMasterDto> jobList = rozgarService.getJobs(jobListDto);
			if (jobList != null) {
				for (JobMasterDto jobMasterDto : jobList) {
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				}
				jobListResponseDto.setJobList(jobList);
				jobListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobListResponseDto;
	}
*/

	/**
	 * Employer's API's Started
	 * 
	 * @author Sumit Sharma
	 *
	 */

	@RequestMapping(value = "/api/getEmployerDetails/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployerLoginResponseDto getEmployerDetails(@PathVariable Long id) {
		EmployerLoginResponseDto responseDTO = new EmployerLoginResponseDto();
		try {
			Optional<Employer> employerE = employerRepo.findById(id);
			if (employerE.isPresent()) {
				responseDTO.setEmployer(employerE.get());
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getEmployerDetails Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	public String randomPassword(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	@RequestMapping(value = "/api/getJobSeekerList", method = RequestMethod.POST)
	public @ResponseBody JobSeekerListResponseDto getJobSeekerList(@RequestBody JobListDto jobListDto) {
		JobSeekerListResponseDto jobSeekerListResponseDto = new JobSeekerListResponseDto();
		try {
			List<JobSeekerMasterDto> jobSeekerList = rozgarService.getJobSeekerList(jobListDto);
			if (jobSeekerList != null) {
				for (JobSeekerMasterDto jobSeekerMasterDto : jobSeekerList) {
					jobSeekerMasterDto.setSkills(rozgarService.getSkillStringByJobSeekerId(jobSeekerMasterDto.getId()));
				}
				jobSeekerListResponseDto.setJobSeekerList(jobSeekerList);
				jobSeekerListResponseDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobSeekerListResponseDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			}
		} catch (Exception e) {
			jobSeekerListResponseDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListResponseDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobSeekerList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListResponseDto;
	}

	@RequestMapping(value = "/api/addUpdateJob", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<AddUpdateJobResponseDto> addUpdateJob(
			@ModelAttribute AddUpdateJobDto addUpdateJobDto, HttpServletRequest request, Errors errors) {
		AddUpdateJobResponseDto responseDTO = new AddUpdateJobResponseDto();
		try {
			JobMaster jobMaster = rozgarService.addUpdateJob(addUpdateJobDto);
			if (jobMaster != null) {
				responseDTO.setJobMaster(jobMaster);
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in addUpdateJob Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return new ResponseEntity<>(responseDTO, HttpStatus.OK);
	}

	@RequestMapping(value = "/api/getJobListToInviteByCandidate", method = RequestMethod.POST)
	public @ResponseBody EmployerJobListDto getJobListToInviteByCandidate(@RequestBody JobListToInviteDto dto) {
		EmployerJobListDto responseDTO = new EmployerJobListDto();
		try {
			List<JobMaster> jobList = jobMasterRepo.findByEmployerId(String.valueOf(dto.getEmployer_id()));
			List<JobMasterDto> jobListreq = new ArrayList<JobMasterDto>();
			for (JobMaster jm : jobList) {
				ApplyJobDto applyJobDto = new ApplyJobDto();
				applyJobDto.setJob_id(jm.getId().intValue());
				applyJobDto.setJob_seeker_id(dto.getJob_seeker_id());
				String result = rozgarService.checkJobApplied(applyJobDto);
				if (result.equalsIgnoreCase("Not Applied for this Job")) {
					ObjectMapper mapper = new ObjectMapper();
					JobMasterDto jobMasterDto = mapper.convertValue(jm, JobMasterDto.class);
					jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
					jobListreq.add(jobMasterDto);
				}
			}
			responseDTO.setJobList(jobListreq);
			responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getJobListToInviteByCandidate Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	@RequestMapping(value = "/api/getEmployerJobList/{id}", method = RequestMethod.GET)
	public @ResponseBody EmployerJobListDto getEmployerJobList(@PathVariable String id) {
		EmployerJobListDto employerJobListDto = new EmployerJobListDto();
		try {
			List<JobMaster> jobList = jobMasterRepo.findByEmployerId(id);
			List<JobMasterDto> jobListreq = new ArrayList<JobMasterDto>();
			for (JobMaster jm : jobList) {
				ObjectMapper mapper = new ObjectMapper();
				JobMasterDto jobMasterDto = mapper.convertValue(jm, JobMasterDto.class);
				jobMasterDto.setSkills(rozgarService.getSkillStringByJobId(jobMasterDto.getId()));
				jobListreq.add(jobMasterDto);
			}
			employerJobListDto.setJobList(jobListreq);
			employerJobListDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			employerJobListDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			employerJobListDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			employerJobListDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getEmployerJobList Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return employerJobListDto;
	}

	@RequestMapping(value = "/api/getContactedAppliedCandidatesByEmployerId/{id}", method = RequestMethod.GET)
	public @ResponseBody JobSeekerListByJobDto getContactedAppliedCandidatesByEmployerId(@PathVariable int id) {
		JobSeekerListByJobDto jobSeekerListByJobDto = new JobSeekerListByJobDto();
		try {
			List<AppliedCandidateDto> appliedCandidateChatList = new ArrayList<AppliedCandidateDto>();
			List<AppliedCandidateDto> appliedCandidateList = rozgarService.getAppliedCandidateListByEmployerId(id);
			if (appliedCandidateList != null) {
				List<AppliedCandidateDto> jobListFinal = new ArrayList<>();
				List<AppliedCandidateDto> jobListNoChat = new ArrayList<>();
				List<AppliedCandidateDto> jobListChat = new ArrayList<>();
				for (AppliedCandidateDto appliedCandidateDto : appliedCandidateList) {
					appliedCandidateDto.setSkills(
							rozgarService.getSkillStringByJobSeekerId((long) appliedCandidateDto.getJob_seeker_id()));
					int unreadCountJs = rozgarService
							.getUnreadMessageCountJobSeeker(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByJobSeeker(unreadCountJs);
					int unreadCountEmp = rozgarService
							.getUnreadMessageCountEmployer(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByEmployer(unreadCountEmp);
					boolean chatStarted = rozgarService.checkChatStatus(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setChatStarted(chatStarted);
					if (appliedCandidateDto.isChatStarted()) {
						Date lastMessageTime = rozgarService
								.getLastChatMessageTime(appliedCandidateDto.getAppliedJobId());
						if (lastMessageTime != null) {
							appliedCandidateDto.setLastMessageTime(lastMessageTime);
							jobListChat.add(appliedCandidateDto);
						} else {
							jobListNoChat.add(appliedCandidateDto);
						}
					}
				}
				jobListChat.sort(Comparator.comparing(AppliedCandidateDto::getLastMessageTime).reversed());
				jobListFinal.addAll(jobListChat);
				jobListFinal.addAll(jobListNoChat);
				jobSeekerListByJobDto.setAppliedCandidateList(jobListFinal);
			}
			jobSeekerListByJobDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			jobSeekerListByJobDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getAppliedCandidateListByJobId Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListByJobDto;
	}

	@RequestMapping(value = "/api/getAppliedCandidateListByJobId/{id}", method = RequestMethod.GET)
	public @ResponseBody JobSeekerListByJobDto getAppliedCandidateListByJobId(@PathVariable int id) {
		JobSeekerListByJobDto jobSeekerListByJobDto = new JobSeekerListByJobDto();
		try {
			List<AppliedCandidateDto> appliedCandidateList = rozgarService.getAppliedCandidateListByJobId(id);
			if (appliedCandidateList != null) {
				for (AppliedCandidateDto appliedCandidateDto : appliedCandidateList) {
					appliedCandidateDto.setSkills(
							rozgarService.getSkillStringByJobSeekerId((long) appliedCandidateDto.getJob_seeker_id()));
					int unreadCountJs = rozgarService
							.getUnreadMessageCountJobSeeker(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByJobSeeker(unreadCountJs);
					int unreadCountEmp = rozgarService
							.getUnreadMessageCountEmployer(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setUnreadMessagesByEmployer(unreadCountEmp);
					boolean chatStarted = rozgarService.checkChatStatus(appliedCandidateDto.getAppliedJobId());
					appliedCandidateDto.setChatStarted(chatStarted);
				}
				jobSeekerListByJobDto.setAppliedCandidateList(appliedCandidateList);
			}
			jobSeekerListByJobDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		} catch (Exception e) {
			jobSeekerListByJobDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobSeekerListByJobDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in getAppliedCandidateListByJobId Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobSeekerListByJobDto;
	}

	@RequestMapping(value = "/api/markJobAsFulfilled/{id}", method = RequestMethod.GET)
	public @ResponseBody JobMasterDto markJobAsFulfilled(@PathVariable int id) {
		JobMasterDto jobMasterDto = new JobMasterDto();
		try {
			rozgarService.markJobAsFulfilled(id);
			Optional<JobMaster> jobMaster = rozgarService.getJobDetails((long) id);
			if (jobMaster.isPresent()) {
				ObjectMapper mapper = new ObjectMapper();
				jobMasterDto = mapper.convertValue(jobMaster.get(), JobMasterDto.class);
				jobMasterDto.setSkills(rozgarService.getSkillStringByJobId((long) id));
				jobMasterDto.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			}
		} catch (Exception e) {
			jobMasterDto.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			jobMasterDto.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in markJobAsFulfilled Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return jobMasterDto;
	}

	@RequestMapping(value = "/api/changePassword", method = RequestMethod.POST)
	public @ResponseBody ResponseDTO changePassword(@RequestBody ChangePasswordRequestDto requestDto) {
		ResponseDTO responseDTO = new ResponseDTO();
		try {
			Optional<Employer> emp = employerRepo.findById((long) requestDto.getEmployer_id());
			if (emp.isPresent()) {
				Employer employer = emp.get();
				// if (employer.getPassword().equalsIgnoreCase(requestDto.getOld_password())) {
				if (util.validateUserPassword(requestDto.getOld_password(), employer.getPassword())) {
					if (requestDto.getNew_password() != null && !requestDto.getNew_password().equalsIgnoreCase("")) {
						jdbcTemplate.update(
								"update employer_master set password='" + encoder.encode(requestDto.getNew_password())
										+ "' where id=" + requestDto.getEmployer_id());
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Password Updated.");
					} else {
						responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
						responseDTO.setResponseDescription("New Password is Empty or Null.");
					}
				} else {
					responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
					responseDTO.setResponseDescription("Invalid Old Password.");
				}
			} else {
				responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
				responseDTO.setResponseDescription("Invalid Employer Id.");
			}
		} catch (Exception e) {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
			log.info("Exception in changePassword Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return responseDTO;
	}

	

	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */


	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */


	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */


	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */


	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */
	

	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */


	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */
	

	// getAdBanner
	/**
	 * images --- GET request to display image
	 *
	 * @param id       -- Image file name
	 *
	 * @param response
	 * @throws IOException
	 */
	

	

	@RequestMapping(value = "/api/updateDeviceToken", method = RequestMethod.PUT)
	public @ResponseBody ResponseDTO updateDeviceToken(@RequestBody UpdateDeviceTokenDTO updateDeviceTokenDTO) {
		ResponseDTO responseDTO = new ResponseDTO();

		try {
			log.info("/api/updateDeviceToken");
			Integer seekerId = rozgarService.updateDeviceToken(updateDeviceTokenDTO);
			if (0 < seekerId) {
				serviceMappingMemberFCM.createMappingMemberFCM(updateDeviceTokenDTO.getUserType(), seekerId.toString(),
						updateDeviceTokenDTO.getDeviceToken());
				responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
				responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
			} else {
				responseDTO.setResponseCode("2222");
				responseDTO.setResponseDescription("Unable to update the token");
			}

		} catch (Exception e) {
			log.info("Exception in getVerificationStatus Method : " + e.getMessage());
			exceptionLog.error(e.getMessage(), e);
			e.printStackTrace();
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription(ServerConstants.FAILURERESPONSEDESC);
		}
		return responseDTO;
	}
}
