package com.hamararojgar.controller;



import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.payload.response.ResponseHamaraRojgar;
import com.hamararojgar.payload.response.ResponseJobSeeker;
import com.hamararojgar.serviceimpl.ServiceJobSeeker;

@Controller
@CrossOrigin("*")
public class APIAuthorizedControllerJobSeeker {

	private static final Logger log = LogManager.getLogger(APIAuthorizedControllerJobSeeker.class);
	private static final Logger reqLog = LogManager.getLogger("request-log");
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	ServiceJobSeeker serviceJobSeeker;
	
	@GetMapping("/seeker/{id}/jobs")
	public @ResponseBody ResponseHamaraRojgar getCampaign(@PathVariable(value = "id") String seekerId, 
			@RequestParam(required = false) Map<String, String> searchParameters) {
		ResponseHamaraRojgar responseHamaraRojgar = new ResponseHamaraRojgar();
		ResponseJobSeeker jobSeeker = serviceJobSeeker.getAppliedJobs(seekerId, searchParameters);
		responseHamaraRojgar.setContent(jobSeeker);
		responseHamaraRojgar.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
		responseHamaraRojgar.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
		return responseHamaraRojgar;
	} 
}
