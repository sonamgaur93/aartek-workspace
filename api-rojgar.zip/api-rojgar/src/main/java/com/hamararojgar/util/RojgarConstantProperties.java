package com.hamararojgar.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Configuration
public class RojgarConstantProperties {	
	
	public String getUploadFolderProfile() {
		return uploadFolderProfile;
	}

	public String getUploadFolderAdhar() {
		return uploadFolderAdhar;
	}

	public String getBaseURLProfile() {
		return baseURLProfile;
	}

	public String getBaseURLAdhar() {
		return baseURLAdhar;
	}

	public String getUploadFolderRecording() {
		return uploadFolderRecording;
	}

	public String getUploadFolderChatFile() {
		return uploadFolderChatFile;
	}

	public String getUploadFolderCompanyRecording() {
		return uploadFolderCompanyRecording;
	}

	public String getUploadFolderCompanyImage() {
		return uploadFolderCompanyImage;
	}

	public String getUploadFolderJobRecording() {
		return uploadFolderJobRecording;
	}

	public String getUploadFolderAd() {
		return uploadFolderAd;
	}

	public boolean isSendByGmail() {
		return sendByGmail;
	}

	public boolean isSendOtp() {
		return sendOtp;
	}

	public String getBaseUrlImage() {
		return baseUrlImage;
	}

	public String getBaseURLCompanyImage() {
		return baseURLCompanyImage;
	}

	public String getEmailTemplateOTPContect() {
		return emailTemplateOTPContect;
	}

	public String getEmailTemplateOTPSubject() {
		return emailTemplateOTPSubject;
	}

	public String getEmailTemplateForgotContect() {
		return emailTemplateForgotContect;
	}

	public String getEmailTemplateForgotSubject() {
		return emailTemplateForgotSubject;
	}

	public String getAssetStorage() {
		return assetStorage;
	}

	public String getUploadFolderAdminProfile() {
		return uploadFolderAdminProfile;
	}
	

	public String getBaseURLJobRecording() {
		return baseURLJobRecording;
	}

	public String getBaseURLRecording() {
		return baseURLRecording;
	}

	public String getBaseURLCompanyRecording() {
		return baseURLCompanyRecording;
	}

	public String getBaseURLChatImages() {
		return baseURLChatImages;
	}
	
	public String getSmtpPort() {
		return smtpPort;
	}

	public String getSmtpHost() {
		return smtpHost;
	}

	public String getSmtpFromEmail() {
		return smtpFromEmail;
	}

	public String getSmtpUserName() {
		return smtpUserName;
	}

	public String getSmtpPassword() {
		return smtpPassword;
	}

	public String getGmailFrom() {
		return gmailFrom;
	}

	public String getS3bucketAdminProfile() {
		return s3bucketAdminProfile;
	}
	
	

	public String getS3bucketProfile() {
		return s3bucketProfile;
	}

	public String getS3bucketAdhar() {
		return s3bucketAdhar;
	}

	public String getS3bucketRecording() {
		return s3bucketRecording;
	}

	public String getS3bucketChatFile() {
		return s3bucketChatFile;
	}

	public String getS3bucketCompanyRecording() {
		return s3bucketCompanyRecording;
	}

	public String getS3bucketCompanyImage() {
		return s3bucketCompanyImage;
	}

	public String getS3bucketJobRecording() {
		return s3bucketJobRecording;
	}

	public String getS3bucketAdImages() {
		return s3bucketAdImages;
	}


	
	

	public String getBaseURLLeadProfile() {
		return baseURLLeadProfile;
	}

	public String getBaseURLLeadRecording() {
		return baseURLLeadRecording;
	}

	public String getUploadFolderLeadProfile() {
		return uploadFolderLeadProfile;
	}

	public String getUploadFolderLeadRecording() {
		return uploadFolderLeadRecording;
	}

	public String getS3bucketLeadRecording() {
		return s3bucketLeadRecording;
	}

	public String getS3bucketLeadImages() {
		return s3bucketLeadImages;
	}

	public String getBaseURLAdminProfile() {
		return baseURLAdminProfile;
	}


	@Value("${upload.dir.path.admin.profile}")
	private String uploadFolderAdminProfile;
	
	@Value("${upload.dir.path.profile}")
	private String uploadFolderProfile;
	
	@Value("${upload.dir.path.adhaar}")
	private String uploadFolderAdhar;

	@Value("${upload.dir.path.recording}")
	private String uploadFolderRecording;

	@Value("${upload.dir.path.chat.file}")
	private String uploadFolderChatFile;

	@Value("${upload.dir.path.company.recording}")
	private String uploadFolderCompanyRecording;

	@Value("${upload.dir.path.company.image}")
	private String uploadFolderCompanyImage;

	@Value("${upload.dir.path.job.recording}")
	private String uploadFolderJobRecording;
	
	@Value("${upload.dir.path.ad.images}")
	private String uploadFolderAd;
	
	@Value("${app.variables.send.by.gmail}")
	private boolean sendByGmail;

	@Value("${app.variables.send.otp.sms}")
	private boolean sendOtp;
	
	@Value("${app.variables.email.template.otp.content}")
	private String emailTemplateOTPContect;
	
	@Value("${app.variables.email.template.otp.subject}")
	private String emailTemplateOTPSubject;
	
	@Value("${app.variables.email.template.forgotpassword.content}")
	private String emailTemplateForgotContect;
	
	@Value("${app.variables.email.template.forgotpassword.subject}")
	private String emailTemplateForgotSubject;
	
	@Value("${asset_storage}")
	private String assetStorage;
	
	@Value("${base.url.job.recording}")
	private String baseURLJobRecording;
	
	@Value("${base.url.profile}")
	private String baseURLProfile;
	
	@Value("${base.url.adhaar}")
	private String baseURLAdhar;
	
	@Value("${ad.images.base.url}")
	private String baseUrlImage;
	
	@Value("${base.url.company.image}")
	private String baseURLCompanyImage;
	
	@Value("${base.url.recording}")
	private String baseURLRecording;
	
	@Value("${base.url.company.recording}")
	private String baseURLCompanyRecording;
	
	@Value("${base.url.chatimages}")
	private String baseURLChatImages;
	
	@Value("${app.variables.smtp.port}")
	private String smtpPort;

	@Value("${app.variables.smtp.host}")
	private String smtpHost;
	
	@Value("${app.variables.smtp.from.email}")
	private String smtpFromEmail;
	
	@Value("${app.variables.smtp.username}")
	private String smtpUserName;
	
	@Value("${app.variables.smtp.password}")
	private String smtpPassword;
	
	@Value("${spring.mail.username}")
	private String gmailFrom;
	
	@Value("${aws.s3.bucket.admin.profile}")
	private String s3bucketAdminProfile;

	@Value("${aws.s3.bucket.profile}")
	private String s3bucketProfile;
	
	@Value("${aws.s3.bucket.adhaar}")
	private String s3bucketAdhar;
	
	@Value("${aws.s3.bucket.recording}")
	private String s3bucketRecording;
	
	@Value("${aws.s3.bucket.chat.file}")
	private String s3bucketChatFile;
	
	@Value("${aws.s3.bucket.company.recording}")
	private String s3bucketCompanyRecording;
	
	@Value("${aws.s3.bucket.company.image}")
	private String s3bucketCompanyImage;
	
	@Value("${aws.s3.bucket.job.recording}")
	private String s3bucketJobRecording;
	
	@Value("${aws.s3.bucket.ad.images}")
	private String s3bucketAdImages;	
	
	
	@Value("${base.url.profile.lead}")
	private String baseURLLeadProfile;
	
	@Value("${base.url.recording.lead}")
	private String baseURLLeadRecording;
	
	@Value("${upload.dir.path.profile.lead}")
	private String uploadFolderLeadProfile;
	
	@Value("${upload.dir.path.recording.lead}")
	private String uploadFolderLeadRecording;
	
	@Value("${aws.s3.bucket.lead.recording}")
	private String s3bucketLeadRecording;
	
	@Value("${aws.s3.bucket.lead.image}")
	private String s3bucketLeadImages;	
	
	@Value("${base.url.admin.profile}")
	private String baseURLAdminProfile; 
}