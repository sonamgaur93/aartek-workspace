package com.hamararojgar.util;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

public class HamaraRojgarTest {

	public static void main(String[] args) {

		long epoch = System.currentTimeMillis() / 1000;
		System.out.println(epoch);
		// TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		Calendar cal_Two = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
		System.out.println(cal_Two);

		//cal_Two = Calendar.getInstance();
		System.out.println(cal_Two.getTime());

		TimeZone timeZone1 = TimeZone.getTimeZone("UTC");
		// Calendar calendar = new GregorianCalendar();
		Calendar calendar = Calendar.getInstance(timeZone1);
		// setting required timeZone

		System.out.println("Time :" + calendar.get(Calendar.HOUR_OF_DAY) + ":" + calendar.get(Calendar.MINUTE) + ":"
				+ calendar.get(Calendar.SECOND));
		System.out.println(calendar);
		System.out.println(calendar.getTimeInMillis());
		
		
		
        Date date =  calendar.getTime();
        
        System.out.println(date);
        
        OffsetDateTime offsetDateTime = OffsetDateTime.now( ZoneOffset.UTC );
        System.out.println(offsetDateTime);
        //Instant instant= Instant.EPOCH;
        Instant instant = Instant.now();
        System.out.println(instant);
        Date myDate = Date.from(instant);
        System.out.println("dddd::" + myDate);
        
        Instant instant1
        = Instant.ofEpochSecond(1627297409);

    // print result
    System.out.println("Instant: "
                       + instant1);
    myDate = Date.from(instant);
    System.out.println(myDate);
    setOperation();
	}
	
	
	private static void setOperation() {
		Set<Integer> test1 = new HashSet<Integer>();
		test1.add(1);
		test1.add(2);
		test1.add(3);

		Set<Integer> test2 = new HashSet<Integer>();
		test2.add(1);
		test2.add(2);
		test2.add(3);
		test2.add(4);
		test2.add(5);
		
		test2.removeAll(test1);
		System.out.println(test2);
		
	}

}
