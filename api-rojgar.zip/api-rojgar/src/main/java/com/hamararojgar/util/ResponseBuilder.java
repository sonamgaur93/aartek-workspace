package com.hamararojgar.util;

import org.springframework.stereotype.Component;

import com.hamararojgar.dto.JobMasterDto;
import com.hamararojgar.model.JobMaster;

@Component
public class ResponseBuilder {
	
	public JobMasterDto buildJobMasterDto(JobMaster jobMaster) {
		JobMasterDto jobMasterDto = null;
		
		if(null==jobMaster) {
			return jobMasterDto;
		}
		
		jobMasterDto = new JobMasterDto();
		jobMasterDto.setId(jobMaster.getId());
		jobMasterDto.setTitle(jobMaster.getTitle());
		jobMasterDto.setContact(jobMaster.getContact());
		jobMasterDto.setSkills(jobMaster.getSkills());
		jobMasterDto.setOpenings(jobMaster.getOpenings());
		jobMasterDto.setExperience(jobMaster.getExperience());
		jobMasterDto.setLocationId(jobMaster.getLocation());
		jobMasterDto.setLocation(jobMaster.getLocation());
		jobMasterDto.setComponsation(jobMaster.getComponsation());
		jobMasterDto.setJob_type(jobMaster.getJob_type());
		jobMasterDto.setAccomodation(jobMaster.getAccomodation());
		jobMasterDto.setFood(jobMaster.getFood());
		jobMasterDto.setLeave_policy(jobMaster.getLeave_policy());
		jobMasterDto.setStatus(jobMaster.getStatus());
		jobMasterDto.setDescription(jobMaster.getDescription());
		jobMasterDto.setRecording_url(jobMaster.getRecording_url());
		jobMasterDto.setJobTrackId(jobMaster.getJobTrackId());
		jobMasterDto.setEmployerId(jobMaster.getEmployerId());
		return jobMasterDto;
	}
}