package com.hamararojgar.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;

import com.hamararojgar.model.ResponseDto;

public class RojgarUtil {

	private static final Logger log = LogManager.getLogger(RojgarUtil.class);

	/**
	 * Description -- Static method to get Current Timestamp.
	 * 
	 * @return java.sql.Timestamp object with current Timestamp.
	 */
	public static java.sql.Timestamp getTimeStamp() {
		DateFormat gmtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		TimeZone gmtTime = TimeZone.getTimeZone("IST");
		gmtFormat.setTimeZone(gmtTime);
		Timestamp ts = Timestamp.valueOf(gmtFormat.format(new Date()));
		return ts;
	}

	/**
	 * Description -- Static method to get Browser Name from UserAgent of
	 * HttpServletRequest object.
	 * 
	 * @param userAgent
	 *            -- HttpServletRequest header.
	 * @return String -- Browser Name fetched from UserAgent of
	 *         HttpServletRequest object.
	 * @throws Exception
	 */
	private static String getBrowserName(String userAgent) throws Exception {
		String browserName = "";
		String[] browserdeatils = (String[]) null;
		if (userAgent.indexOf("Firefox") != -1) {
			browserdeatils = userAgent.split("Firefox/");
			browserName = "Mozilla FireFox " + browserdeatils[1];
		} else if (userAgent.indexOf("Chrome") != -1) {
			browserdeatils = userAgent.split("Chrome/");
			String[] br1 = browserdeatils[1].split(" ");
			browserName = "Google Chrome " + br1[0];
		} else if (userAgent.indexOf("MSIE") != -1) {
			browserdeatils = userAgent.split("MSIE ");
			String[] br1 = browserdeatils[1].split("; ");
			browserName = "Internet Explorer " + br1[0];
		} else if (userAgent.indexOf("Safari") != -1) {
			if (userAgent.indexOf("Maxthon") != -1) {
				String[] br1 = userAgent.split(" Maxthon/");
				browserName = "Maxthon " + br1[1];
			} else {
				browserdeatils = userAgent.split("Version/");
				String[] br1 = browserdeatils[1].split(" Safari/");
				browserName = "Apple Safari " + br1[0];
			}
		} else if (userAgent.indexOf("Opera Mobi") != -1) {
			browserdeatils = userAgent.split("Version/");
			browserName = "Opera Mini(Mobile) " + browserdeatils[1];
			if (browserdeatils.length > 1)
				browserName = "Opera " + browserdeatils[1];
			else
				browserName = "unknown";
		} else if (userAgent.indexOf("Opera") != -1) {
			browserdeatils = userAgent.split("Version/");
			if (browserdeatils.length > 1)
				browserName = "Opera " + browserdeatils[1];
			else
				browserName = "unknown";
		} else {
			browserName = "unknown";
		}
		return browserName;
	}

	/**
	 * Description -- Static method to get Operating System Name from UserAgent
	 * of HttpServletRequest object.
	 * 
	 * @param userAgent
	 *            -- HttpServletRequest header.
	 * @return String[] -- String array containing Operating System details.
	 */
	public static String[] getOS(String userAgent) {
		if (getBotName(userAgent) != null) {
			return getArray("Bot", "Bot", "Bot");
		}
		String[] res = (String[]) null;
		int pos;
		if ((pos = userAgent.indexOf("Windows Phone")) > -1) {
			res = getArray("windows phone", "windows phone", "windows phone" + getVersionNumber(userAgent, pos + 10));
		} else if ((pos = userAgent.indexOf("windows phone")) > -1) {
			res = getArray("Win?Phone", "Win?Phone", "Win?Phone" + getVersionNumber(userAgent, pos + 10));
		} else if ((pos = userAgent.indexOf("Win?")) > -1) {
			res = getArray("Win?Phone", "Win?Phone", "Win?Phone" + getVersionNumber(userAgent, pos + 10));
		} else if ((pos = userAgent.indexOf("Windows-NT")) > -1) {
			res = getArray("Win", "WinNT", "Win" + getVersionNumber(userAgent, pos + 8));
		} else if (userAgent.indexOf("Windows NT") > -1) {
			if ((pos = userAgent.indexOf("Windows NT 5.1")) > -1)
				res = getArray("Win", "WinXP", "Win" + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT 6.0")) > -1)
				res = getArray("Win", "Vista", "Vista" + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT 5.0")) > -1)
				res = getArray("Win", "Seven", "Seven " + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT 5.0")) > -1)
				res = getArray("Win", "Win2000", "Win" + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT 5.2")) > -1)
				res = getArray("Win", "Win2003", "Win" + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT 4.0")) > -1)
				res = getArray("Win", "WinNT4", "Win" + getVersionNumber(userAgent, pos + 7));
			else if ((pos = userAgent.indexOf("Windows NT)")) > -1)
				res = getArray("Win", "WinNT", "WinNT");
			else if ((pos = userAgent.indexOf("Windows NT;")) > -1)
				res = getArray("Win", "WinNT", "WinNT");
			else
				res = getArray("Win", "<B>WinNT?</B>", "<B>WinNT?</B>");
		} else if (userAgent.indexOf("Win") > -1) {
			if (userAgent.indexOf("Windows") > -1) {
				if ((pos = userAgent.indexOf("Windows 98")) > -1)
					res = getArray("Win", "Win98", "Win" + getVersionNumber(userAgent, pos + 7));
				else if ((pos = userAgent.indexOf("Windows_98")) > -1)
					res = getArray("Win", "Win98", "Win" + getVersionNumber(userAgent, pos + 8));
				else if ((pos = userAgent.indexOf("Windows 2000")) > -1)
					res = getArray("Win", "Win2000", "Win" + getVersionNumber(userAgent, pos + 7));
				else if ((pos = userAgent.indexOf("Windows 95")) > -1)
					res = getArray("Win", "Win95", "Win" + getVersionNumber(userAgent, pos + 7));
				else if ((pos = userAgent.indexOf("Windows 9x")) > -1)
					res = getArray("Win", "Win9x", "Win" + getVersionNumber(userAgent, pos + 7));
				else if ((pos = userAgent.indexOf("Windows ME")) > -1)
					res = getArray("Win", "WinME", "Win" + getVersionNumber(userAgent, pos + 7));
				else if ((pos = userAgent.indexOf("Windows 3.1")) > -1) {
					res = getArray("Win", "Win31", "Win" + getVersionNumber(userAgent, pos + 7));
				}

			}

			if (res == null) {
				if ((pos = userAgent.indexOf("Win98")) > -1)
					res = getArray("Win", "Win98", "Win" + getVersionNumber(userAgent, pos + 3));
				else if ((pos = userAgent.indexOf("Win31")) > -1)
					res = getArray("Win", "Win31", "Win" + getVersionNumber(userAgent, pos + 3));
				else if ((pos = userAgent.indexOf("Win95")) > -1)
					res = getArray("Win", "Win95", "Win" + getVersionNumber(userAgent, pos + 3));
				else if ((pos = userAgent.indexOf("Win 9x")) > -1)
					res = getArray("Win", "Win9x", "Win" + getVersionNumber(userAgent, pos + 3));
				else if ((pos = userAgent.indexOf("WinNT4.0")) > -1)
					res = getArray("Win", "WinNT4", "Win" + getVersionNumber(userAgent, pos + 3));
				else if ((pos = userAgent.indexOf("WinNT")) > -1) {
					res = getArray("Win", "WinNT", "Win" + getVersionNumber(userAgent, pos + 3));
				}
			}
			if (res == null) {
				if ((pos = userAgent.indexOf("Windows")) > -1)
					res = getArray("Win", "<B>Win?</B>", "<B>Win?" + getVersionNumber(userAgent, pos + 7) + "</B>");
				else if ((pos = userAgent.indexOf("Win")) > -1) {
					res = getArray("Win", "<B>Win?</B>", "<B>Win?" + getVersionNumber(userAgent, pos + 3) + "</B>");
				} else
					res = getArray("Win", "<B>Win?</B>", "<B>Win?</B>");
			}
		} else if ((pos = userAgent.indexOf("Mac OS X")) > -1) {
			if (userAgent.indexOf("iPhone") > -1) {
				pos = userAgent.indexOf("iPhone OS");
				if (userAgent.indexOf("iPod") > -1)
					res = getArray("iOS", "iOS-iPod",
							"iOS-iPod " + (pos < 0 ? "" : getVersionNumber(userAgent, pos + 9)));
				else
					res = getArray("iOS", "iOS-iPhone",
							"iOS-iPhone " + (pos < 0 ? "" : getVersionNumber(userAgent, pos + 9)));
			} else if (userAgent.indexOf("iPad") > -1) {
				pos = userAgent.indexOf("CPU OS");
				res = getArray("iOS", "iOS-iPad", "iOS-iPad " + (pos < 0 ? "" : getVersionNumber(userAgent, pos + 6)));
			} else {
				res = getArray("Mac", "MacOSX", "MacOS " + getVersionNumber(userAgent, pos + 8));
			}
		} else if ((pos = userAgent.indexOf("Android")) > -1) {
			res = getArray("Android", "Android", "Android " + getVersionNumber(userAgent, pos + 8));
		} else if ((pos = userAgent.indexOf("Mac_PowerPC")) > -1) {
			res = getArray("Mac", "MacPPC", "MacOS " + getVersionNumber(userAgent, pos + 3));
		} else if ((pos = userAgent.indexOf("Macintosh")) > -1) {
			if (userAgent.indexOf("PPC") > -1)
				res = getArray("Mac", "MacPPC", "MacOS?");
			else
				res = getArray("Mac?", "Mac?", "MacOS?");
		} else if ((pos = userAgent.indexOf("FreeBSD")) > -1) {
			res = getArray("*BSD", "*BSD FreeBSD", "FreeBSD " + getVersionNumber(userAgent, pos + 7));
		} else if ((pos = userAgent.indexOf("OpenBSD")) > -1) {
			res = getArray("*BSD", "*BSD OpenBSD", "OpenBSD " + getVersionNumber(userAgent, pos + 7));
		} else if ((pos = userAgent.indexOf("Linux")) > -1) {
			String detail = "Linux " + getVersionNumber(userAgent, pos + 5);
			String med = "Linux";
			if ((pos = userAgent.indexOf("Ubuntu/")) > -1) {
				detail = "Ubuntu " + getVersionNumber(userAgent, pos + 7);
				med = med + " Ubuntu";
			}
			res = getArray("Linux", med, detail);
		} else if ((pos = userAgent.indexOf("CentOS")) > -1) {
			res = getArray("Linux", "Linux CentOS", "CentOS");
		} else if ((pos = userAgent.indexOf("NetBSD")) > -1) {
			res = getArray("*BSD", "*BSD NetBSD", "NetBSD " + getVersionNumber(userAgent, pos + 6));
		} else if ((pos = userAgent.indexOf("Unix")) > -1) {
			res = getArray("Linux", "Linux", "Linux " + getVersionNumber(userAgent, pos + 4));
		} else if ((pos = userAgent.indexOf("SunOS")) > -1) {
			res = getArray("Unix", "SunOS", "SunOS" + getVersionNumber(userAgent, pos + 5));
		} else if ((pos = userAgent.indexOf("IRIX")) > -1) {
			res = getArray("Unix", "IRIX", "IRIX" + getVersionNumber(userAgent, pos + 4));
		} else if ((pos = userAgent.indexOf("SonyEricsson")) > -1) {
			res = getArray("SonyEricsson", "SonyEricsson", "SonyEricsson" + getVersionNumber(userAgent, pos + 12));
		} else if ((pos = userAgent.indexOf("Nokia")) > -1) {
			res = getArray("Nokia", "Nokia", "Nokia" + getVersionNumber(userAgent, pos + 5));
		} else if ((pos = userAgent.indexOf("BlackBerry")) > -1) {
			res = getArray("BlackBerry", "BlackBerry", "BlackBerry" + getVersionNumber(userAgent, pos + 10));
		} else if ((pos = userAgent.indexOf("SymbianOS")) > -1) {
			res = getArray("SymbianOS", "SymbianOS", "SymbianOS" + getVersionNumber(userAgent, pos + 10));
		} else if ((pos = userAgent.indexOf("BeOS")) > -1) {
			res = getArray("BeOS", "BeOS", "BeOS");
		} else if ((pos = userAgent.indexOf("Nintendo Wii")) > -1) {
			res = getArray("Nintendo Wii", "Nintendo Wii", "Nintendo Wii" + getVersionNumber(userAgent, pos + 10));
		} else {
			res = getArray("<b>?</b>", "<b>?</b>", "<b>?</b>");
		}
		return res;
	}

	/**
	 * Description -- Static method to get Version Number from User agent and
	 * position.
	 * 
	 * @param a_userAgent
	 * @param a_position
	 * @return
	 */
	public static String getVersionNumber(String a_userAgent, int a_position) {
		if (a_position < 0) {
			return "";
		}
		StringBuffer res = new StringBuffer();
		int status = 0;

		while (a_position < a_userAgent.length()) {
			char c = a_userAgent.charAt(a_position);
			switch (status) {
			case 0:
				if ((c != ' ') && (c != '/')) {
					if ((c == ';') || (c == ')')) {
						return "";
					}
					status = 1;
				}
				break;
			case 1:
				if ((c == ';') || (c == '/') || (c == ')') || (c == '(') || (c == '[')) {
					return res.toString().trim();
				}
				if (c == ' ') {
					status = 2;
				}
				res.append(c);
				break;
			case 2:
				if (((Character.isLetter(c)) && (Character.isLowerCase(c))) || (Character.isDigit(c))) {
					res.append(c);
					status = 1;
				} else {
					return res.toString().trim();
				}
				break;
			}
			a_position++;
		}
		return res.toString().trim();
	}

	public static String[] getBotName(String userAgent) {
		userAgent = userAgent.toLowerCase();
		int pos = 0;
		String res = null;
		if ((pos = userAgent.indexOf("google/")) > -1) {
			res = "Google";
			pos += 7;
		} else if ((pos = userAgent.indexOf("msnbot/")) > -1) {
			res = "MSNBot";
			pos += 7;
		} else if ((pos = userAgent.indexOf("googlebot/")) > -1) {
			res = "Google";
			pos += 10;
		} else if ((pos = userAgent.indexOf("webcrawler/")) > -1) {
			res = "WebCrawler";
			pos += 11;
		} else if ((pos = userAgent.indexOf("inktomi")) > -1) {
			res = "Inktomi";
			pos = -1;
		} else if ((pos = userAgent.indexOf("teoma")) > -1) {
			res = "Teoma";
			pos = -1;
		}
		if (res == null) {
			return null;
		}
		return getArray(res, res, res + getVersionNumber(userAgent, pos));
	}

	public static String[] getArray(String a, String b, String c) {
		String[] res = new String[3];
		res[0] = a;
		res[1] = b;
		res[2] = c;
		return res;
	}

	/**
	 * Description -- Util Method to get OS from user agent string
	 * 
	 * @param osString
	 * @param osList
	 * @return
	 */
	public static String getOSType(String osString, List<String> osList) {
		String osType = "0";
		String os = null;
		try {
			Iterator<String> it = osList.iterator();
			while (it.hasNext()) {
				os = (String) it.next();
				if (osString.contains(os)) {
					osType = os;
					break;
				}
			}
		} catch (Exception e) {
			osType = "0";
		}
		return osType;
	}

	/**
	 * Description -- Util Method to generate Desktop OS list
	 * 
	 * @return
	 * @throws Exception
	 */
	public static List<String> getDesktopOSList() throws Exception {
		List<String> desktopOSList = new ArrayList<String>();
		desktopOSList.add("WinNT");
		desktopOSList.add("WinXP");
		desktopOSList.add("Vista");
		desktopOSList.add("Seven");
		desktopOSList.add("Win2000");
		desktopOSList.add("Win2003");
		desktopOSList.add("WinNT4");
		desktopOSList.add("Win98");
		desktopOSList.add("Win95");
		desktopOSList.add("Win9x");
		desktopOSList.add("WinME");
		desktopOSList.add("Win31");
		desktopOSList.add("WinNT4");
		desktopOSList.add("<B>Win?</B>");
		desktopOSList.add("MacOSX");
		desktopOSList.add("MacPPC");
		desktopOSList.add("Mac?");
		desktopOSList.add("*BSD FreeBSD");
		desktopOSList.add("*BSD OpenBSD");
		desktopOSList.add("Ubuntu");
		desktopOSList.add("Linux CentOS");
		desktopOSList.add("*BSD NetBSD");
		desktopOSList.add("Linux");
		desktopOSList.add("SunOS");
		desktopOSList.add("IRIX");
		desktopOSList.add("BeOS");
		desktopOSList.add("BeOS");
		return desktopOSList;
	}

	/**
	 * Description -- Util Method to generate Mobile OS list
	 * 
	 * @return
	 * @throws Exception
	 */
	public static List<String> getMobileOSList() throws Exception {
		List<String> mobileOSList = new ArrayList<String>();
		mobileOSList.add("iOS-iPod");
		mobileOSList.add("iOS-iPhone");
		mobileOSList.add("iOS-iPad");
		mobileOSList.add("Android");
		mobileOSList.add("Nokia");
		mobileOSList.add("BlackBerry");
		mobileOSList.add("SymbianOS");
		mobileOSList.add("SymbianOS");
		mobileOSList.add("Nintendo Wii");
		mobileOSList.add("windows phone");
		mobileOSList.add("Win?Phone");
		return mobileOSList;
	}

	/**
	 * Description -- Util Method to get Expiry date for users whom we have sent
	 * RTO for current day.
	 * 
	 * @return Next Day Date with Zero Hours time so that document will
	 *         automatically get deleted on next day and emailadress will get
	 *         eligible for RTO.
	 */
	public static Date getExpiryDate() {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, 1);
		Date tomorrow = cal.getTime();
		tomorrow.setHours(0);
		tomorrow.setMinutes(0);
		tomorrow.setSeconds(0);
		return tomorrow;
	}

	/**
	 * Description -- Util Method to get Timestamp of currentday of Zero Hour to
	 * get the first open of day
	 * 
	 * @return Timestamp of currentday of Zero Hour in String format
	 */
	public static String getCurrentTimestampStringWithZeroTime() {
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		currentTime.setHours(0);
		currentTime.setMinutes(0);
		currentTime.setSeconds(0);
		currentTime.setNanos(0);
		// System.out.println(currentTime.toString());
		return currentTime.toString();
	}

	/**
	 * Description -- Util Method to generate RTO schedule time phase wise
	 * according to the delay time specified in property file
	 * 
	 * @param timeInterval
	 *            -- Get delay Timeinterval for particular RTO phase
	 * @return DateTime for RTO with delay time in String format
	 */
	public static Date getRtoScheduleDateString(String timeInterval) {
		Calendar calendar = Calendar.getInstance();
		try {
			String[] timeArr = timeInterval.split(":");

			// Add hours to the calendar time
			calendar.add(Calendar.HOUR, Integer.parseInt(timeArr[0]));

			// Add minutes to the calendar time
			calendar.add(Calendar.MINUTE, Integer.parseInt(timeArr[1]));

			// Add seconds to the calendar time
			calendar.add(Calendar.SECOND, Integer.parseInt(timeArr[2]));
			// System.out.println(dateFormat.format(calendar.getTime()));
			// System.out.println(calendar.getTime());
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return calendar.getTime();
	}

	/**
	 * Description -- Util Method to compare current time with first open of the
	 * day to check RTO 4 eligibility.
	 * 
	 * @param openTime
	 *            -- Gets Open time of first Open of the day
	 * @param type
	 * @param timeDiffrence
	 * @return True if time difference is more than 2 Hours
	 */
	public static boolean compareTimestampForRto4(Date openTime, String timeDiffrence, String type) {
		log.info("Open Time :  " + openTime + ", RTO4 Allowed Time Difference :  " + timeDiffrence + ", Time Type : "
				+ type);
		boolean result = false;
		long milliseconds1 = openTime.getTime();
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		long milliseconds2 = currentTime.getTime();
		long diff = milliseconds2 - milliseconds1;

		long diffHhMM = 0;
		if (type.equalsIgnoreCase("minutes")) {
			diffHhMM = diff / (60 * 1000);
		} else if (type.equalsIgnoreCase("hours")) {
			diffHhMM = diff / (60 * 60 * 1000);
		} else if (type.equalsIgnoreCase("seconds")) {
			diffHhMM = diff / 1000;
		} else {
			diffHhMM = diff / (60 * 1000);
		}
		System.out.println("DIff : " + diffHhMM);
		if (diffHhMM >= Integer.parseInt(timeDiffrence)) {
			result = true;
		}

		return result;
	}

	public static void main(String[] args) {
		System.out
				.println(checkURlStatus("https://tracking.geoadmedia.com/aff_c?offer_id=1119&aff_id=1026&url_id=5614"));
		System.out.println(checkURlStatus(
				"https://www.google.com/url?q=https://spectrumdigital.gotrackier.com/click?campaign_id%3D318%26pub_id%3D28&sa=D&source=hangouts&ust=1589370001155000&usg=AFQjCNEWiLfXq50FDR4bogJFAIexmp1ibQ"));
		/*
		 * Date d = getExpiryByHours(1); System.out.println(d);
		 * System.out.println(getExpiryDate());
		 */

		/*
		 * System.out.println(getRtoScheduleDateString("0:0:0"));
		 * 
		 * Timestamp ct = new
		 * Timestamp(System.currentTimeMillis()-24*60*60*1000); ct.setHours(0);
		 * ct.setMinutes(0); ct.setSeconds(0); ct.setNanos(0);
		 * //System.out.println(ct); Date date1 = new Date(ct.getTime());
		 * boolean result = checkCampaignRtoExpiry(date1, 2);
		 * //System.out.println(result);
		 * 
		 * 
		 * String test =
		 * "q9PRhixVBVHKCuOBU8hYC2oIogGtmQ68kJhBn2YC1OJd6nqhuDlyklPrjKXeWnmxPbnfohCtVQW0538G75V+WI+YshF1ZYvQe5W8G28xoY3bgAED4gPWWkgMLL2UavgJysB70mrFYeetv4vMy6iI/l5/pGZsvhWCBOZvtq3DxJCbHI1XhuyBwae7RZFByqFnv8aIrluaXjmF0AHG2EMA9tlPeu/u5HYRh8Q4MppGUKD+FVqOdl12gFZENFWa8XCwIBJI2yJyRC/rkBHc+igp33itD8DOil9pmnSlrEAuFXcV0T80H8oSfF+vLITH5aYDsgZoo3tR2FRTPrE7BIQrS/E0xmPGIyUjpG8g6dLnnDy95o126ftRQkZEmLNQzmGZPBh1UUFY9ZZnqMx5HXDYYA==";
		 * try { Map<String, String > testMap =
		 * getRequestParameterMap(test,"3443243426586565"); TrackingRequestDTO
		 * requestDTO = getRequestDtoFromMap(testMap);
		 * System.out.println(requestDTO.getEmailaddress()); } catch (Exception
		 * e) { e.printStackTrace(); }
		 * 
		 * String dateString = getCurrentDateString(); SimpleDateFormat
		 * formatter = new SimpleDateFormat("yyyy-MM-dd"); Date date = new
		 * Date(); //System.out.println(dateString);
		 * 
		 * getCurrentTimestampStringWithZeroTime(); Date time =
		 * getRtoScheduleDateString("1:11:11");
		 */

		// System.out.println(time);

		try {

			// System.out.println(getCurrentDateStringForActivityData());
			Timestamp currentTime = new Timestamp(System.currentTimeMillis());
			currentTime.setHours(0);
			currentTime.setMinutes(0);
			currentTime.setSeconds(0);
			currentTime.setNanos(0);
			// System.out.println(currentTime);

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			Date parsedDate = dateFormat.parse("2018-10-18 10:10:11.000");
			Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
			// System.out.println(compareTimestampForRto4(timestamp, "2",
			// "hours"));
		} catch (Exception e) { // this generic but you can control another
								// types of exception
			// look the origin of excption
		}
		/*
		 * String timeStamp = new
		 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		 * System.out.println(timeStamp); Timestamp timestamp = new
		 * Timestamp(Calendar.getInstance().getTimeInMillis()); getExpiryDate();
		 */
	}

	public static String getCurrentDateString() {
		String dateString = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		dateString = formatter.format(date);
		return dateString;
	}

	public static String getStartTimeForCampaign() {
		String dateString = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd hh:mm");
		Date date = new Date();
		dateString = formatter.format(date);
		return dateString;
	}

	public static String updateDelayTimeForReschedule(String delayTime) {
		String finalTime = delayTime;
		try {
			String arr[] = delayTime.split(":");
			int minutes = Integer.parseInt(arr[1]) + 10;
			finalTime = arr[0] + ":" + minutes + ":" + arr[2];
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return finalTime;
	}

	public static boolean checkCampaignRtoExpiry(Date scheduleTime, int rto_expiry) {
		boolean result = false;
		Date currentTime = new Date();
		long diff = currentTime.getTime() - scheduleTime.getTime();
		long diffHours = diff / (60 * 60 * 1000) % 24;
		// System.out.println ("Days: " + TimeUnit.DAYS.convert(diff,
		// TimeUnit.MILLISECONDS));
		int days = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		// log.info("Hour difference between Schedule Time and Current Time is :
		// "+diffHours+" and RTO Expiry Hours is : "+rto_expiry);
		log.info("Day difference is : " + days);
		if (days >= rto_expiry) {
			// System.out.println ("Day difference is : "+days+" >= Expiry Days
			// : "+rto_expiry);
			log.info("Campaign Specific RTO Expired !!!");
			result = true;
		}
		return result;
	}

	public static String getCurrentDateStringForActivityData() {
		String dateString = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		dateString = formatter.format(date);
		return dateString;
	}

	public static Date getExpiryDateByDays(int days) {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, days);
		Date tomorrow = cal.getTime();
		tomorrow.setHours(0);
		tomorrow.setMinutes(0);
		tomorrow.setSeconds(0);
		return tomorrow;
	}

	public static Date getExpiryByHours(int hours) {
		Date now = new Date();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(now);
		calendar.add(Calendar.HOUR_OF_DAY, hours);
		return calendar.getTime();
	}

	public static String checkURlStatus(String linkUrl) {
		String status = "404";
		try {
			URL url = new URL(linkUrl);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			int responseCode = connection.getResponseCode();
			if (responseCode == 200) {
				InputStream inputStream = connection.getInputStream();

				BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));

				StringBuilder response = new StringBuilder();
				String currentLine;

				while ((currentLine = in.readLine()) != null)
					response.append(currentLine);

				in.close();
				if (response.toString().length() > 0) {
					status = "200";
				} else {
					log.info("Blank Response Found for URL :{}", linkUrl);
					status = "blank";
				}
			} else if (responseCode == 404) {
				log.info("404 Response Found for URL :{}", linkUrl);
			} else {
				log.info("Blank Response Found for URL :{}", linkUrl);
				status = "blank";
			}
		} catch (MalformedURLException e) {
			log.error("Exception in checkURlStatus Method : " + e.getMessage());
		} catch (IOException e) {
			log.error("Exception in checkURlStatus Method : " + e.getMessage());
		}
		return status;
	}

	public static ResponseEntity<ResponseDto> getErrorMssg(Errors errors) {
		ResponseDto result = new ResponseDto();
		result.setResponseDescription(
				errors.getAllErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.joining(",")));
		result.setResponseCode("400");
		return ResponseEntity.ok().body(result);
	}

}
