package com.hamararojgar.util;

public enum AssetType {
	
	ADMIN_PROFILE("AP", "ADMIN_PROFILE_"),
	JS_PROFILE_PIC("JPP", "JS_PROFILE_PIC_"),
	JS_ADHAR("JSA", "JS_ADHAR_"),
	JS_RECORDING("JSR", "JS_RECORDING_"),
	LEAD_PROFILE("LP", "LEAD_PROFILE_"),
	LEAD_RECORDING("LR", "LEAD_RECORDING_")
	;
	
	private final String value;
	private final String description;
	

	AssetType(String value, String description) {
		this.value = value;
		this.description=description;
	}
	
	public String getDescription() {
		return this.description;
	}
	
	public String geValue() {
		return this.value;
	}

}