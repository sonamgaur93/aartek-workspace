package com.hamararojgar.util;

import java.util.Comparator;

import com.hamararojgar.dto.ResponseNotification;

public class SortingList {
	
	public static class NotilicationListSortById implements Comparator<ResponseNotification>{
		@Override
		public int compare(ResponseNotification o1, ResponseNotification o2) {
			return o1.getId().intValue() - o2.getId().intValue();
		}
	}
	
	public static class NotilicationListSortByCreatedDate implements Comparator<ResponseNotification>{
		@Override
		public int compare(ResponseNotification o1, ResponseNotification o2) {
			return o1.getTime().compareTo(o2.getTime());
		}
	}

}
