package com.hamararojgar.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.codec.binary.StringUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.web.multipart.MultipartFile;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.ResponseDTO;
import com.hamararojgar.serviceimpl.AWSS3Service;

@Component
public class Util {

	@Autowired
	AWSS3Service awss3Service;

	@Autowired
	RojgarConstantProperties constantProperties;

	private final Logger log = LogManager.getLogger(Util.class);
	private final Logger exceptionLog = LogManager.getLogger("exception-log");

	/**
	 * Description -- Static method to get Current Timestamp.
	 * 
	 * @return java.sql.Timestamp object with current Timestamp.
	 */
	public java.sql.Timestamp getTimeStamp() {
		DateFormat gmtFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		TimeZone gmtTime = TimeZone.getTimeZone("IST");
		gmtFormat.setTimeZone(gmtTime);
		Timestamp ts = Timestamp.valueOf(gmtFormat.format(new Date()));
		return ts;
	}

	public String getCurrentDateString() {
		String dateString = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		dateString = formatter.format(date);
		return dateString;
	}

	public Date getDateFromString(String stringDate) {
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
			return formatter.parse(stringDate);
		} catch (Exception exception) {
			return null;
		}
	}

	public String getFromattedDateFromStringDate(String date) {
		String dateString = "";
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		try {
			if (date != null && !date.equalsIgnoreCase("")) {
				Date date1 = new SimpleDateFormat("yyyy-MM-dd").parse(date);
				dateString = formatter.format(date1);
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dateString;
	}

	public Date getExpiryDateByDays(int days) {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, days);
		Date tomorrow = cal.getTime();
		tomorrow.setHours(0);
		tomorrow.setMinutes(0);
		tomorrow.setSeconds(0);
		return tomorrow;
	}

	public String getDomainFromURL(String referrer) {
		String domain = null;
		try {
			URI uri = new URI(referrer);
			domain = uri.getHost();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		return domain;
	}

	public ResponseEntity<ResponseDTO> getErrorMssg(Errors errors) {
		ResponseDTO result = new ResponseDTO();
		result.setResponseDescription(
				errors.getAllErrors().stream().map(x -> x.getDefaultMessage()).collect(Collectors.joining(",")));
		result.setResponseCode("400");
		return ResponseEntity.ok().body(result);

	}

	public String lastWeekDate() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, -6);
		Date date = calendar.getTime();
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
		String dt = format.format(date);
		return dt;
	}

	public String getRedirectionURL(String trackingLink, String clickId) {
		String redirectionUrl = trackingLink.trim();
		log.info("Going to generated Redirection URL with Link :{} and Click Id:{}", trackingLink, clickId);
		try {
			URI uri = new URI(redirectionUrl.trim());
			if (uri.getQuery() != null) {
				redirectionUrl = redirectionUrl + "&clickid=" + clickId;
				log.info("Generated Redirection URL with Link :{} and Click Id:{} i.e :{}", trackingLink, clickId,
						redirectionUrl);
			} else {
				redirectionUrl = redirectionUrl + "?clickid=" + clickId;
				log.info("Generated Redirection URL with Link :{} and Click Id:{} i.e :{}", trackingLink, clickId,
						redirectionUrl);
			}
		} catch (Exception e) {
			if (hasParameters(trackingLink.trim())) {
				redirectionUrl = redirectionUrl + "&clickid=" + clickId;
				log.info("In catch Generated Redirection URL with Link :{} and Click Id:{} i.e :{}", trackingLink,
						clickId, redirectionUrl);
			} else {
				redirectionUrl = redirectionUrl + "?clickid=" + clickId;
				log.info("In catch Generated Redirection URL with Link :{} and Click Id:{} i.e :{}", trackingLink,
						clickId, redirectionUrl);
			}
			log.error("Exception in getRedirectionURL method :{}", e.getMessage());
		}
		return redirectionUrl;
	}

	public boolean hasParameters(String url) {
		return url.matches(".*\\?((.*=.*)(&?))+");
	}

	public double getPercentageDataByGradeprice(double gradePrice, double percentage) {
		double score = 0;
		score = (percentage * gradePrice) / 100;
		return score;
	}

	public String generatePhoneOTP() {
		String otp = "1234";
		Random random = new Random();
		otp = String.format("%06d", random.nextInt(999999));
		return otp;
	}

	public String generateEmailOTP() {
		String otp = "1234";
		Random random = new Random();
		otp = String.format("%06d", random.nextInt(999999));
		return otp;
	}

	public long addMinutesToCurrentTime(int time) {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, time);
		return cal.getTimeInMillis();
	}

	public String encryptPassword(String password) {
		String pwd = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update("N3ByWDJELztQrz3U".getBytes());
			byte[] hashedPassword = md.digest(password.getBytes(StandardCharsets.UTF_8));
			pwd = String.format("%064x", new BigInteger(1, hashedPassword));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return pwd;
	}

	public boolean validateUserPassword(String password, String encryptPassword) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		return encoder.matches(password, encryptPassword);
	}

	public File convertMultiPartFileToFile(final MultipartFile multipartFile) {
		final File file = new File(multipartFile.getOriginalFilename());
		try (final FileOutputStream outputStream = new FileOutputStream(file)) {
			outputStream.write(multipartFile.getBytes());
		} catch (final IOException ex) {

		}
		return file;
	}

	public String createAsset(MultipartFile profile_pic_multipart, Long id, AssetType assetType) {

		String fName = "";
		String assetpath = getAssetpath(assetType);
		try {
			if (null != profile_pic_multipart) {
				fName = assetType.getDescription() + id + "."
						+ FilenameUtils.getExtension(profile_pic_multipart.getOriginalFilename());
				if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
					awss3Service.uploadFile(profile_pic_multipart, assetpath, fName);
				} else {
					Path path = Paths.get(assetpath + fName);
					Files.write(path, profile_pic_multipart.getBytes());
				}
			}

		} catch (Exception e) {
			exceptionLog.error(e.getMessage(), e);
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return fName;
	}

	public InputStream retrieveAsset(String id, AssetType assetType) throws FileNotFoundException {
		InputStream targetStream = null;
		String assetpath = getAssetpath(assetType);
		if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
			targetStream = awss3Service.downloadFile(assetpath, id).getObjectContent();
		} else {
			File imgFile = new File(assetpath + id);
			targetStream = new FileInputStream(imgFile);
		}
		return targetStream;
	}

	private String getAssetpath(AssetType assetType) {

		System.out.println("constantProperties.getAssetStorage():: " + constantProperties.getAssetStorage());
		if ("AWSS3".equalsIgnoreCase(constantProperties.getAssetStorage())) {
			if (assetType.name().equalsIgnoreCase(AssetType.LEAD_RECORDING.name())) {
				return constantProperties.getS3bucketLeadRecording();
			} else if (assetType.name().equalsIgnoreCase(AssetType.LEAD_PROFILE.name())) {
				return constantProperties.getS3bucketLeadImages();
			} else if (assetType.name().equalsIgnoreCase(AssetType.ADMIN_PROFILE.name())) {
				return constantProperties.getS3bucketAdminProfile();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_PROFILE_PIC.name())) {
				return constantProperties.getS3bucketProfile();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_ADHAR.name())) {
				return constantProperties.getS3bucketAdhar();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_RECORDING.name())) {
				return constantProperties.getS3bucketRecording();
			}
		} else {
			if (assetType.name().equalsIgnoreCase(AssetType.LEAD_RECORDING.name())) {
				return constantProperties.getUploadFolderLeadRecording();
			} else if (assetType.name().equalsIgnoreCase(AssetType.LEAD_PROFILE.name())) {
				return constantProperties.getUploadFolderLeadProfile();
			} else if (assetType.name().equalsIgnoreCase(AssetType.ADMIN_PROFILE.name())) {
				return constantProperties.getUploadFolderAdminProfile();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_PROFILE_PIC.name())) {
				return constantProperties.getUploadFolderProfile();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_ADHAR.name())) {
				return constantProperties.getUploadFolderAdhar();
			} else if (assetType.name().equalsIgnoreCase(AssetType.JS_RECORDING.name())) {
				return constantProperties.getUploadFolderRecording();
			}
		}

		return null;
	}

	public String buildResponseStatus(int httpStatusValue) {
		String buildStatus = null;
		switch (httpStatusValue) {
		case 000:
			buildStatus = ServerConstants.ALREADYEXISTS;
			break;
		case 200:
			buildStatus = ServerConstants.SUCCESRESPONSECODE;
			break;
		case 204:
			buildStatus = "STS_NDF";
			break;
		case 417:
		default:
			buildStatus = ServerConstants.FAILURERESPONSECODE;
			break;
		}
		return buildStatus;
	}

	public Instant getInstantByDateFormat(String dateString) {
		try {
			return Instant.parse(dateString);
		} catch (Exception exception) {

		}

		return null;
	}

	public boolean isValuePresent(String commaSeparateString, String seachValue) {
		String[] splitted = commaSeparateString.trim().split("\\s*,\\s*");
		boolean contains = Stream.of(splitted).anyMatch(x -> x.equalsIgnoreCase(seachValue));
		return contains;
	}

	public static void main(String[] args) {
		// rdev$4admin dev end admin password
		String password = null;
		password = "rdev$4admin";
		password = "My$Pass123";
		System.out.println("Encrtpy Password is:: " + new BCryptPasswordEncoder().encode(password));

		System.out.println(AssetType.LEAD_PROFILE.getDescription() + "BHAGIRATHi");
		System.out.println(AssetType.LEAD_RECORDING);

		System.out.println("Result:: " + "LEAD_RECORDING".equalsIgnoreCase(AssetType.LEAD_RECORDING.name()));

		String[] stringList = { "Red", "Orange", "Yellow", "Green", "Blue", "Violet", "Orange", "Blue" };
		boolean contains = Stream.of(stringList).anyMatch(x -> x.equalsIgnoreCase("blue"));
		System.out.println(contains);
	}
}