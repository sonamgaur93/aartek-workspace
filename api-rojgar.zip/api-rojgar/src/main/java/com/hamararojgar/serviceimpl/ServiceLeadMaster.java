package com.hamararojgar.serviceimpl;

import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.hamararojgar.config.ServerConstants;
import com.hamararojgar.dto.LeadDto;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.JobSeekerSkillMap;
import com.hamararojgar.model.LeadMaster;
import com.hamararojgar.model.LeadSkillMap;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.RelationCampaignLead;
import com.hamararojgar.model.ResponseDto;
import com.hamararojgar.repo.CampaignLeadRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;
import com.hamararojgar.repo.JobSeekerSkillMapRepo;
import com.hamararojgar.repo.LeadMasterRepo;
import com.hamararojgar.repo.LeadSkillMapRepo;
import com.hamararojgar.util.AssetType;
import com.hamararojgar.util.RojgarConstantProperties;
import com.hamararojgar.util.RojgarPasswordGenerator;
import com.hamararojgar.util.Util;

@Service
public class ServiceLeadMaster {

	private static final Logger log = LogManager.getLogger(ServiceLeadMaster.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Autowired
	private LeadMasterRepo leadMasterRepo;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private LeadSkillMapRepo leadSkillMapRepo;

	@Autowired
	private RojgarConstantProperties constantProperties;

	@Autowired
	private CampaignLeadRepo campaignLeadRepo;

	@Autowired
	private Util util;

	@Autowired
	private EmployerRepo employerRepo;

	@Autowired
	private JobSeekerMasterRepo jobSeekerMasterRepo;

	@Autowired
	private JobSeekerSkillMapRepo jobSeekerSkillMapRepo;

	@Autowired
	private ServiceCampaign serviceCampaign;

	public Long createLeadMaster(LeadDto dto) {

		LeadMaster leadMaster = new LeadMaster();
		leadMaster.setCustomerId("0");
		leadMaster.setType(dto.getType());
		leadMaster.setAgent_id(dto.getAgent_id());
		leadMaster.setAgent_name(dto.getAgent_name());
		leadMaster.setCreate_date(new Date());
		leadMaster.setDate(util.getCurrentDateString());
		leadMaster.setPriority(dto.getPriority());
		if (null != dto.getStatus() && !dto.getStatus().isEmpty()) {
			leadMaster.setStatus(dto.getStatus());
		}
		leadMaster.setStage(dto.getStage());
		leadMaster.setName(dto.getName());
		leadMaster.setEmail(dto.getEmail());
		leadMaster.setPhone(dto.getPhone());
		leadMaster.setAddress(dto.getAddress());

		if (null != dto.getLattitude() && !dto.getLattitude().isEmpty()) {
			leadMaster.setLattitude(dto.getLattitude());
		}

		if (null != dto.getLongitude() && !dto.getLongitude().isEmpty()) {
			leadMaster.setLongitude(dto.getLongitude());
		}

		if (null != dto.getNote() && !dto.getNote().isEmpty()) {
			leadMaster.setNote(dto.getNote());
		}

		leadMaster.setNote(dto.getNote());

		if (dto.getType().equalsIgnoreCase("Employer")) {
			leadMaster.setCompany_name(dto.getCompany_name());
			leadMaster.setBussiness_type(dto.getBussiness_type());

			if (null != dto.getGst() && !dto.getGst().isEmpty()) {
				leadMaster.setGst(dto.getGst());
			}

			if (null != dto.getPan() && !dto.getPan().isEmpty()) {
				leadMaster.setPan(dto.getPan());
			}
		} else {
			leadMaster.setAvailability(dto.getAvailability());
			leadMaster.setExpected_compensation(dto.getExpected_compensation());
			leadMaster.setExpected_salary(dto.getExpected_salary());
			leadMaster.setExperience(dto.getExperience());
		}

		if (null != dto.getCustomerId() && !dto.getCustomerId().isEmpty()) {
			leadMaster.setCustomerId(dto.getCustomerId());
		}

		leadMaster.setEntryDateTime(Instant.now());

		leadMasterRepo.save(leadMaster);

		if (null != dto.getCampaignCode() && !dto.getCampaignCode().isEmpty()) {
			leadMaster.setCampaignCode(dto.getCampaignCode());
			leadMasterRepo.save(leadMaster);
			RelationCampaignLead relationCampaignLead = new RelationCampaignLead();
			relationCampaignLead.setCampaignCode(Long.parseLong(dto.getCampaignCode()));
			relationCampaignLead.setLeadCode(leadMaster.getId());
			relationCampaignLead.setEntryDateTime(leadMaster.getEntryDateTime());
			campaignLeadRepo.save(relationCampaignLead);
		}
		if (dto.getSkills() != null && !dto.getSkills().equalsIgnoreCase("")) {
			String skillArr[] = dto.getSkills().split(",");
			if (skillArr.length > 0) {
				jdbcTemplate.update("delete from lead_skill_map where lead_id=" + leadMaster.getId().intValue());
				for (String s : skillArr) {
					LeadSkillMap skillMap = new LeadSkillMap();
					skillMap.setLeadId(leadMaster.getId().intValue());
					skillMap.setSkillId(Integer.parseInt(s));
					leadSkillMapRepo.save(skillMap);
				}
			}
			leadMaster.setSkills(dto.getSkills());
		}
		if (null != dto.getProfile_pic_multipart()) {
			String profileUrl = util.createAsset(dto.getProfile_pic_multipart(), leadMaster.getId(),
					AssetType.LEAD_PROFILE);
			leadMaster.setProfile_pic_url(constantProperties.getBaseURLLeadProfile() + profileUrl);
		}
		if (null != dto.getRecording_multipart()) {
			String recordingUrl = util.createAsset(dto.getRecording_multipart(), leadMaster.getId(),
					AssetType.LEAD_RECORDING);
			leadMaster.setRecording_url(constantProperties.getBaseURLLeadRecording() + recordingUrl);
		}
		leadMasterRepo.save(leadMaster);

		return leadMaster.getId();

	}

	
	public Long createSeekerLead(Employer employer) {

		LeadDto leadDto = new LeadDto();

		leadDto.setType("Employer");
		leadDto.setStage("L2");
		leadDto.setAgent_id(1);
		leadDto.setAgent_name("SYSTEM");

		leadDto.setName(employer.getName());
		leadDto.setEmail(employer.getEmail());
		leadDto.setBussiness_type(employer.getBusinessType());
		leadDto.setAddress(employer.getAddress());
		leadDto.setCompany_name(employer.getCompany());

		MasterCampaign masterCampaign = serviceCampaign.getMasterCampaignById(1l);
		if (null != masterCampaign) {
			leadDto.setCampaignCode(masterCampaign.getCampaignCode());
		}

		if (null != employer.getPhone() && !employer.getPhone().isEmpty()) {
			leadDto.setPhone(employer.getPhone());
		}

		if (null != employer.getGst() && !employer.getGst().isEmpty()) {
			leadDto.setGst(employer.getGst());
		}

		if (null != employer.getPan() && !employer.getPan().isEmpty()) {
			leadDto.setPan(employer.getPan());
		}

		leadDto.setCustomerId(String.valueOf(employer.getId()));

		return createLeadMaster(leadDto);
	}
	
	public Long createEmployeeLead(Employer employer) {

		LeadDto leadDto = new LeadDto();

		leadDto.setType("Employer");
		leadDto.setStage("L2");
		leadDto.setAgent_id(1);
		leadDto.setAgent_name("SYSTEM");

		leadDto.setName(employer.getName());
		leadDto.setEmail(employer.getEmail());
		leadDto.setBussiness_type(employer.getBusinessType());
		leadDto.setAddress(employer.getAddress());
		leadDto.setCompany_name(employer.getCompany());

		MasterCampaign masterCampaign = serviceCampaign.getMasterCampaignById(1l);
		if (null != masterCampaign) {
			leadDto.setCampaignCode(masterCampaign.getCampaignCode());
		}

		if (null != employer.getPhone() && !employer.getPhone().isEmpty()) {
			leadDto.setPhone(employer.getPhone());
		}

		if (null != employer.getGst() && !employer.getGst().isEmpty()) {
			leadDto.setGst(employer.getGst());
		}

		if (null != employer.getPan() && !employer.getPan().isEmpty()) {
			leadDto.setPan(employer.getPan());
		}

		leadDto.setCustomerId(String.valueOf(employer.getId()));

		return createLeadMaster(leadDto);
	}

	public int updateLeadMaster(LeadDto dto) {

		Optional<LeadMaster> lead = leadMasterRepo.findById((long) dto.getLeadId());
		if (!lead.isPresent()) {
			return -1;
		}

		LeadMaster leadMaster = lead.get();
		leadMaster.setStatus(dto.getStatus());
		if (dto.getName() != null && !dto.getName().equalsIgnoreCase("")) {
			leadMaster.setName(dto.getName());
		}
		if (dto.getPriority() != null && !dto.getPriority().equalsIgnoreCase("")) {
			leadMaster.setPriority(dto.getPriority());
		}
		if (dto.getEmail() != null && !dto.getEmail().equalsIgnoreCase("")) {
			leadMaster.setEmail(dto.getEmail());
		}
		if (dto.getPhone() != null && !dto.getPhone().equalsIgnoreCase("")) {
			leadMaster.setPhone(dto.getPhone());
		}
		if (dto.getStage() != null && !dto.getStage().equalsIgnoreCase("")) {
			leadMaster.setStage(dto.getStage());
		}
		if (dto.getAddress() != null && !dto.getAddress().equalsIgnoreCase("")) {
			leadMaster.setAddress(dto.getAddress());
		}
		if (dto.getNote() != null && !dto.getNote().equalsIgnoreCase("")) {
			leadMaster.setNote(dto.getNote());
		}
		if (dto.getProfile_pic_multipart() != null) {
			String profileUrl = util.createAsset(dto.getProfile_pic_multipart(), leadMaster.getId(),
					AssetType.LEAD_PROFILE);
			leadMaster.setProfile_pic_url(constantProperties.getBaseURLLeadProfile() + profileUrl);
		}
		if (leadMaster.getType().equalsIgnoreCase("Employer")) {
			if (dto.getCompany_name() != null && !dto.getCompany_name().equalsIgnoreCase("")) {
				leadMaster.setCompany_name(dto.getCompany_name());
			}
			if (dto.getBussiness_type() != null && !dto.getBussiness_type().equalsIgnoreCase("")) {
				leadMaster.setBussiness_type(dto.getBussiness_type());
			}
			if (dto.getPan() != null && !dto.getPan().equalsIgnoreCase("")) {
				leadMaster.setPan(dto.getPan());
			}
			if (dto.getGst() != null && !dto.getGst().equalsIgnoreCase("")) {
				leadMaster.setGst(dto.getGst());
			}
		} else {

			if (dto.getAvailability() != null && !dto.getAvailability().equalsIgnoreCase("")) {
				leadMaster.setAvailability(dto.getAvailability());
			}
			if (dto.getExpected_compensation() != null && !dto.getExpected_compensation().equalsIgnoreCase("")) {
				leadMaster.setExpected_compensation(dto.getExpected_compensation());
			}
			if (dto.getExpected_salary() != null && !dto.getExpected_salary().equalsIgnoreCase("")) {
				leadMaster.setExpected_salary(dto.getExpected_salary());
			}
			if (dto.getExperience() != null && !dto.getExperience().equalsIgnoreCase("")) {
				leadMaster.setExperience(dto.getExperience());
			}
			if (dto.getSkills() != null && !dto.getSkills().equalsIgnoreCase("")) {
				String skillArr[] = dto.getSkills().split(",");
				if (skillArr.length > 0) {
					jdbcTemplate.update("delete from lead_skill_map where lead_id=" + leadMaster.getId().intValue());
					for (String s : skillArr) {
						LeadSkillMap skillMap = new LeadSkillMap();
						skillMap.setLeadId(leadMaster.getId().intValue());
						skillMap.setSkillId(Integer.parseInt(s));
						leadSkillMapRepo.save(skillMap);
					}
				}
				leadMaster.setSkills(dto.getSkills());
			}

		}
		if (null != dto.getCampaignCode() && !dto.getCampaignCode().isEmpty()) {
			if (!leadMaster.getCampaignCode().equalsIgnoreCase(dto.getCampaignCode())) {
				leadMaster.setCampaignCode(dto.getCampaignCode());
				RelationCampaignLead relationCampaignLead = new RelationCampaignLead();
				relationCampaignLead.setCampaignCode(Long.parseLong(dto.getCampaignCode()));
				relationCampaignLead.setLeadCode(leadMaster.getId());
				relationCampaignLead.setEntryDateTime(leadMaster.getEntryDateTime());
				campaignLeadRepo.save(relationCampaignLead);
			}
		}
		leadMasterRepo.save(leadMaster);
		try {
			if ((null == leadMaster.getCustomerId()) || (Integer.parseInt(leadMaster.getCustomerId()) == 0) || leadMaster.getCustomerId().trim().isEmpty())
				if ("L3".equalsIgnoreCase(dto.getStage())) {
					publishLeadByid(leadMaster.getId());
				}
		} catch (Exception exception) {

		}
		return 1;
	}

	public LeadMaster getLeadMaster(Long leadId) {
		Optional<LeadMaster> leadMasterOptional = leadMasterRepo.findById(leadId);
		if (leadMasterOptional.isPresent()) {
			return leadMasterOptional.get();
		}
		return null;
	}

	private ResponseDto publishLeadByid(Long id) {
		ResponseDto responseDTO = new ResponseDto();
		responseDTO.setJobSeekerId(id.intValue());
		log.info("Going to get Lead Details");
		Optional<LeadMaster> lead = leadMasterRepo.findById(id);
		if (lead.isPresent()) {
			LeadMaster leadMaster = lead.get();
			if (leadMaster.getType().equalsIgnoreCase("Employer")) {
				log.info("Lead Type is Employer. Going to check Employer by Email Id " + leadMaster.getEmail());
				Employer employerE = employerRepo.findByEmail(leadMaster.getEmail());
				if (employerE != null) {
					log.info("Email Id Already Exist with Another Employer Email Id " + leadMaster.getEmail());
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Email Id Already Exist with Another Employer");
				} else {
					log.info("Lead Type is Employer. Going to check Employer by Phone No " + leadMaster.getPhone());
					List<Employer> employerP = employerRepo.findByPhone(leadMaster.getPhone());
					if (employerP != null && employerP.size() > 0) {
						log.info("Mobile No Already Exist with Another Employer Mobile No " + leadMaster.getPhone());
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription("Mobile No Already Exist with Another Employer");
					} else {
						log.info("Going to create Employer By Lead Details");
						Employer employer = new Employer();
						employer.setName(leadMaster.getName());
						employer.setEmail(leadMaster.getEmail());
						employer.setPassword(RojgarPasswordGenerator.generateStrongPassword());
						employer.setPhone(leadMaster.getPhone());
						employer.setCompany(leadMaster.getCompany_name());
						employer.setAddress(leadMaster.getAddress());
						employer.setPan(leadMaster.getPan());
						employer.setGst(leadMaster.getGst());
						employer.setBusinessType(leadMaster.getBussiness_type());
						employer.setDeviceToken("");
						employer.setVerified(true);
						employer.setEntryDateTime(Instant.now());
						employer.setEmailVerification(true);
						employer.setStatus("IN-ACTIVE");
						employer.setLeadId(id);

						employerRepo.save(employer);
						log.info("Created Employer By Lead Details");
						leadMaster.setCustomerId(String.valueOf(employer.getId()));
						leadMasterRepo.save(leadMaster);
						responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
						responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
					}
				}

			} else {
				log.info("Lead Type is Job Seeker");
				log.info("Checking Job Seeker with Phone No and Verified Status");
				JobSeekerMaster jm = null;
				// jm =
				// jobSeekerMasterRepo.findByContactAndVerified(addJobSeekerDto.getContact_no(),
				// true);
				jm = jobSeekerMasterRepo.findByContactAndMobileVerification(leadMaster.getPhone(), true);
				if (jm != null) {
					log.info("Mobile Number is already Verifed with Another Job Seeker " + leadMaster.getPhone());
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription("Mobile Number is already Verifed with Another Job Seeker");

				} else {
					log.info("Going to create jobSeeker By Lead Details");
					JobSeekerMaster jobSeeker = new JobSeekerMaster();

					if (leadMaster.getAddress() != null && !leadMaster.getAddress().equalsIgnoreCase("")) {
						jobSeeker.setAddress(leadMaster.getAddress());
					}
					if (leadMaster.getAvailability() != null && !leadMaster.getAvailability().equalsIgnoreCase("")) {
						jobSeeker.setAvailability(leadMaster.getAvailability());
					}
					if (leadMaster.getEmail() != null && !leadMaster.getEmail().equalsIgnoreCase("")) {
						jobSeeker.setEmail(leadMaster.getEmail());
					}
					if (leadMaster.getPhone() != null && !leadMaster.getPhone().equalsIgnoreCase("")) {
						jobSeeker.setContact(leadMaster.getPhone());
					}
					/*
					 * if(leadMaster.getCurrent_location()!=null &&
					 * !leadMaster.getCurrent_location().equalsIgnoreCase("")){
					 * jobSeeker.setCurrent_location(leadMaster.getCurrent_location()); }
					 */
					if (leadMaster.getExpected_compensation() != null
							&& !leadMaster.getExpected_compensation().equalsIgnoreCase("")) {
						jobSeeker.setExpected_compensation(leadMaster.getExpected_compensation());
					}
					if (leadMaster.getExpected_salary() != null
							&& !leadMaster.getExpected_salary().equalsIgnoreCase("")) {
						jobSeeker.setExpected_salary(leadMaster.getExpected_salary());
					}
					if (leadMaster.getExperience() != null && !leadMaster.getExperience().equalsIgnoreCase("")) {
						jobSeeker.setExperience(leadMaster.getExperience());
					}
					/*
					 * if(leadMaster.getFather_name()!=null &&
					 * !leadMaster.getFather_name().equalsIgnoreCase("")){
					 * jobSeeker.setFather_name(leadMaster.getFather_name()); }
					 */
					if (leadMaster.getNote() != null && !leadMaster.getNote().equalsIgnoreCase("")) {
						jobSeeker.setMessage(leadMaster.getNote());
					}
					if (leadMaster.getName() != null && !leadMaster.getName().equalsIgnoreCase("")) {
						jobSeeker.setName(leadMaster.getName());
					}
					/*
					 * if(leadMaster.getPreferred_location()!=null &&
					 * !leadMaster.getPreferred_location().equalsIgnoreCase("")){
					 * jobSeeker.setPreferred_location(leadMaster.getPreferred_location()); }
					 * if(leadMaster.getDeviceToken()!=null &&
					 * !leadMaster.getDeviceToken().equalsIgnoreCase("")){
					 * jobSeeker.setDeviceToken(leadMaster.getDeviceToken()); }
					 */
					jobSeeker.setStatus("IN-ACTIVE");
					jobSeeker.setVerified(true);
					jobSeeker.setMobileVerification(true);
					jobSeeker.setEntryDateTime(Instant.now());
					jobSeeker.setLeadId(id);
					if (leadMaster.getProfile_pic_url() != null) {
						jobSeeker.setProfile_pic_url(leadMaster.getProfile_pic_url());
					}
					if (leadMaster.getRecording_url() != null) {
						jobSeeker.setRecording_url(leadMaster.getRecording_url());
					}
					if (leadMaster.getSkills() != null && !leadMaster.getSkills().equalsIgnoreCase("")) {
						jobSeeker.setSkills(leadMaster.getSkills());
					}
					jobSeekerMasterRepo.save(jobSeeker);
					if (leadMaster.getSkills() != null && !leadMaster.getSkills().equalsIgnoreCase("")) {
						String skillArr[] = leadMaster.getSkills().split(",");
						if (skillArr.length > 0) {
							for (String s : skillArr) {
								JobSeekerSkillMap skillMap = new JobSeekerSkillMap();
								skillMap.setJobSeekerId(jobSeeker.getId().intValue());
								skillMap.setSkillId(Integer.parseInt(s));
								jobSeekerSkillMapRepo.save(skillMap);
							}
						}
					}
					leadMaster.setCustomerId(String.valueOf(jobSeeker.getId()));
					leadMasterRepo.save(leadMaster);
					responseDTO.setResponseCode(ServerConstants.SUCCESRESPONSECODE);
					responseDTO.setResponseDescription(ServerConstants.SUCCESRESPONSEDESC);
				}

			}

		} else {
			responseDTO.setResponseCode(ServerConstants.FAILURERESPONSECODE);
			responseDTO.setResponseDescription("In-Valid Lead Id.");
		}
		return responseDTO;
	}

}