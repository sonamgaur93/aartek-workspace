package com.hamararojgar.serviceimpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.model.ModelMappingNotificationMember;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.payload.request.RequestRojgarNotification;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.RepoMappingNotificationMember;
import com.hamararojgar.util.SortingList;
import com.hamararojgar.util.Util;

@Service
public class ServiceNotification {
	
	private static final Logger log  = LogManager.getLogger(ServiceNotification.class);

	@Autowired
	NotificationMasterRepo notificationMasterRepo;

	@Autowired
	RepoMappingNotificationMember repoMappingNotificationMember;

	@Autowired
	AsyncService asyncService;
	
	@Autowired
	private Util util;

	public void createNotification(RequestRojgarNotification requestRojgarNotification) {
		NotificationMaster notificationMaster = new NotificationMaster();
		notificationMaster.setTitle(requestRojgarNotification.getTitle());
		notificationMaster.setDescription(requestRojgarNotification.getDescription());
		notificationMaster.setTime(new Date());
		notificationMaster.setUserType(requestRojgarNotification.getUserType());
		notificationMasterRepo.save(notificationMaster);
		processMappingMember(notificationMaster.getId(), requestRojgarNotification);
		asyncService.sendPushNotification(requestRojgarNotification);
	}
	
	public List<ResponseNotification> getNotifications(Map<String, String> allRequestParams) {
		List<NotificationMaster> notificationList = null;
		List<ModelMappingNotificationMember> modelMappingNotificationMembers = null;
		if (null != allRequestParams) {
			String memberCode = allRequestParams.get("memberCode");
			String userType = allRequestParams.get("userType");
			List<String> memberCodes = new ArrayList<String>();
			List<String> memberTypes = new ArrayList<String>();
			memberCodes.add("ALL");
			memberTypes.add("ALL");
			if("SATHI".equalsIgnoreCase(userType)) {
				memberCodes.add(userType);
				memberTypes.add(userType);
				if(null !=memberCode ) {
					memberCodes.add(memberCode);
					memberTypes.add("INDIVIDUAL_EMPLOYERS");
				}
				
			}else if("SEEKER".equalsIgnoreCase(userType)) {
				memberCodes.add(userType);
				memberTypes.add(userType);
				if(null !=memberCode ) {
					memberCodes.add(memberCode);
					memberTypes.add("INDIVIDUAL_SEEKERS");
				}
			}
			String startDate = allRequestParams.get("startDate");
			String endDate = allRequestParams.get("endDate");
			if (null != startDate && null != endDate) {
				notificationList = notificationMasterRepo.findByStartDateAndEndDate(startDate, endDate);
			} else if (null != startDate && null == endDate) {
				//notificationList = notificationMasterRepo.findByStartDate(startDate);
				modelMappingNotificationMembers = repoMappingNotificationMember.findAllByEntryDateTimeGreaterThanEqualAndMemberCodeInAndMemberTypeIn(Instant.parse(startDate), memberCodes, memberTypes);
			} else {
				notificationList = notificationMasterRepo.findAll();
			}
		} else {
			notificationList = notificationMasterRepo.findAll();
		}
		if(null == modelMappingNotificationMembers) {
			return null;
		}
		Set<Long> notificationIds= new HashSet<Long>();
		for (ModelMappingNotificationMember modelMappingNotificationMember : modelMappingNotificationMembers) {
			notificationIds.add(modelMappingNotificationMember.getNotificationId());
		}
		Sort sort=Sort.by("id").descending();
		notificationList = notificationMasterRepo.findAllByIdIn(notificationIds, sort);
		if (null != notificationList) {
			List<ResponseNotification> notifications = new ArrayList<ResponseNotification>();
			for (NotificationMaster notificationMaster : notificationList) {
				ResponseNotification responseNotification = new ResponseNotification();
				BeanUtils.copyProperties(notificationMaster, responseNotification);
				notifications.add(responseNotification);
				/*
				 * Comparator<ResponseNotification> comp = Collections .reverseOrder(new
				 * SortingList.NotilicationListSortByCreatedDate());
				 * Collections.sort(notifications, comp);
				 */
			}
			return notifications;
		}
		return null;
	
	}

	private void processMappingMember(Long notificationId, RequestRojgarNotification requestRojgarNotification) {
		List<ModelMappingNotificationMember> modelMappingNotificationMembers = new ArrayList<ModelMappingNotificationMember>();
		if (canProcessMappingMember(requestRojgarNotification.getUserType())) {
			if (isAllMember(requestRojgarNotification.getUserType())) {
				ModelMappingNotificationMember modelMappingNotificationMember = new ModelMappingNotificationMember();
				modelMappingNotificationMember.setMemberCode(requestRojgarNotification.getUserType());
				modelMappingNotificationMember.setNotificationId(notificationId);
				modelMappingNotificationMember.setMemberType(requestRojgarNotification.getUserType());
				modelMappingNotificationMember.setEntryDateTime(Instant.now());
				modelMappingNotificationMembers.add(modelMappingNotificationMember);
			} else {
				for (Long memberCode : requestRojgarNotification.getMemberCodes()) {
					ModelMappingNotificationMember modelMappingNotificationMember = new ModelMappingNotificationMember();
					modelMappingNotificationMember.setMemberCode(String.valueOf(memberCode));
					modelMappingNotificationMember.setNotificationId(notificationId);
					modelMappingNotificationMember.setMemberType(requestRojgarNotification.getUserType());
					modelMappingNotificationMember.setEntryDateTime(Instant.now());
					modelMappingNotificationMembers.add(modelMappingNotificationMember);
				}
			}
		}
		if (!modelMappingNotificationMembers.isEmpty()) {
			repoMappingNotificationMember.saveAll(modelMappingNotificationMembers);
		}
	}

	private boolean canProcessMappingMember(String userType) {
		Set<String> setUserType = new HashSet<String>();
		setUserType.add("ALL");
		setUserType.add("SATHI");
		setUserType.add("SEEKER");
		setUserType.add("INDIVIDUAL_SEEKERS");
		setUserType.add("INDIVIDUAL_EMPLOYERS");
		if (setUserType.contains(userType)) {
			return true;
		}
		return false;
	}

	private boolean isAllMember(String userType) {
		Set<String> setUserType = new HashSet<String>();
		setUserType.add("ALL");
		setUserType.add("SATHI");
		setUserType.add("SEEKER");
		if (setUserType.contains(userType)) {
			return true;
		}
		return false;
	}


}