package com.hamararojgar.serviceimpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import com.hamararojgar.dto.DTOLeadStageMaster;
import com.hamararojgar.dto.DTOLeadStatusMaster;
import com.hamararojgar.dto.RequestDTOBusinessType;
import com.hamararojgar.dto.ResponseDTOBusinessType;
import com.hamararojgar.dto.ResponseDTOHamararojgarUser;
import com.hamararojgar.dto.ResponseDTOUserRole;
import com.hamararojgar.dto.ResponseDTOFeature;
import com.hamararojgar.dto.ResponseDTOFeatureAction;
import com.hamararojgar.dto.ResponseNotification;
import com.hamararojgar.model.BusinessTypeMaster;
import com.hamararojgar.model.LeadStageMaster;
import com.hamararojgar.model.LocationMaster;
import com.hamararojgar.model.MasterCampaign;
import com.hamararojgar.model.MasterFeatureActionModel;
import com.hamararojgar.model.MasterFeatureModel;
import com.hamararojgar.model.MasterUserRoleType;
import com.hamararojgar.model.ModelLeadStatusMaster;
import com.hamararojgar.model.ModelMappingNotificationMember;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.model.RelationFeatureRole;
import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.model.User;
import com.hamararojgar.payload.request.RequestCampaign;
import com.hamararojgar.payload.request.RequestFeature;
import com.hamararojgar.payload.request.RequestMasterUserRole;
import com.hamararojgar.payload.response.ResponseCampaign;
import com.hamararojgar.payload.response.ResponseFeature;
import com.hamararojgar.payload.response.ResponseHamaraRojgarUser;
import com.hamararojgar.payload.response.ResponseHamararojgarContent;
import com.hamararojgar.payload.response.ResponseLeadStageMaster;
import com.hamararojgar.payload.response.ResponseLeadStatus;
import com.hamararojgar.payload.response.ResponseUserRole;
import com.hamararojgar.repo.BusinessTypeMasterRepo;
import com.hamararojgar.repo.CampaignRepo;
import com.hamararojgar.repo.LeadStageMasterRepo;
import com.hamararojgar.repo.LocationMasterRepo;
import com.hamararojgar.repo.NotificationMasterRepo;
import com.hamararojgar.repo.RepoFeature;
import com.hamararojgar.repo.RepoFeatureAction;
import com.hamararojgar.repo.RepoLeadStatusMaster;
import com.hamararojgar.repo.RepoMasterUserRoleType;
import com.hamararojgar.repo.RepoRelationFeatureRole;
import com.hamararojgar.repo.SkillMasterRepo;
import com.hamararojgar.repo.UserRepo;
import com.hamararojgar.util.SortingList;
import com.hamararojgar.util.Util;

@Service
public class MasterDataService {

	private static final Logger log = LogManager.getLogger(MasterDataService.class);

	@Autowired
	private SkillMasterRepo skillMasterRepo;

	@Autowired
	private BusinessTypeMasterRepo businessTypeMasterRepo;

	@Autowired
	private NotificationMasterRepo notificationMasterRepo;

	@Autowired
	private LeadStageMasterRepo leadStageMasterRepo;

	@Autowired
	private RepoMasterUserRoleType repoMasterUserRoleType;

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private RepoLeadStatusMaster repoLeadStatusMaster;

	@Autowired
	private RepoRelationFeatureRole repoRelationFeatureRole;

	@Autowired
	private RepoFeatureAction repoFeatureAction;

	@Autowired
	private RepoFeature repoFeature;

	@Autowired
	private LocationMasterRepo locationMasterRepo;

	@Autowired
	private Util util;

	public List<SkillMaster> getAllSkills() {
		return skillMasterRepo.findAll();
	}

	public List<SkillMaster> getAllSkillsSortByTitle() {
		return skillMasterRepo.findAll(Sort.by("title").ascending());
	}

	public List<BusinessTypeMaster> getBusinessTypes() {
		return businessTypeMasterRepo.findAll();
	}

	public List<BusinessTypeMaster> getBusinessTypes(Sort sort) {
		return businessTypeMasterRepo.findAll(sort);
	}

	public Page<BusinessTypeMaster> getBusinessTypeList(Pageable pageable, String name, Boolean isSorted) {

		Page<BusinessTypeMaster> data = null;
		Pageable sortedpage = null;
		Sort sort = null;
		if (!isSorted) {
			sort = Sort.by("id").ascending();
		} else {
			sort = Sort.by("id").descending();
		}

		sortedpage = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);

		if ("".equalsIgnoreCase(name.trim())) {
			data = businessTypeMasterRepo.findAll(sortedpage);
		} else if (!"".equalsIgnoreCase(name.trim())) {
			data = businessTypeMasterRepo.findAllByNameLike(name, sortedpage);
		} else {
			data = businessTypeMasterRepo.findAll(sortedpage);
		}

		return data;
	}

	public List<ResponseNotification> getNotifications(Map<String, String> allRequestParams) {
		List<NotificationMaster> notificationList = null;
		List<ModelMappingNotificationMember> modelMappingNotificationMembers = null;
		if (null != allRequestParams) {
			for (String parameterKey : allRequestParams.keySet()) {
				log.info("Param Key is:: [" + parameterKey + "] value is:: [" + allRequestParams.get(parameterKey)
						+ "]");

			}
			String startDate = allRequestParams.get("startDate");
			String endDate = allRequestParams.get("endDate");
			if (null != startDate && null != endDate) {
				notificationList = notificationMasterRepo.findByStartDateAndEndDate(startDate, endDate);
			} else if (null != startDate && null == endDate) {
				// notificationList = notificationMasterRepo.findByStartDate(startDate);
				notificationList = notificationMasterRepo.findByTimeGreaterThanEqual(util.getDateFromString(startDate));
			} else {
				notificationList = notificationMasterRepo.findAll();
			}
		} else {
			notificationList = notificationMasterRepo.findAll();
		}
		if (null != notificationList) {
			List<ResponseNotification> notifications = new ArrayList<ResponseNotification>();
			for (NotificationMaster notificationMaster : notificationList) {
				ResponseNotification responseNotification = new ResponseNotification();
				BeanUtils.copyProperties(notificationMaster, responseNotification);
				notifications.add(responseNotification);
				Comparator<ResponseNotification> comp = Collections
						.reverseOrder(new SortingList.NotilicationListSortByCreatedDate());
				Collections.sort(notifications, comp);

			}
			return notifications;

		}

		return null;
	}

	public List<LeadStageMaster> getLeadStages() {
		return leadStageMasterRepo.findAll();
	}

	public ResponseLeadStageMaster getLeadStages(Pageable paging, String userRole) {
		List<LeadStageMaster> leadStages = null;
		Page<LeadStageMaster> page = null;

		if (null == paging) {
			leadStages = leadStageMasterRepo.findAll();
		} else {
			page = leadStageMasterRepo.findAll(paging);
			leadStages = page.getContent();
		}

		if (null == leadStages) {
			return null;
		}

		List<DTOLeadStageMaster> dtoLeadStageMasters = new ArrayList<DTOLeadStageMaster>();

		for (LeadStageMaster leadStageMaster : leadStages) {
			if (null == userRole || userRole.isEmpty()) {
				DTOLeadStageMaster dtoLeadStageMaster = new DTOLeadStageMaster();
				BeanUtils.copyProperties(leadStageMaster, dtoLeadStageMaster);
				dtoLeadStageMasters.add(dtoLeadStageMaster);
			} else {
				if (util.isValuePresent(leadStageMaster.getUserRoles(), userRole)) {
					DTOLeadStageMaster dtoLeadStageMaster = new DTOLeadStageMaster();
					BeanUtils.copyProperties(leadStageMaster, dtoLeadStageMaster);
					dtoLeadStageMasters.add(dtoLeadStageMaster);
				}
			}
		}
		ResponseLeadStageMaster responseUserRole = new ResponseLeadStageMaster();
		responseUserRole.setLeadStages(dtoLeadStageMasters);

		if (null != page) {
			responseUserRole.setCurrentPage(page.getNumber());
			responseUserRole.setTotalItems(page.getNumberOfElements());
			responseUserRole.setTotalPages(page.getTotalPages());
		}
		return responseUserRole;
	}

	public ResponseHamararojgarContent getUserRoleByRoleCode(String roleCode) {
		MasterUserRoleType masterUserRoleType = repoMasterUserRoleType.findByShortCode(roleCode);
		if (null == masterUserRoleType) {
			return null;
		}

		ResponseDTOUserRole responseDTOUserRole = new ResponseDTOUserRole();
		BeanUtils.copyProperties(masterUserRoleType, responseDTOUserRole);

		ResponseUserRole responseUserRole = new ResponseUserRole();
		responseUserRole.setUserRole(responseDTOUserRole);

		return responseUserRole;
	}

	public ResponseHamararojgarContent getUserRoles(Pageable paging) {

		List<MasterUserRoleType> masterUserRoleTypes = null;
		Page<MasterUserRoleType> page = null;

		if (null == paging) {
			masterUserRoleTypes = repoMasterUserRoleType.findAll();
		} else {
			page = repoMasterUserRoleType.findAll(paging);
			masterUserRoleTypes = page.getContent();
		}

		if (null == masterUserRoleTypes) {
			return null;
		}

		List<ResponseDTOUserRole> dtoUserRoles = new ArrayList<ResponseDTOUserRole>();
		for (MasterUserRoleType masterUserRoleType : masterUserRoleTypes) {
			ResponseDTOUserRole responseDTOUserRole = new ResponseDTOUserRole();
			BeanUtils.copyProperties(masterUserRoleType, responseDTOUserRole);
			dtoUserRoles.add(responseDTOUserRole);
		}

		ResponseUserRole responseUserRole = new ResponseUserRole();
		responseUserRole.setUserRoles(dtoUserRoles);

		if (null != page) {
			responseUserRole.setCurrentPage(page.getNumber());
			responseUserRole.setTotalItems(page.getNumberOfElements());
			responseUserRole.setTotalPages(page.getTotalPages());
		}

		return responseUserRole;
	}

	public ResponseUserRole createMasterUserRole(RequestMasterUserRole requestMasterUserRole) {
		MasterUserRoleType masterUserRoleType = new MasterUserRoleType();
		BeanUtils.copyProperties(requestMasterUserRole, masterUserRoleType);
		repoMasterUserRoleType.save(masterUserRoleType);
		ResponseUserRole responseUserRole = new ResponseUserRole();
		ResponseDTOUserRole userRole = new ResponseDTOUserRole();
		BeanUtils.copyProperties(masterUserRoleType, userRole);
		responseUserRole.setUserRole(userRole);
		return responseUserRole;
	}

	public ResponseUserRole updatesMasterUserRole(RequestMasterUserRole requestMasterUserRole) {
		MasterUserRoleType masterUserRoleType = repoMasterUserRoleType
				.findByShortCode(requestMasterUserRole.getShortCode());
		if (null == masterUserRoleType) {
			return null;
		}
		masterUserRoleType.setUserRoleName(requestMasterUserRole.getUserRoleName());
		repoMasterUserRoleType.save(masterUserRoleType);
		ResponseUserRole responseUserRole = new ResponseUserRole();
		ResponseDTOUserRole userRole = new ResponseDTOUserRole();
		BeanUtils.copyProperties(masterUserRoleType, userRole);
		responseUserRole.setUserRole(userRole);
		return responseUserRole;
	}

	public ResponseHamaraRojgarUser getUsers(Pageable paging) {
		log.info("Called getUsers master data service");
		List<User> users = null;
		Page<User> page = null;

		if (null == paging) {
			users = userRepo.findAll();
		} else {
			page = userRepo.findAll(paging);
			users = page.getContent();
		}

		if (null == users) {
			return null;
		}
		log.info("Called getUsers master data service users size:: " + users.size());
		List<ResponseDTOHamararojgarUser> dtoHamararojgarUsers = new ArrayList<ResponseDTOHamararojgarUser>();
		for (User user : users) {
			ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
			BeanUtils.copyProperties(user, responseDTOHamararojgarUser);
			dtoHamararojgarUsers.add(responseDTOHamararojgarUser);
		}

		ResponseHamaraRojgarUser responseUserRole = new ResponseHamaraRojgarUser();
		responseUserRole.setUsers(dtoHamararojgarUsers);

		if (null != page) {
			responseUserRole.setCurrentPage(page.getNumber());
			responseUserRole.setTotalItems(page.getNumberOfElements());
			responseUserRole.setTotalPages(page.getTotalPages());
		}
		log.info("Called getUsers master data service users dtoHamararojgarUsers:: " + dtoHamararojgarUsers.size());
		return responseUserRole;
	}

	public ResponseHamaraRojgarUser getUsers(Map<String, String> parameters) {
		log.info("Called getUsers master data service");
		List<User> users = null;

		Integer size = null;
		Integer pageNumber = null;
		String memberName = null;
		try {
			size = Integer.valueOf(parameters.get("size"));
			pageNumber = Integer.valueOf(parameters.get("page"));
		} catch (Exception exception) {

		}
		Pageable paging = null;
		if (null != size && size >= 1) {
			if (null == pageNumber || pageNumber < 0) {
				pageNumber = 0;
			}
			paging = PageRequest.of(pageNumber, size);
		}

		Page<User> page = null;

		memberName = parameters.get("userName");

		if (null != memberName && !memberName.trim().isEmpty()) {
			memberName = null;
		}

		if (null == memberName && null == paging) {
			users = userRepo.findAll();
		} else if (null != memberName && null != paging) {
			page = userRepo.findByUsernameContaining(memberName, paging);
			users = page.getContent();
		} else {
			page = userRepo.findAll(paging);
			users = page.getContent();
		}

		if (null == users) {
			return null;
		}
		log.info("Called getUsers master data service users size:: " + users.size());
		List<ResponseDTOHamararojgarUser> dtoHamararojgarUsers = new ArrayList<ResponseDTOHamararojgarUser>();
		for (User user : users) {
			ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
			BeanUtils.copyProperties(user, responseDTOHamararojgarUser);
			MasterUserRoleType masterUserRoleType = repoMasterUserRoleType.findByShortCode(user.getRole());
			if (null != masterUserRoleType) {
				responseDTOHamararojgarUser.setRoleName(masterUserRoleType.getUserRoleName());
			}
			dtoHamararojgarUsers.add(responseDTOHamararojgarUser);
		}

		ResponseHamaraRojgarUser responseUserRole = new ResponseHamaraRojgarUser();
		responseUserRole.setUsers(dtoHamararojgarUsers);

		if (null != page) {
			responseUserRole.setCurrentPage(page.getNumber());
			responseUserRole.setTotalItems(page.getNumberOfElements());
			responseUserRole.setTotalPages(page.getTotalPages());
		}
		log.info("Called getUsers master data service users dtoHamararojgarUsers:: " + dtoHamararojgarUsers.size());
		return responseUserRole;
	}

	public ResponseHamararojgarContent getLeadStatus(Pageable paging, String userRole) {

		List<ModelLeadStatusMaster> leadStatusMasters = null;
		Page<ModelLeadStatusMaster> page = null;

		if (null == paging) {
			leadStatusMasters = repoLeadStatusMaster.findAll();
		} else {
			page = repoLeadStatusMaster.findAll(paging);
			leadStatusMasters = page.getContent();
		}

		if (null == leadStatusMasters) {
			return null;
		}
		List<DTOLeadStatusMaster> dtoLeadStatusMasters = new ArrayList<DTOLeadStatusMaster>();

		if (null == userRole || userRole.isEmpty()) {
			for (ModelLeadStatusMaster modelLeadStatusMaster : leadStatusMasters) {
				DTOLeadStatusMaster dtoLeadStatusMaster = new DTOLeadStatusMaster();
				BeanUtils.copyProperties(modelLeadStatusMaster, dtoLeadStatusMaster);
				dtoLeadStatusMasters.add(dtoLeadStatusMaster);
			}
		} else {
			for (ModelLeadStatusMaster modelLeadStatusMaster : leadStatusMasters) {
				if (util.isValuePresent(modelLeadStatusMaster.getUserRoles(), userRole)) {
					DTOLeadStatusMaster dtoLeadStatusMaster = new DTOLeadStatusMaster();
					BeanUtils.copyProperties(modelLeadStatusMaster, dtoLeadStatusMaster);
					dtoLeadStatusMasters.add(dtoLeadStatusMaster);
				}
			}
		}
		ResponseLeadStatus responseLeadStatusMaster = null;
		if (!dtoLeadStatusMasters.isEmpty()) {
			responseLeadStatusMaster = new ResponseLeadStatus();
			responseLeadStatusMaster.setLeadStatusList(dtoLeadStatusMasters);
			if (null != page) {
				responseLeadStatusMaster.setCurrentPage(page.getNumber());
				responseLeadStatusMaster.setTotalItems(page.getNumberOfElements());
				responseLeadStatusMaster.setTotalPages(page.getTotalPages());
			}
		}
		return responseLeadStatusMaster;
	}

	public ResponseHamaraRojgarUser getUser(String userId) {

		Optional<User> optionalUser = userRepo.findById(Long.parseLong(userId));

		if (!optionalUser.isPresent())
			return null;

		User user = optionalUser.get();
		log.info("user:: {} ",user );
		ResponseDTOHamararojgarUser responseDTOHamararojgarUser = new ResponseDTOHamararojgarUser();
		BeanUtils.copyProperties(user, responseDTOHamararojgarUser);
		MasterUserRoleType masterUserRoleType = repoMasterUserRoleType.findByShortCode(user.getRole());
		log.info("masterUserRoleType:: {} ",masterUserRoleType );
		if (null != masterUserRoleType) {
			responseDTOHamararojgarUser.setRoleName(masterUserRoleType.getUserRoleName());
		}
		
		List<ResponseDTOFeature> features = buildResponseFeature(user);
		responseDTOHamararojgarUser.setFeatures(features);
		log.info("responseDTOHamararojgarUser:: {} ",responseDTOHamararojgarUser );
		ResponseHamaraRojgarUser responseUserRole = new ResponseHamaraRojgarUser();
		responseUserRole.setUser(responseDTOHamararojgarUser);
		log.info("success");
		return responseUserRole;
	}

	private List<ResponseDTOFeature> buildResponseFeature(User user) {
		log.info("buildResponseFeature called");
		List<RelationFeatureRole> relationFeatureRoles = repoRelationFeatureRole.findByRoleCode(user.getRole());

		if (null == relationFeatureRoles || relationFeatureRoles.isEmpty())
			return null;

		log.info("relationFeatureRoles:: {}", relationFeatureRoles);
		
		Map<String, MasterFeatureActionModel> mapActionCodes = new HashMap<String, MasterFeatureActionModel>();

		for (RelationFeatureRole relationFeatureRole : relationFeatureRoles) {
			if (!mapActionCodes.containsKey(relationFeatureRole.getActionCode())) {
				mapActionCodes.put(relationFeatureRole.getActionCode(),
						repoFeatureAction.findByActionCode(relationFeatureRole.getActionCode()));
			}
		}
		log.info("mapActionCodes:: {}", mapActionCodes);
		Map<String, List<MasterFeatureActionModel>> mapFeatureActionByFeatureCodes = new HashMap<String, List<MasterFeatureActionModel>>();
		for (String actionCode : mapActionCodes.keySet()) {
			MasterFeatureActionModel masterFeatureActionModel = mapActionCodes.get(actionCode);
			if (!mapFeatureActionByFeatureCodes.containsKey(masterFeatureActionModel.getFeatureCode())) {
				List<MasterFeatureActionModel> masterFeatureActionModels = new ArrayList<MasterFeatureActionModel>();
				masterFeatureActionModels.add(masterFeatureActionModel);
				mapFeatureActionByFeatureCodes.put(masterFeatureActionModel.getFeatureCode(),
						masterFeatureActionModels);
			} else {
				List<MasterFeatureActionModel> masterFeatureActionModels = mapFeatureActionByFeatureCodes
						.get(masterFeatureActionModel.getFeatureCode());
				masterFeatureActionModels.add(masterFeatureActionModel);
				mapFeatureActionByFeatureCodes.put(masterFeatureActionModel.getFeatureCode(),
						masterFeatureActionModels);
			}
		}
		log.info("mapFeatureActionByFeatureCodes:: {}", mapFeatureActionByFeatureCodes);
		
		List<ResponseDTOFeature> features = new ArrayList<>();

		for (String featureCode : mapFeatureActionByFeatureCodes.keySet()) {
			log.info("masterFeatureModel:: {}", featureCode);
			MasterFeatureModel masterFeatureModel = repoFeature.findByFeatureCode(featureCode);
			log.info("masterFeatureModel:: {}", masterFeatureModel);
			ResponseDTOFeature responseFeature = new ResponseDTOFeature();
			BeanUtils.copyProperties(masterFeatureModel, responseFeature);

			List<MasterFeatureActionModel> masterFeatureActionModels = mapFeatureActionByFeatureCodes.get(featureCode);
			List<ResponseDTOFeatureAction> responseFeatureActions = new ArrayList<ResponseDTOFeatureAction>();
			for (MasterFeatureActionModel featureActionModel : masterFeatureActionModels) {
				ResponseDTOFeatureAction responseFeatureAction = new ResponseDTOFeatureAction();
				BeanUtils.copyProperties(featureActionModel, responseFeatureAction);
				responseFeatureActions.add(responseFeatureAction);
			}
			responseFeature.setFeatureActions(responseFeatureActions);
			features.add(responseFeature);
		}
		
		log.info("features:: {}", features);
		return features;
	}

	public BusinessTypeMaster getBusinessTypeMaster(Long id) {
		Optional<BusinessTypeMaster> optioanl = businessTypeMasterRepo.findById(id);
		if (optioanl.isPresent()) {
			return optioanl.get();
		}
		return null;
	}

	public ResponseDTOBusinessType createOrUpdateBusinessType(RequestDTOBusinessType requestDTOBusinessType) {
		ResponseDTOBusinessType responseDTOBusinessType = null;
		BusinessTypeMaster businessTypeMaster = new BusinessTypeMaster();
		BeanUtils.copyProperties(requestDTOBusinessType, businessTypeMaster);
		if (null == requestDTOBusinessType.getId()) {
			businessTypeMaster.setEntryDateTime(Instant.now());
			businessTypeMaster.setUpdateDateTime(Instant.now());
		} else {
			businessTypeMaster.setUpdateDateTime(Instant.now());
		}
		businessTypeMasterRepo.save(businessTypeMaster);
		responseDTOBusinessType = new ResponseDTOBusinessType();
		BeanUtils.copyProperties(businessTypeMaster, responseDTOBusinessType);
		return responseDTOBusinessType;
	}

	public ResponseDTOBusinessType getBusinessType(Long id) {
		BusinessTypeMaster businessTypeMaster = getBusinessTypeMaster(id);
		if (null == businessTypeMaster) {
			return null;

		}
		ResponseDTOBusinessType responseDTOBusinessType = null;
		responseDTOBusinessType = new ResponseDTOBusinessType();
		BeanUtils.copyProperties(businessTypeMaster, responseDTOBusinessType);
		return responseDTOBusinessType;
	}

	public Page<LocationMaster> getLocations(String search, Pageable pageable) {

		Page<LocationMaster> industryList = null;
		if (null == search || search.trim().isEmpty()) {
			industryList = locationMasterRepo.findAll(pageable);
		} else {
			industryList = locationMasterRepo.findLocationByTitleContains(search, pageable);
		}
		return industryList;
	}

	public Page<SkillMaster> getSkills(String search, Pageable sortedpage) {
		Page<SkillMaster> industryList = null;
		if (null == search || search.trim().isEmpty()) {
			industryList = skillMasterRepo.findAll(sortedpage);
		} else {
			industryList = skillMasterRepo.findSkillsByTitleContains(search, sortedpage);
		}
		return industryList;
	}

	public ResponseFeature createFeature(RequestFeature requestFeature) {
		MasterFeatureModel masterFeatureModel = new MasterFeatureModel();
		masterFeatureModel.setEntryDateTime(Instant.now());
		masterFeatureModel.setFeatureCode(requestFeature.getFeatureCode());
		masterFeatureModel.setFeature(requestFeature.getFeatureName());
		masterFeatureModel = repoFeature.save(masterFeatureModel);
		createFeatureActions(requestFeature);

		ResponseDTOFeature responseDTOFeature = new ResponseDTOFeature();
		BeanUtils.copyProperties(masterFeatureModel, responseDTOFeature);
		ResponseFeature responseFeature = new ResponseFeature();
		responseFeature.setFeature(responseDTOFeature);
		return responseFeature;
	}

	public ResponseFeature getFeatures(Map<String, String> parameters) {
		if (null != parameters) {
			for (String parameterKey : parameters.keySet()) {
				log.info("Parameter Key :: " + parameterKey + " Value:: " + parameters.get(parameterKey));
			}
		}
		Pageable paging = null;
		Integer size = null;
		Integer pageNumber = null;
		try {
			size = Integer.valueOf(parameters.get("size"));
			pageNumber = Integer.valueOf(parameters.get("page"));
		} catch (Exception exception) {

		}
		Sort sort = Sort.by("id").descending();
		if (null != size && size >= 1) {
			if (null == pageNumber || pageNumber < 0) {
				pageNumber = 0;
			}
			paging = PageRequest.of(pageNumber, size, sort);
		}
		List<MasterFeatureModel> masterFeatureModels = null;
		Page<MasterFeatureModel> masterFeatureModelsPage = null;

		if (null != paging) {
			masterFeatureModelsPage = repoFeature.findAll(paging);
		} else {
			masterFeatureModels = repoFeature.findAll(sort);
		}

		ResponseFeature responseFeature = new ResponseFeature();
		if (null != masterFeatureModelsPage) {
			masterFeatureModels = masterFeatureModelsPage.getContent();
			responseFeature.setCurrentPage(masterFeatureModelsPage.getNumber());
			responseFeature.setTotalItems(masterFeatureModelsPage.getNumberOfElements());
			responseFeature.setTotalPages(masterFeatureModelsPage.getTotalPages());
		} else if (null != masterFeatureModels) {
			responseFeature.setCurrentPage(1);
			responseFeature.setTotalItems(masterFeatureModels.size());
			responseFeature.setTotalPages(1);
		}

		if (null != masterFeatureModels) {
			List<ResponseDTOFeature> dtoFeatures = new ArrayList<ResponseDTOFeature>();
			for (MasterFeatureModel masterFeatureModel : masterFeatureModels) {
				ResponseDTOFeature dtoFeature = new ResponseDTOFeature();
				dtoFeature.setFeatureCode(masterFeatureModel.getFeatureCode());
				dtoFeature.setFeature(masterFeatureModel.getFeature());
				dtoFeature.setEntryDateTime(masterFeatureModel.getEntryDateTime());
				dtoFeatures.add(dtoFeature);
			}
			responseFeature.setFeatures(dtoFeatures);
		}

		return responseFeature;
	}

	public ResponseFeature getFeature(String featureCode) {

		MasterFeatureModel masterFeatureModel = repoFeature.findByFeatureCode(featureCode);

		if (null == masterFeatureModel) {
			return null;
		}

		ResponseDTOFeature dtoFeature = new ResponseDTOFeature();
		dtoFeature.setFeature(masterFeatureModel.getFeature());
		dtoFeature.setFeatureCode(masterFeatureModel.getFeatureCode());
		dtoFeature.setEntryDateTime(masterFeatureModel.getEntryDateTime());
		List<MasterFeatureActionModel> masterFeatureActionModels = repoFeatureAction.findByFeatureCode(featureCode);
		Map<String, MasterUserRoleType> mapMasterUserRole = new HashMap<String, MasterUserRoleType>();
		if (null != masterFeatureActionModels) {
			List<ResponseDTOFeatureAction> dtoFeatureActions = new ArrayList<ResponseDTOFeatureAction>();
			for (MasterFeatureActionModel masterFeatureActionModel : masterFeatureActionModels) {
				ResponseDTOFeatureAction dtoFeatureAction = new ResponseDTOFeatureAction();
				dtoFeatureAction.setActionCode(masterFeatureActionModel.getActionCode());
				dtoFeatureAction.setAction(masterFeatureActionModel.getAction());

				List<RelationFeatureRole> relationFeatureRoles = repoRelationFeatureRole
						.findByActionCode(masterFeatureActionModel.getActionCode());

				if (null != relationFeatureRoles) {
					for (RelationFeatureRole relationFeatureRole : relationFeatureRoles) {
						if (!mapMasterUserRole.containsKey(relationFeatureRole.getRoleCode())) {
							MasterUserRoleType masterUserRoleType = repoMasterUserRoleType
									.findByShortCode(relationFeatureRole.getRoleCode());
							if (null != masterUserRoleType) {
								mapMasterUserRole.put(relationFeatureRole.getRoleCode(), masterUserRoleType);
							}
						}
					}
				}
				dtoFeatureActions.add(dtoFeatureAction);
			}
			dtoFeature.setFeatureActions(dtoFeatureActions);
			if (null != mapMasterUserRole && !mapMasterUserRole.isEmpty()) {
				List<ResponseDTOUserRole> userRoles = new ArrayList<ResponseDTOUserRole>();
				for (String roleCode : mapMasterUserRole.keySet()) {
					MasterUserRoleType masterUserRoleType = mapMasterUserRole.get(roleCode);
					ResponseDTOUserRole  responseDTOUserRole = new ResponseDTOUserRole();
					responseDTOUserRole.setShortCode(masterUserRoleType.getShortCode());
					responseDTOUserRole.setUserRoleName(masterUserRoleType.getUserRoleName());
					userRoles.add(responseDTOUserRole);
				}
				dtoFeature.setUserRoles(userRoles);
			}
		}

		ResponseFeature responseFeature = new ResponseFeature();
		responseFeature.setFeature(dtoFeature);

		return responseFeature;
	}

	private void createFeatureActions(RequestFeature requestFeature) {
		Set<String> actions = requestFeature.getActions();
		Set<String> actionCodes = new HashSet<String>();
		for (String action : actions) {
			if ("get".equalsIgnoreCase(action)) {

				createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_GET",
						"Get " + requestFeature.getFeatureName());
				actionCodes.add(requestFeature.getFeatureCode() + "_GET");

				createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_GET_ALL",
						"Get all " + requestFeature.getFeatureName());
				actionCodes.add(requestFeature.getFeatureCode() + "_GET_ALL");

				createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_VIEW",
						"View " + requestFeature.getFeatureName());
				actionCodes.add(requestFeature.getFeatureCode() + "_VIEW");

			} else {

				if ("create".equalsIgnoreCase(action)) {
					createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_CREATE",
							"Create " + requestFeature.getFeatureName());
					actionCodes.add(requestFeature.getFeatureCode() + "_CREATE");
				} else if ("edit".equalsIgnoreCase(action)) {
					createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_EDIT",
							"Edit " + requestFeature.getFeatureName());
					actionCodes.add(requestFeature.getFeatureCode() + "_EDIT");
				} else if ("delete".equalsIgnoreCase(action)) {
					createFeatureAction(requestFeature.getFeatureCode(), requestFeature.getFeatureCode() + "_DELETE",
							"Delete " + requestFeature.getFeatureName());
					actionCodes.add(requestFeature.getFeatureCode() + "_DELETE");
				}
			}
		}

		if (!actionCodes.isEmpty()) {

			createRoleFeatureMap(actionCodes, requestFeature.getRoleCodes());
		}
	}

	private void createRoleFeatureMap(Set<String> actionCodes, Set<String> roleCodes) {
		if (null != roleCodes && null != actionCodes) {
			for (String roleCode : roleCodes) {
				for (String actionCode : actionCodes) {
					RelationFeatureRole relationFeatureRole = new RelationFeatureRole();
					relationFeatureRole.setRoleCode(roleCode);
					relationFeatureRole.setActionCode(actionCode);
					relationFeatureRole.setEntryDateTime(Instant.now());
					repoRelationFeatureRole.save(relationFeatureRole);
				}
			}
		}
	}

	private void createFeatureAction(String featureCode, String actionCode, String action) {
		MasterFeatureActionModel masterFeatureActionModelGet = new MasterFeatureActionModel();
		masterFeatureActionModelGet.setFeatureCode(featureCode);
		masterFeatureActionModelGet.setActionCode(actionCode);
		masterFeatureActionModelGet.setAction(action);
		masterFeatureActionModelGet.setEntryDateTime(Instant.now());
		repoFeatureAction.save(masterFeatureActionModelGet);
	}

}