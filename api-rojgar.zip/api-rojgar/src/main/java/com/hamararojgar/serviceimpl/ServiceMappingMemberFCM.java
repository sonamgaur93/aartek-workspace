package com.hamararojgar.serviceimpl;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hamararojgar.model.MappingMemberFCM;
import com.hamararojgar.repo.RepoMappingMemberFCM;

@Service
public class ServiceMappingMemberFCM {

	@Autowired
	RepoMappingMemberFCM repoMappingMemberFCM;

	public MappingMemberFCM getMappingMemberFCMByMemebrTypeAndMemberCode(String memberType, String memberCode) {
		return repoMappingMemberFCM.getRecordByMemberTypeAndMemberCode(memberType, memberCode);
	}

	public boolean createMappingMemberFCM(String memberType, String memberCode, String deviceToken) {
		try {
			MappingMemberFCM mappingMemberFCM = getMappingMemberFCMByMemebrTypeAndMemberCode(memberType, memberCode);
			if (null == mappingMemberFCM) {
				mappingMemberFCM = new MappingMemberFCM();
				mappingMemberFCM.setEntryDateTime(Instant.now());
			}
			mappingMemberFCM.setDeviceToken(deviceToken);
			mappingMemberFCM.setMemberCode(memberCode);
			mappingMemberFCM.setMemberType(memberType);
			mappingMemberFCM.setUpdateDateTime(Instant.now());
			repoMappingMemberFCM.save(mappingMemberFCM);
			return true;
		} catch (Exception exception) {

		}
		return false;
	}

}