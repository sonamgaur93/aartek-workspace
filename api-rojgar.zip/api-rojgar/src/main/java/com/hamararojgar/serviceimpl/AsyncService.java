package com.hamararojgar.serviceimpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hamararojgar.dto.SaveJobChat;
import com.hamararojgar.model.AppliedJobs;
import com.hamararojgar.model.Employer;
import com.hamararojgar.model.JobMaster;
import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.NotificationMaster;
import com.hamararojgar.payload.request.RequestRojgarNotification;
import com.hamararojgar.repo.AppliedJobsRepo;
import com.hamararojgar.repo.EmployerRepo;
import com.hamararojgar.repo.JobMasterRepo;
import com.hamararojgar.repo.JobSeekerMasterRepo;

@Service
public class AsyncService {

	private static final Logger log = LogManager.getLogger(AsyncService.class);
	private static final Logger exceptionLog = LogManager.getLogger("exception-log");

	@Value("${android.fm.key}")
	private String FCM_KEY;

	@Value("${android.fm.url}")
	private String FCM_URL;

	@Autowired
	EmployerRepo employerRepo;

	@Autowired
	AppliedJobsRepo appliedJobsRepo;

	@Autowired
	JobMasterRepo jobMasterRepo;

	@Autowired
	JobSeekerMasterRepo jobSeekerMasterRepo;

	@Autowired
	ServiceEmployer serviceEmployer;
	
	@Async
	public void sendPushNotification(SaveJobChat chatDto) {
		try {
			String deviceToken = "";
			Optional<AppliedJobs> appliedJobs = appliedJobsRepo.findById((long) chatDto.getAppliedJobId());
			if (appliedJobs.isPresent()) {
				AppliedJobs aj = appliedJobs.get();
				if (chatDto.getMessageBy().equalsIgnoreCase("JobSeeker")) {
					Optional<JobMaster> jobMaster = jobMasterRepo.findById((long) aj.getJobId());
					if (jobMaster.isPresent()) {
						JobMaster job = jobMaster.get();
						Optional<Employer> empemployer = employerRepo.findById(Long.parseLong(job.getEmployerId()));
						if (empemployer.isPresent()) {
							Employer employer = empemployer.get();
							deviceToken = employer.getDeviceToken();
						}
					}
				} else {
					Optional<JobSeekerMaster> jobSeekerMaster = jobSeekerMasterRepo
							.findById((long) aj.getJobSeekerId());
					if (jobSeekerMaster.isPresent()) {
						JobSeekerMaster seekerMaster = jobSeekerMaster.get();
						deviceToken = seekerMaster.getDeviceToken();
					}
				}
			}
			if (deviceToken != null && !deviceToken.equalsIgnoreCase("")) {
				log.info("FCM: Going to send Push Notification with FCM KEY :{}", FCM_KEY);
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.set("Authorization", "key=" + FCM_KEY);
				httpHeaders.set("Content-Type", "application/json");
				JSONObject msg = new JSONObject();
				JSONObject json = new JSONObject();

				msg.put("appliedJobId", chatDto.getAppliedJobId());
				msg.put("name", chatDto.getName());
				msg.put("messageBy", chatDto.getMessageBy());
				msg.put("type", chatDto.getType());
				if (chatDto.getMessage() != null) {
					msg.put("message", chatDto.getMessage());
				} else {
					msg.put("message", "");
				}
				json.put("data", msg);
				json.put("to", deviceToken);
				log.info("FCM: Sending Push Notification to Device Token {} with data {}", deviceToken, msg.toString());
				HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
				String response = restTemplate.postForObject(FCM_URL, httpEntity, String.class);

				log.info("FCM: Push Notification Response : {}", response);
			} else {
				log.info("FCM: Device Token Not Found for Chat Message  :{}", chatDto);
			}
		} catch (Exception e) {
			log.info("FCM: Exception in sendPushNotification : {}", e.getMessage());
			e.printStackTrace();
		}

	}

	@Async
	public void sendPushNotificationForAllEmployers(NotificationMaster sm) {
		try {
			List<Employer> allJobSeekers = employerRepo.findAll();
			for (Employer emp : allJobSeekers) {
				if (emp.getDeviceToken() != null) {
					log.info("FCM: Going to send Push Notification with FCM KEY :{}", FCM_KEY);
					RestTemplate restTemplate = new RestTemplate();
					HttpHeaders httpHeaders = new HttpHeaders();
					httpHeaders.set("Authorization", "key=" + FCM_KEY);
					httpHeaders.set("Content-Type", "application/json");
					JSONObject msg = new JSONObject();
					JSONObject json = new JSONObject();
					msg.put("type", "admin");
					msg.put("title", sm.getTitle());
					msg.put("description", sm.getDescription());
					json.put("data", msg);
					json.put("to", emp.getDeviceToken());
					log.info("FCM: Sending Push Notification to Device Token {} with data {}", emp.getDeviceToken(),
							msg.toString());
					HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
					String response = restTemplate.postForObject(FCM_URL, httpEntity, String.class);

					log.info("FCM: Push Notification Response : {}", response);
				} else {
					log.info("FCM: Device Token Not Found for Employer Id  :{}", emp.getId());
				}
			}
		} catch (Exception e) {
			log.info("FCM: Exception in sendPushNotification : {}", e.getMessage());
			e.printStackTrace();
		}
	}

	@Async
	public void sendPushNotificationForAllJobSeekers(NotificationMaster sm) {
		try {
			List<JobSeekerMaster> allJobSeekers = jobSeekerMasterRepo.findAll();
			for (JobSeekerMaster jm : allJobSeekers) {
				if (jm.getDeviceToken() != null) {
					log.info("FCM: Going to send Push Notification with FCM KEY :{}", FCM_KEY);
					RestTemplate restTemplate = new RestTemplate();
					HttpHeaders httpHeaders = new HttpHeaders();
					httpHeaders.set("Authorization", "key=" + FCM_KEY);
					httpHeaders.set("Content-Type", "application/json");
					JSONObject msg = new JSONObject();
					JSONObject json = new JSONObject();
					msg.put("type", "admin");
					msg.put("title", sm.getTitle());
					msg.put("description", sm.getDescription());
					json.put("data", msg);
					json.put("to", jm.getDeviceToken());
					log.info("FCM: Sending Push Notification to Device Token {} with data {}", jm.getDeviceToken(),
							msg.toString());
					HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
					String response = restTemplate.postForObject(FCM_URL, httpEntity, String.class);

					log.info("FCM: Push Notification Response : {}", response);
				} else {
					log.info("FCM: Device Token Not Found for Job Seeker Id  :{}", jm.getId());
				}
			}
		} catch (Exception e) {
			log.info("FCM: Exception in sendPushNotification : {}", e.getMessage());
			e.printStackTrace();
		}

	}

	@Async
	public void sendPushNotification(NotificationMaster notificationMaster) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.set("Authorization", "key=" + FCM_KEY);
			httpHeaders.set("Content-Type", "application/json");
			JSONObject msg = new JSONObject();
			JSONObject json = new JSONObject();
			msg.put("type", "admin");
			msg.put("title", notificationMaster.getTitle());
			msg.put("description", notificationMaster.getDescription());
			json.put("data", msg);
			if ("SATHI".equalsIgnoreCase(notificationMaster.getUserType().trim())) {
				json.put("to", "/topics/sathi");
			} else if ("SEEKER".equalsIgnoreCase(notificationMaster.getUserType().trim())) {
				json.put("to", "/topics/jobseeker");
			} else {
				json.put("to", "/topics/all");
			}
			log.info("FCM: Sending Push Notification to Device Token {} with data {}", msg.toString());
			HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
			String response = restTemplate.postForObject(FCM_URL, httpEntity, String.class);
			log.info("FCM: Push Notification Response : {}", response);
		} catch (Exception e) {
			log.info("FCM: Exception in sendPushNotification : {}", e.getMessage());
			e.printStackTrace();
		}
	}

	@Async
	public void sendPushNotification(RequestRojgarNotification requestRojgarNotification) {
		try {
			List<String> senderList = new ArrayList<String>();
			if ("SATHI".equalsIgnoreCase(requestRojgarNotification.getUserType().trim())) {
				senderList.add("/topics/sathi");
			} else if ("SEEKER".equalsIgnoreCase(requestRojgarNotification.getUserType().trim())) {
				senderList.add("/topics/jobseeker");
			} else if ("INDIVIDUAL_EMPLOYERS".equalsIgnoreCase(requestRojgarNotification.getUserType().trim())) {
				senderList = getEmployerList(requestRojgarNotification.getMemberCodes());
			} else if ("INDIVIDUAL_SEEKERS".equalsIgnoreCase(requestRojgarNotification.getUserType().trim())) {
				senderList = getJobSeekerList(requestRojgarNotification.getMemberCodes());
			} else {
				senderList.add("/topics/all");
			}
			for (String senderToken : senderList) {
				RestTemplate restTemplate = new RestTemplate();
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.set("Authorization", "key=" + FCM_KEY);
				httpHeaders.set("Content-Type", "application/json");
				JSONObject json = new JSONObject();
				json.put("to", senderToken);
				JSONObject msg = new JSONObject();
				msg.put("type", "admin");
				msg.put("title", requestRojgarNotification.getTitle());
				msg.put("description", requestRojgarNotification.getDescription());
				json.put("data", msg);
				HttpEntity<String> httpEntity = new HttpEntity<String>(json.toString(), httpHeaders);
				String response = restTemplate.postForObject(FCM_URL, httpEntity, String.class);
				log.info("FCM: Push Notification Response : {}", response);
			}
		} catch (Exception e) {
			log.info("FCM: Exception in sendPushNotification : {}", e.getMessage());
			e.printStackTrace();
		}
	}

	private List<String> getEmployerList(Long[] memberCodes) {
		List<Employer> employers = serviceEmployer.getEmployers(memberCodes);

		if (null == employers) {
			return new ArrayList<String>();
		}
		List<String> employerList = new ArrayList<String>();
		for (Employer employer : employers) {
			employerList.add(employer.getDeviceToken());
		}
		return employerList;
	}
	private List<String> getJobSeekerList(Long[] memberCodes) {
		List<Long> inputAsList = Arrays.asList(memberCodes);
		List<JobSeekerMaster> jobSeekerMasters = jobSeekerMasterRepo.findAllByIdIn(inputAsList);
		if (null == jobSeekerMasters) {
			return new ArrayList<String>();
		}
		List<String> jobSeekerList = new ArrayList<String>();
		for (JobSeekerMaster jobSeekerMaster : jobSeekerMasters) {
			jobSeekerList.add(jobSeekerMaster.getDeviceToken());
		}
		return jobSeekerList;
	}
}