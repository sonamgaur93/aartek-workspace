package com.hamararojgar.repo;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.NotificationMaster;

public interface NotificationMasterRepo extends JpaRepository<NotificationMaster, Long> {
	
	@Query(value = "SELECT * from notification_master where date(time) >= date(?1)",
            nativeQuery = true)
	List<NotificationMaster> findByStartDate(String startDate);
	
	List<NotificationMaster> findByTimeGreaterThanEqual(Date startDate);
	
	@Query(value = "SELECT * from notification_master where date(time) between date(?1) and date(?2)",
            nativeQuery = true)
	List<NotificationMaster> findByStartDateAndEndDate(String startDate, String endDate);

	List<NotificationMaster> findAllByIdIn(Set<Long> notificationIds, Sort sort);

}
