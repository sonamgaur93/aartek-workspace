package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.MappingMemberFCM;

@Repository
public interface RepoMappingMemberFCM extends JpaRepository<MappingMemberFCM, Long> {
	
	MappingMemberFCM getRecordByMemberTypeAndMemberCode(String memberType, String memberCode);
	

}