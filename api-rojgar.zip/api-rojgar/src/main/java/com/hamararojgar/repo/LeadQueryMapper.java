package com.hamararojgar.repo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hamararojgar.dto.LeadDto;

public class LeadQueryMapper  implements RowMapper<LeadDto>{

	@Override
	public LeadDto mapRow(ResultSet resultSet, int i) throws SQLException {
		LeadDto dto = new LeadDto();
		dto.setId(resultSet.getLong("id"));
		dto.setAgent_name(resultSet.getString("agent_name"));
		dto.setName(resultSet.getString("name"));
		dto.setType(resultSet.getString("type"));
		dto.setPriority(resultSet.getString("priority"));
		dto.setCreate_date(resultSet.getDate("create_date"));
		dto.setStage(resultSet.getString("stage"));
		dto.setStatus(resultSet.getString("status"));
		dto.setCampaignCode(resultSet.getString("campaign_code"));
		return dto;
	}

}