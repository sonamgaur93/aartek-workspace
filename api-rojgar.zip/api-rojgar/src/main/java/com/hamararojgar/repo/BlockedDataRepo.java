package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.BlockedData;

public interface BlockedDataRepo extends JpaRepository<BlockedData, Long> {

	BlockedData findByKeyIdAndName(int id, String key);

}
