package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.JobSeekerMaster;
import com.hamararojgar.model.UserOtp;

public interface JobSeekerMasterRepo extends JpaRepository<JobSeekerMaster, Long> {

	JobSeekerMaster findByContact(String contact_no);
	JobSeekerMaster findTop1ByContactOrderByIdDesc(String contact_no);
	
	JobSeekerMaster findByContactAndVerified(String contact_no,boolean status);
	
	JobSeekerMaster findByContactAndMobileVerification(String contact_no,boolean status);
	
	JobSeekerMaster findByContactAndId(String contact_no, long id);
	
	long countByContact(String contact_no);
	
	@Query(value = "select * from job_seeker_master where name like %?1% and verified IN ?2 and status IN ?3 \n#pageable\n",
	            countQuery = "select count(*) from job_seeker_master where name like %?1% and verified IN ?2 and status IN ?3",
	            nativeQuery = true)
	Page<JobSeekerMaster> findAllByNameLike(String name,List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where contact_no like %?1%  and verified IN ?2 and status IN ?3 \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where contact_no like %?1% and verified IN ?2 and status IN ?3",
            nativeQuery = true)
    Page<JobSeekerMaster> findAllByContactLike(String contact,List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where email like %?1%  and verified IN ?2 and status IN ?3 \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where email like %?1% and verified IN ?2 and status IN ?3",
            nativeQuery = true)
    Page<JobSeekerMaster> findAllByEmailLike(String email,List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where name like %?1% and contact_no like %?2% and verified IN ?3 and status IN ?4  \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where name like %?1% and contact_no like %?2% and verified IN ?3 and status IN ?4  ",
            nativeQuery = true)
	Page<JobSeekerMaster> findByNameLikeAndContactLike(String name,String contact, List<Boolean> v, List<String> s,Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where name like %?1% and email like %?2% and verified IN ?3 and status IN ?4    \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where name like %?1% and email like %?2% and verified IN ?3 and status IN ?4  ",
            nativeQuery = true)
	Page<JobSeekerMaster> findByNameLikeAndEmailLike(String name,String email,List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where contact_no like %?1% and email like %?2% and verified IN ?3 and status IN ?4    \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where contact_no like %?1% and email like %?2% and verified IN ?3 and status IN ?4  ",
            nativeQuery = true)
	Page<JobSeekerMaster> findByContactLikeAndEmailLike(String contact, String email,List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where name like %?1% and email like %?2% and contact_no like %?3% and verified IN ?4 and status IN ?5 \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where name like %?1% and email like %?2% and contact_no like %?3%  and verified IN ?4 and status IN ?5 ",
            nativeQuery = true)
	Page<JobSeekerMaster> findByNameLikeAndEmailLikeAndContactLike(String name, String email, String contact,List<Boolean> v, List<String> s, Pageable sortedpage);

	@Query(value = "select * from job_seeker_master where verified IN ?1 and status IN ?2  \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where verified IN ?1 and status IN ?2",
            nativeQuery = true)
	Page<JobSeekerMaster> findByVerifiedAndStatus(List<Boolean> v, List<String> s, Pageable sortedpage);
	
	@Query(value = "select * from job_seeker_master where status IN ?1  \n#pageable\n",
            countQuery = "select count(*) from job_seeker_master where status IN ?1",
            nativeQuery = true)
	Page<JobSeekerMaster> findByStatus(List<String> s, Pageable sortedpage);

	List<JobSeekerMaster> findByEmail(String email);
	
	List<JobSeekerMaster> findAllByIdIn(List<Long> ids) ;
	List<JobSeekerMaster> findByVerifiedAndStatus(List<Boolean> verfiedValues, List<String> statusValues, Sort sort);
	List<JobSeekerMaster> findByNameLikeAndEmailLikeAndContactLike(String contactName, String email, String contact,
			List<Boolean> verfiedValues, List<String> statusValues, Sort sort);
	List<JobSeekerMaster> findAllByEmailLike(String email, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);
	List<JobSeekerMaster> findAllByNameLike(String contactName, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);
	List<JobSeekerMaster> findAllByContactLike(String contact, List<Boolean> verfiedValues, List<String> statusValues,
			Sort sort);
	List<JobSeekerMaster> findByNameLikeAndContactLike(String contactName, String contact, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);
	List<JobSeekerMaster> findByNameLikeAndEmailLike(String contactName, String email, List<Boolean> verfiedValues,
			List<String> statusValues, Sort sort);
	List<JobSeekerMaster> findByContactLikeAndEmailLike(String contact, String email, List<Boolean> verfiedValues, List<String> statusValues, Sort sort);

}
