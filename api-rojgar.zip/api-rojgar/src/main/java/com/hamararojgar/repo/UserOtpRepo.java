package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.UserOtp;

public interface UserOtpRepo extends JpaRepository<UserOtp, Long> {

	UserOtp findByPhone(String phone);
	UserOtp findTop1ByEmailOrderByIdDesc(String email);

}
