package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.AppliedJobChatMaster;

public interface AppliedJobChatMasterRepo extends JpaRepository<AppliedJobChatMaster, Long> {

	List<AppliedJobChatMaster> findByAppliedJobId(int id);

}
