package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hamararojgar.model.CommentMaster;

public interface CommentMasterRepo extends JpaRepository<CommentMaster, Long> {

	List<CommentMaster> findByLeadId(int leadId);
	
	@Query(value = "select * from lead_comment_master where lead_id = ?1  \n#pageable\n",
            countQuery = "select count(*) from lead_comment_master where lead_id = ?1 ",
            nativeQuery = true)
    Page<CommentMaster> findAllByLeadId(int leadId,Pageable sortedpage);
}
