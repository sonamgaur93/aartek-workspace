package com.hamararojgar.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.hamararojgar.model.User;

public interface UserRepo extends JpaRepository<User, Long> {

	User findByEmailAndPassword(String email, String password);

	User findByEmail(String email);

	User findByEmailAndPasswords(String email, String pass);
	
	Page<User> findByUsernameContaining(String userName, Pageable pageable);
	Page<User> findByIdIn(List<Long> ids, Pageable pageable);
	List<User> findByRole(String role);
	Page<User> findByRole(String role, Pageable pageable);

	User findByEmailAndRole(String email, String role);
	
	
}
