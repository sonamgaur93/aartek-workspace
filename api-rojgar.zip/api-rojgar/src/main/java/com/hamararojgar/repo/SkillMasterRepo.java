package com.hamararojgar.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hamararojgar.model.SkillMaster;

@Repository
public interface SkillMasterRepo extends JpaRepository<SkillMaster, Long> {

	List<SkillMaster> findByTitle(String title);
	Page<SkillMaster>  findSkillsByTitleContains(String title, Pageable pageable);
	List<SkillMaster> findByIdIn(List<Long> ids);
	
	List<SkillMaster> findByTitleIn(List<String> title);
	


}
