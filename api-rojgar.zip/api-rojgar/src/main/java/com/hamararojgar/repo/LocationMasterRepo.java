package com.hamararojgar.repo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hamararojgar.model.LocationMaster;

public interface LocationMasterRepo extends JpaRepository<LocationMaster, Long> {
	
	Page<LocationMaster>  findLocationByTitleContains(String title, Pageable pageable);


}
