package com.hamararojgar.dto;

public class ResponseDTORojgarJobApplied extends DTOCommonDBFields{

	public String getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}
	public ResponseDTORojgarJob getJob() {
		return job;
	}
	public void setJob(ResponseDTORojgarJob job) {
		this.job = job;
	}
	public ResponseDTOJobSeeker getSeeker() {
		return seeker;
	}
	public void setSeeker(ResponseDTOJobSeeker seeker) {
		this.seeker = seeker;
	}
	private String appliedDate;
	private ResponseDTORojgarJob job;
	private ResponseDTOJobSeeker seeker;

}