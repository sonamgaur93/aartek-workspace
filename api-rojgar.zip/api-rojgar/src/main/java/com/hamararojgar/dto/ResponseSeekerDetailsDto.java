package com.hamararojgar.dto;

import java.util.Date;
import java.util.List;

public class ResponseSeekerDetailsDto {
	
	private String responseCode = "";
	private String responseDescription = "";
	private Date responseTime ;
	
	@Override
	public String toString() {
		return "ResponseSeekerDetailsDto [responseCode=" + responseCode + ", responseDescription=" + responseDescription
				+ ", responseTime=" + responseTime + ", seekerDetails=" + seekerDetails + "]";
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}


	public Date getResponseTime() {
		if(null == responseTime)
			responseTime= new Date();
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}
	private List<SeekerSkillDetailsDto> seekerDetails;

	public List<SeekerSkillDetailsDto> getSeekerDetails() {
		return seekerDetails;
	}

	public void setSeekerDetails(List<SeekerSkillDetailsDto> seekerDetails) {
		this.seekerDetails = seekerDetails;
	}
	
	
	

}
