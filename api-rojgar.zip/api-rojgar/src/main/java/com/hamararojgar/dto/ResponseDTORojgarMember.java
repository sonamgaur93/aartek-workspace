package com.hamararojgar.dto;

import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.BreakIterator;

public class ResponseDTORojgarMember {
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserName() {
		return (null !=userName? UCharacter.toTitleCase(userName, BreakIterator.getTitleInstance()):null);
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}


	private Long id;
	private String userName;
	private String email;
	private String role;
	private String status; 
	private String userType;

}
