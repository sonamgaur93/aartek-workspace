package com.hamararojgar.dto;

import java.util.List;

public class ResponseSkillWithJobSeeker {
	
	private int skillId;
	private String skillType;
	private int noOfJobSeeker;
	private List<SeekerDetailDto> seekerDetails;
	public int getSkillId() {
		return skillId;
	}
	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}
	public String getSkillType() {
		return skillType;
	}
	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}
	public int getNoOfJobSeeker() {
		return noOfJobSeeker;
	}
	public void setNoOfJobSeeker(int noOfJobSeeker) {
		this.noOfJobSeeker = noOfJobSeeker;
	}
	public List<SeekerDetailDto> getSeekerDetails() {
		return seekerDetails;
	}
	public void setSeekerDetails(List<SeekerDetailDto> seekerDetails) {
		this.seekerDetails = seekerDetails;
	}
	@Override
	public String toString() {
		return "ResponseSkillWithJobSeeker [skillId=" + skillId + ", skillType=" + skillType + ", noOfJobSeeker="
				+ noOfJobSeeker + ", seekerDetails=" + seekerDetails + "]";
	}
	
}
