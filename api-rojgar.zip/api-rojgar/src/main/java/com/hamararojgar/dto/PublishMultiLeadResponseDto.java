package com.hamararojgar.dto;

import java.util.List;

import com.hamararojgar.model.ResponseDto;

public class PublishMultiLeadResponseDto {

	List<ResponseDto> failedList;

	public List<ResponseDto> getFailedList() {
		return failedList;
	}

	public void setFailedList(List<ResponseDto> failedList) {
		this.failedList = failedList;
	}
	
}
