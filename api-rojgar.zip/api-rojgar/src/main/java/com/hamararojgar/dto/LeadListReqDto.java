package com.hamararojgar.dto;

import java.util.Set;

public class LeadListReqDto {

	private int agentId;
	private String fromDate;
	private String toDate;
	private String type;
	private Set<String> campaignCodes;
	private String campaignCode;
	
	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

	public Set<String> getCampaignCodes() {
		return campaignCodes;
	}

	public void setCampaignCodes(Set<String> campaignCodes) {
		this.campaignCodes = campaignCodes;
	}

	public int getAgentId() {
		return agentId;
	}

	public void setAgentId(int agentId) {
		this.agentId = agentId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	
}
