package com.hamararojgar.dto;

public class ProfileDetailRequestDto {

	private int id;
	private String contact_no;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	
	
}
