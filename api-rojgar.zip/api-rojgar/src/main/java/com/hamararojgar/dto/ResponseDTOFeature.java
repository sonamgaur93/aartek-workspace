package com.hamararojgar.dto;

import java.util.List;

public class ResponseDTOFeature extends DTOCommonDBFields{

	public String getFeatureCode() {
		return featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getFeature() {
		return feature;
	}
	public void setFeature(String feature) {
		this.feature = feature;
	}
		
	public List<ResponseDTOFeatureAction> getFeatureActions() {
		return featureActions;
	}
	public void setFeatureActions(List<ResponseDTOFeatureAction> featureActions) {
		this.featureActions = featureActions;
	}

	public List<ResponseDTOUserRole> getUserRoles() {
		return userRoles;
	}
	public void setUserRoles(List<ResponseDTOUserRole> userRoles) {
		this.userRoles = userRoles;
	}
	
	

	@Override
	public String toString() {
		return "ResponseDTOFeature [featureCode=" + featureCode + ", feature=" + feature + ", featureActions="
				+ featureActions + ", userRoles=" + userRoles + "]";
	}



	private String featureCode;
	private String feature;
	private List<ResponseDTOFeatureAction> featureActions;
	private List<ResponseDTOUserRole> userRoles;
	
}
