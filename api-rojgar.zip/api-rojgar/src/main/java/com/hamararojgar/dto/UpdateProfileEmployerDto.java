package com.hamararojgar.dto;

import org.springframework.web.multipart.MultipartFile;

public class UpdateProfileEmployerDto {

	private int employerId;
	private String email;
	private String phone;
	private String name;
	private String company;
	private String address;
	private String pan;
	private String gst;
	private String businessType;
	private String description;
	private MultipartFile company_image_multipart;
	private MultipartFile company_image_multipart2;
	private MultipartFile company_image_multipart3;
	private MultipartFile company_image_multipart4;
	private MultipartFile company_image_multipart5;
	private MultipartFile recording_multipart;
	private String deviceToken;
	
	
	public String getDeviceToken() {
		return deviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	public int getEmployerId() {
		return employerId;
	}
	public void setEmployerId(int employerId) {
		this.employerId = employerId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getGst() {
		return gst;
	}
	public void setGst(String gst) {
		this.gst = gst;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public MultipartFile getCompany_image_multipart() {
		return company_image_multipart;
	}
	public void setCompany_image_multipart(MultipartFile company_image_multipart) {
		this.company_image_multipart = company_image_multipart;
	}
	public MultipartFile getRecording_multipart() {
		return recording_multipart;
	}
	public void setRecording_multipart(MultipartFile recording_multipart) {
		this.recording_multipart = recording_multipart;
	}
	public MultipartFile getCompany_image_multipart2() {
		return company_image_multipart2;
	}
	public void setCompany_image_multipart2(MultipartFile company_image_multipart2) {
		this.company_image_multipart2 = company_image_multipart2;
	}
	public MultipartFile getCompany_image_multipart3() {
		return company_image_multipart3;
	}
	public void setCompany_image_multipart3(MultipartFile company_image_multipart3) {
		this.company_image_multipart3 = company_image_multipart3;
	}
	public MultipartFile getCompany_image_multipart4() {
		return company_image_multipart4;
	}
	public void setCompany_image_multipart4(MultipartFile company_image_multipart4) {
		this.company_image_multipart4 = company_image_multipart4;
	}
	public MultipartFile getCompany_image_multipart5() {
		return company_image_multipart5;
	}
	public void setCompany_image_multipart5(MultipartFile company_image_multipart5) {
		this.company_image_multipart5 = company_image_multipart5;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
