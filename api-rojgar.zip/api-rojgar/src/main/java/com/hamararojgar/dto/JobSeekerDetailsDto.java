package com.hamararojgar.dto;

import java.util.List;

public class JobSeekerDetailsDto {
	private Integer id;
	private List<String> skills;
	private String address;
	private String availability;
	private String status;
	private String currentLocation;
	private String preferredLocation;
	private String expectedCompensation;
	private String message;
	private String adhaarImageUrl;
	private String recordingUrl;
	private String profilePicUrl;
	private Boolean verified;
	private Boolean mobileVerification;
	private Boolean emailVerification;
	private Boolean accountVerification;
	private Long leadId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public List<String> getSkills() {
		return skills;
	}
	public void setSkills(List<String> skills) {
		this.skills = skills;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCurrentLocation() {
		return currentLocation;
	}
	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
	public String getPreferredLocation() {
		return preferredLocation;
	}
	public void setPreferredLocation(String preferredLocation) {
		this.preferredLocation = preferredLocation;
	}
	public String getExpectedCompensation() {
		return expectedCompensation;
	}
	public void setExpectedCompensation(String expectedCompensation) {
		this.expectedCompensation = expectedCompensation;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAdhaarImageUrl() {
		return adhaarImageUrl;
	}
	public void setAdhaarImageUrl(String adhaarImageUrl) {
		this.adhaarImageUrl = adhaarImageUrl;
	}
	public String getRecordingUrl() {
		return recordingUrl;
	}
	public void setRecordingUrl(String recordingUrl) {
		this.recordingUrl = recordingUrl;
	}
	public String getProfilePicUrl() {
		return profilePicUrl;
	}
	public void setProfilePicUrl(String profilePicUrl) {
		this.profilePicUrl = profilePicUrl;
	}
	public Boolean getVerified() {
		return verified;
	}
	public void setVerified(Boolean verified) {
		this.verified = verified;
	}
	public Boolean getMobileVerification() {
		return mobileVerification;
	}
	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}
	public Boolean getEmailVerification() {
		return emailVerification;
	}
	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}
	public Boolean getAccountVerification() {
		return accountVerification;
	}
	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}
	public Long getLeadId() {
		return leadId;
	}
	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	
}
