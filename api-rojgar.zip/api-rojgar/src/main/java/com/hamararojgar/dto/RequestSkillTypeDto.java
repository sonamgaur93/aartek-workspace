package com.hamararojgar.dto;

import java.util.List;

public class RequestSkillTypeDto {
	
	
	private List<String> skillType;

	public List<String> getSkillType() {
		return skillType;
	}

	public void setSkillType(List<String> skillType) {
		this.skillType = skillType;
	}

	@Override
	public String toString() {
		return "RequestSkillTypeDto [skillType=" + skillType + "]";
	}
		

}
