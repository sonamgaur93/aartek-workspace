package com.hamararojgar.dto;

import java.util.List;

import com.hamararojgar.model.JobSeekerMasterDto;

public class JobSeekerListResponseDto extends ResponseDTO{
	
	List<JobSeekerMasterDto> jobSeekerList ;

	public List<JobSeekerMasterDto> getJobSeekerList() {
		return jobSeekerList;
	}

	public void setJobSeekerList(List<JobSeekerMasterDto> jobSeekerList) {
		this.jobSeekerList = jobSeekerList;
	}

}
