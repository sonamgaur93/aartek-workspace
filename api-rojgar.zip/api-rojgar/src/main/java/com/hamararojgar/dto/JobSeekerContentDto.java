package com.hamararojgar.dto;

import java.util.Set;

public class JobSeekerContentDto extends DTOHamaraRojgarPagination {

	private JobSeekerDetailsDto jobSeeker;

	private Set<Integer> notinvited;

	private Set<Integer> notapplied;

	public JobSeekerDetailsDto getJobSeeker() {
		return jobSeeker;
	}
	public void setJobSeeker(JobSeekerDetailsDto jobSeeker) {
		this.jobSeeker = jobSeeker;
	}
	public Set<Integer> getNotinvited() {
		return notinvited;
	}
	public void setNotinvited(Set<Integer> notinvited) {
		this.notinvited = notinvited;
	}
	public Set<Integer> getNotapplied() {
		return notapplied;
	}
	public void setNotapplied(Set<Integer> notapplied) {
		this.notapplied = notapplied;
	}



}
