package com.hamararojgar.dto;

public class ChatReadDto {
	
    private int chatId;
	private boolean readByEmployer;
	private boolean readByJobSeeker;
	public int getChatId() {
		return chatId;
	}
	public void setChatId(int chatId) {
		this.chatId = chatId;
	}
	public boolean isReadByEmployer() {
		return readByEmployer;
	}
	public void setReadByEmployer(boolean readByEmployer) {
		this.readByEmployer = readByEmployer;
	}
	public boolean isReadByJobSeeker() {
		return readByJobSeeker;
	}
	public void setReadByJobSeeker(boolean readByJobSeeker) {
		this.readByJobSeeker = readByJobSeeker;
	}
	
	
}
