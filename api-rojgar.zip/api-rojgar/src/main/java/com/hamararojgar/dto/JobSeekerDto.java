package com.hamararojgar.dto;

import java.time.Instant;
import java.util.List;

import com.hamararojgar.model.SkillMaster;
import com.hamararojgar.payload.response.ResponseModuleComment;


public class JobSeekerDto {

	
	private int id;
	private String contact; 
	private String name;
	private String email;
	private String father_name;
	private String expected_salary;
	private String experience;
	private String address;
	private List<SkillMaster> skills;
	private String current_location;
	private String preferred_location;
	private String availability;
	private String expected_compensation;
	private String message;
	private String adhaar_image_url;
	private String recording_url;
	private String profile_pic_url;
	private String status;
	private Boolean verified;
	private Boolean mobileVerification;
	private Boolean emailVerification;
	private Boolean accountVerification;
	private Long leadId;
	private Instant registredDateTime;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getExpected_salary() {
		return expected_salary;
	}
	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<SkillMaster> getSkills() {
		return skills;
	}
	public void setSkills(List<SkillMaster> skills) {
		this.skills = skills;
	}
	public String getCurrent_location() {
		return current_location;
	}
	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}
	public String getPreferred_location() {
		return preferred_location;
	}
	public void setPreferred_location(String preferred_location) {
		this.preferred_location = preferred_location;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getExpected_compensation() {
		return expected_compensation;
	}
	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAdhaar_image_url() {
		return adhaar_image_url;
	}
	public void setAdhaar_image_url(String adhaar_image_url) {
		this.adhaar_image_url = adhaar_image_url;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	public String getProfile_pic_url() {
		return profile_pic_url;
	}
	public void setProfile_pic_url(String profile_pic_url) {
		this.profile_pic_url = profile_pic_url;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Boolean getVerified() {
		return verified;
	}
	public void setVerified(Boolean verified) {
		this.verified = verified;
	}
	public Long getLeadId() {
		return leadId;
	}

	public void setLeadId(Long leadId) {
		this.leadId = leadId;
	}
	public Boolean getMobileVerification() {
		return mobileVerification;
	}
	public void setMobileVerification(Boolean mobileVerification) {
		this.mobileVerification = mobileVerification;
	}
	public Boolean getEmailVerification() {
		return emailVerification;
	}
	public void setEmailVerification(Boolean emailVerification) {
		this.emailVerification = emailVerification;
	}
	public Boolean getAccountVerification() {
		return accountVerification;
	}
	public void setAccountVerification(Boolean accountVerification) {
		this.accountVerification = accountVerification;
	}
	public Instant getRegistredDateTime() {
		return registredDateTime;
	}
	public void setRegistredDateTime(Instant registredDateTime) {
		this.registredDateTime = registredDateTime;
	}
}
