package com.hamararojgar.dto;

import java.util.List;

public class BannerDTO extends ResponseDTO{
	
	private List<String> bannerList;

	public List<String> getBannerList() {
		return bannerList;
	}

	public void setBannerList(List<String> bannerList) {
		this.bannerList = bannerList;
	}

}
