package com.hamararojgar.dto;

import java.util.List;

public class SeekerSkillDetailsDto {
	
	private String skillType;
	private Long skillId;
	private Integer numberOfSeeker;
	private Integer currentPage;
	private Integer totalPage;
	private Integer totalItems;

	
	private List<SeekerInformationDto> seekerInformation;

	
	
	
	@Override
	public String toString() {
		return "SeekerSkillDetailsDto [skillType=" + skillType + ", skillId=" + skillId + ", numberOfSeeker="
				+ numberOfSeeker + ", currentPage=" + currentPage + ", totalPage=" + totalPage + ", totalItems="
				+ totalItems + ", seekerInformation=" + seekerInformation + "]";
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(Integer totalPage) {
		this.totalPage = totalPage;
	}

	public Integer getTotalItems() {
		return totalItems;
	}

	public void setTotalItems(Integer totalItems) {
		this.totalItems = totalItems;
	}

	public String getSkillType() {
		return skillType;
	}

	public void setSkillType(String skillType) {
		this.skillType = skillType;
	}

	public Long getSkillId() {
		return skillId;
	}

	public void setSkillId(Long skillId) {
		this.skillId = skillId;
	}

	public Integer getNumberOfSeeker() {
		return numberOfSeeker;
	}

	public void setNumberOfSeeker(Integer numberOfSeeker) {
		this.numberOfSeeker = numberOfSeeker;
	}



	public List<SeekerInformationDto> getSeekerInformation() {
		return seekerInformation;
	}

	public void setSeekerInformation(List<SeekerInformationDto> seekerInformation) {
		this.seekerInformation = seekerInformation;
	}


	
	
	

}
