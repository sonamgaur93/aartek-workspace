package com.hamararojgar.dto;

public class InviteForJobDto {

	private String jobSeekerName;
	private String employerName;
	private int jobId;
	private int job_seeker_Id;
	private String inviteMessage;
	private String jobTitle;
	
	public String getJobSeekerName() {
		return jobSeekerName;
	}
	public void setJobSeekerName(String jobSeekerName) {
		this.jobSeekerName = jobSeekerName;
	}
	public String getEmployerName() {
		return employerName;
	}
	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public int getJob_seeker_Id() {
		return job_seeker_Id;
	}
	public void setJob_seeker_Id(int job_seeker_Id) {
		this.job_seeker_Id = job_seeker_Id;
	}
	public String getInviteMessage() {
		return inviteMessage;
	}
	public void setInviteMessage(String inviteMessage) {
		this.inviteMessage = inviteMessage;
	}
	
	
	
}
