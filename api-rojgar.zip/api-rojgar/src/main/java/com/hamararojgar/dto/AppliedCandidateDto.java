package com.hamararojgar.dto;

import java.util.Date;

public class AppliedCandidateDto {

	private String address;
	private String adhaar_image_url;
	private String availability;
	private String contact_no;
	private String current_location;
	private String expected_compensation;
	private String expected_salary;
	private String experience;
	private String father_name;
	private String message;
	private String name;
	private String preferred_location;
	private String profile_pic_url;
	private String recording_url;
	private String skills;
	private String status;
	private String email;
	private boolean verified;
	private String device_token;
	private int appliedJobId;
	private String appliedDate;
	private String appliedJobType;
	private int job_id;
	private int job_seeker_id;
	private int unreadMessagesByJobSeeker;
	private int unreadMessagesByEmployer;
	private boolean chatStarted;
	private Date lastMessageTime;
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAdhaar_image_url() {
		return adhaar_image_url;
	}
	public void setAdhaar_image_url(String adhaar_image_url) {
		this.adhaar_image_url = adhaar_image_url;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public String getCurrent_location() {
		return current_location;
	}
	public void setCurrent_location(String current_location) {
		this.current_location = current_location;
	}
	public String getExpected_compensation() {
		return expected_compensation;
	}
	public void setExpected_compensation(String expected_compensation) {
		this.expected_compensation = expected_compensation;
	}
	public String getExpected_salary() {
		return expected_salary;
	}
	public void setExpected_salary(String expected_salary) {
		this.expected_salary = expected_salary;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPreferred_location() {
		return preferred_location;
	}
	public void setPreferred_location(String preferred_location) {
		this.preferred_location = preferred_location;
	}
	public String getProfile_pic_url() {
		return profile_pic_url;
	}
	public void setProfile_pic_url(String profile_pic_url) {
		this.profile_pic_url = profile_pic_url;
	}
	public String getRecording_url() {
		return recording_url;
	}
	public void setRecording_url(String recording_url) {
		this.recording_url = recording_url;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isVerified() {
		return verified;
	}
	public void setVerified(boolean verified) {
		this.verified = verified;
	}
	public String getDevice_token() {
		return device_token;
	}
	public void setDevice_token(String device_token) {
		this.device_token = device_token;
	}
	public int getAppliedJobId() {
		return appliedJobId;
	}
	public void setAppliedJobId(int appliedJobId) {
		this.appliedJobId = appliedJobId;
	}
	public int getJob_id() {
		return job_id;
	}
	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}
	public int getJob_seeker_id() {
		return job_seeker_id;
	}
	public void setJob_seeker_id(int job_seeker_id) {
		this.job_seeker_id = job_seeker_id;
	}
	public int getUnreadMessagesByJobSeeker() {
		return unreadMessagesByJobSeeker;
	}
	public void setUnreadMessagesByJobSeeker(int unreadMessagesByJobSeeker) {
		this.unreadMessagesByJobSeeker = unreadMessagesByJobSeeker;
	}
	public int getUnreadMessagesByEmployer() {
		return unreadMessagesByEmployer;
	}
	public void setUnreadMessagesByEmployer(int unreadMessagesByEmployer) {
		this.unreadMessagesByEmployer = unreadMessagesByEmployer;
	}
	public boolean isChatStarted() {
		return chatStarted;
	}
	public void setChatStarted(boolean chatStarted) {
		this.chatStarted = chatStarted;
	}
	public String getAppliedDate() {
		return appliedDate;
	}
	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}
	public String getAppliedJobType() {
		return appliedJobType;
	}
	public void setAppliedJobType(String appliedJobType) {
		this.appliedJobType = appliedJobType;
	}
	public Date getLastMessageTime() {
		return lastMessageTime;
	}
	public void setLastMessageTime(Date lastMessageTime) {
		this.lastMessageTime = lastMessageTime;
	}
	
	
	
}
