package com.hamararojgar.dto;

import java.util.List;

import com.hamararojgar.model.NotificationMaster;

public class NotificationListDto extends ResponseDTO{
	
	List<NotificationMaster> notificationList ;

	public List<NotificationMaster> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<NotificationMaster> notificationList) {
		this.notificationList = notificationList;
	}
	
	

}
