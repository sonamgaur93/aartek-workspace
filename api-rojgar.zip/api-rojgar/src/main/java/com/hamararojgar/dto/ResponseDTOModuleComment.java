package com.hamararojgar.dto;

public class ResponseDTOModuleComment extends DTOCommonDBFields{	

	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getModuleComment() {
		return moduleComment;
	}
	public void setModuleComment(String moduleComment) {
		this.moduleComment = moduleComment;
	}
	public String getRecordId() {
		return recordId;
	}
	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}
	private String moduleName;
	private String moduleComment;
	private String recordId;

}
