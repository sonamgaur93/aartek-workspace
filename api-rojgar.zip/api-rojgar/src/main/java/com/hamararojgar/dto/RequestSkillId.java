package com.hamararojgar.dto;

public class RequestSkillId {
	
	private int skillId;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	@Override
	public String toString() {
		return "RequestSkillId [skillId=" + skillId + "]";
	}
	
}
