package com.hamararojgar.dto;

import java.time.Instant;
import java.util.List;

public class DTOCampaign extends DTOCommonDBFields{
	
	public String getCampaignCode() {
		return campaignCode;
	}
	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}
	public String getCampaignName() {
		return campaignName;
	}
	public void setCampaignName(String campaignName) {
		this.campaignName = campaignName;
	}
	public String getCampaignDescription() {
		return campaignDescription;
	}
	public void setCampaignDescription(String campaignDescription) {
		this.campaignDescription = campaignDescription;
	}
	public Integer getCampaignType() {
		return campaignType;
	}
	public void setCampaignType(Integer campaignType) {
		this.campaignType = campaignType;
	}
	public Instant getCampaignStartDate() {
		return campaignStartDate;
	}
	public void setCampaignStartDate(Instant campaignStartDate) {
		this.campaignStartDate = campaignStartDate;
	}
	public Instant getCampaignEndDate() {
		return campaignEndDate;
	}
	public void setCampaignEndDate(Instant campaignEndDate) {
		this.campaignEndDate = campaignEndDate;
	}
	public String getCampaignStatus() {
		return campaignStatus;
	}
	public void setCampaignStatus(String campaignStatus) {
		this.campaignStatus = campaignStatus;
	}
	
	public List<ResponseDTOHamararojgarUser> getMembers() {
		return members;
	}
	public void setMembers(List<ResponseDTOHamararojgarUser> members) {
		this.members = members;
	}
	
	public List<ResponseDTOLead> getLeads() {
		return leads;
	}
	public void setLeads(List<ResponseDTOLead> leads) {
		this.leads = leads;
	}

	private String campaignCode;
	private String campaignName;
	private String campaignDescription;
	private Integer campaignType;
	private Instant campaignStartDate;
	private Instant campaignEndDate;
	private String campaignStatus;
	private List<ResponseDTOHamararojgarUser>  members;
	private List<ResponseDTOLead> leads;
}
