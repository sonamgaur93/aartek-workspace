package com.hamararojgar.dto;

import java.util.Date;

public class JobSeekerUpdateStatusResponseDto {

	private String responseCode = "";
	private String responseDescription = "";
	private Date responseTime ;
	
	private JobSeekerContentDto content;
	
	public Date getResponseTime() {
		if(null == responseTime)
			responseTime= new Date();
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseDescription() {
		return responseDescription;
	}

	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	
	public JobSeekerContentDto getContent() {
		return content;
	}

	public void setContent(JobSeekerContentDto content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "JobSeekerUpdateStatusResponseDto [responseCode=" + responseCode + ", responseDescription="
				+ responseDescription + ", responseTime=" + responseTime + ", content=" + content + "]";
	}

	
}
