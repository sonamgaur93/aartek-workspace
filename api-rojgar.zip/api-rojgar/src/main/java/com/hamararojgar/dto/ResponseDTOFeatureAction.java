package com.hamararojgar.dto;

public class ResponseDTOFeatureAction extends DTOCommonDBFields{

	public String getActionCode() {
		return actionCode;
	}
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	private String actionCode;
	private String action;
	
}
