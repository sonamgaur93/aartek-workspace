package com.hamararojgar.dto;

import org.springframework.web.multipart.MultipartFile;

public class SaveJobChat {
	
	private int appliedJobId;
	private String name;
	private String messageBy;
	private String message;
	private String type;
	private MultipartFile file;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAppliedJobId() {
		return appliedJobId;
	}
	public void setAppliedJobId(int appliedJobId) {
		this.appliedJobId = appliedJobId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMessageBy() {
		return messageBy;
	}
	public void setMessageBy(String messageBy) {
		this.messageBy = messageBy;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	
}
