package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.EmployerDto;

public class ResponseEmployer extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public EmployerDto getEmployer() {
		return employer;
	}

	public void setEmployer(EmployerDto employer) {
		this.employer = employer;
	}

	public List<EmployerDto> getEmployers() {
		return employers;
	}

	public void setEmployers(List<EmployerDto> employers) {
		this.employers = employers;
	}



	private EmployerDto employer;
	private List<EmployerDto> employers;

}