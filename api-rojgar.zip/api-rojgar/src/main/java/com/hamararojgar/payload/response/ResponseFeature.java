package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOBusinessType;
import com.hamararojgar.dto.ResponseDTOFeature;

public class ResponseFeature extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<ResponseDTOFeature> getFeatures() {
		return features;
	}
	public void setFeatures(List<ResponseDTOFeature> features) {
		this.features = features;
	}
	public ResponseDTOFeature getFeature() {
		return feature;
	}
	public void setFeature(ResponseDTOFeature feature) {
		this.feature = feature;
	}
	private List<ResponseDTOFeature> features;
	private ResponseDTOFeature feature;
	
}
