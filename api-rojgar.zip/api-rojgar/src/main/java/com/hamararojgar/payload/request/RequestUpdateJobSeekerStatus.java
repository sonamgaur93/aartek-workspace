package com.hamararojgar.payload.request;

public class RequestUpdateJobSeekerStatus {
	
	private int jobSeekerId ;
	private String status ;
	
	
	public int getJobSeekerId() {
		return jobSeekerId;
	}
	public void setJobSeekerId(int jobSeekerId) {
		this.jobSeekerId = jobSeekerId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RequestUpdateJobSeekerStatus [jobSeekerId=" + jobSeekerId + ", status=" + status + "]";
	}
	
	

}
