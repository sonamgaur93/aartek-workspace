package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.EmployerDto;
import com.hamararojgar.dto.ResponseDTORojgarJob;

public class ResponseRojgarJob extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public ResponseDTORojgarJob getJob() {
		return job;
	}
	public void setJob(ResponseDTORojgarJob job) {
		this.job = job;
	}
	public List<ResponseDTORojgarJob> getJobs() {
		return jobs;
	}
	public void setJobs(List<ResponseDTORojgarJob> jobs) {
		this.jobs = jobs;
	}
	private ResponseDTORojgarJob job;
	private List<ResponseDTORojgarJob> jobs;

}