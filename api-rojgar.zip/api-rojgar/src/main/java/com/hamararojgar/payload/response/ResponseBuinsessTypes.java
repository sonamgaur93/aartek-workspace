package com.hamararojgar.payload.response;

import java.util.List;

import com.hamararojgar.dto.DTOHamaraRojgarPagination;
import com.hamararojgar.dto.ResponseDTOBusinessType;

public class ResponseBuinsessTypes extends DTOHamaraRojgarPagination implements ResponseHamararojgarContent {
	
	public List<ResponseDTOBusinessType> getBusinessTypes() {
		return businessTypes;
	}
	public void setBusinessTypes(List<ResponseDTOBusinessType> businessTypes) {
		this.businessTypes = businessTypes;
	}
	public ResponseDTOBusinessType getBusinessType() {
		return businessType;
	}
	public void setBusinessType(ResponseDTOBusinessType businessType) {
		this.businessType = businessType;
	}
	private List<ResponseDTOBusinessType> businessTypes;
	private ResponseDTOBusinessType businessType;
	
}
