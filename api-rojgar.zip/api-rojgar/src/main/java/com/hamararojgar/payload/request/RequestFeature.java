package com.hamararojgar.payload.request;

import java.util.Set;

public class RequestFeature {
	
	public String getFeatureCode() {
		return featureCode;
	}
	public void setFeatureCode(String featureCode) {
		this.featureCode = featureCode;
	}
	public String getFeatureName() {
		return featureName;
	}
	public void setFeatureName(String featureName) {
		this.featureName = featureName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public Set<String> getActions() {
		return actions;
	}
	public void setActions(Set<String> actions) {
		this.actions = actions;
	}

	public Set<String> getRoleCodes() {
		return roleCodes;
	}
	public void setRoleCodes(Set<String> roleCodes) {
		this.roleCodes = roleCodes;
	}
	@Override
	public String toString() {
		return "RequestFeature [featureCode=" + featureCode + ", featureName=" + featureName + ", action=" + action
				+ ", actions=" + actions + "]";
	}

	private String featureCode;
	private String featureName;
	private String action;
	private Set<String> actions;
	private Set<String> roleCodes;

}
